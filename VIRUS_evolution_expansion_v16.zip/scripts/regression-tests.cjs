/* Regression tests for critical VIRUS game logic.
 * Run with: npm test
 * TypeScript source is transpiled in-memory so tests need no extra runtime package.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const ts = require('typescript');

require.extensions['.ts'] = (module, filename) => {
  const source = fs.readFileSync(filename, 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2020,
      esModuleInterop: true,
    },
    fileName: filename,
  }).outputText;
  module._compile(compiled, filename);
};

const { buildTraits, MUTATIONS, MUTATION_BY_ID, STAGES } = require('../src/game/data.ts');
const { World } = require('../src/game/world.ts');
const { Game } = require('../src/game/engine.ts');
const { circleRect, dist2 } = require('../src/game/math.ts');
const { Input } = require('../src/game/input.ts');
const campaignSave = require('../src/game/save.ts');
const { getMutationTierStatus } = require('../src/game/mutationTier.ts');
const { MUTATION_PREVIEW_STYLES } = require('../src/game/draw.ts');

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    process.stdout.write(`✓ ${name}\n`);
  } catch (error) {
    process.stderr.write(`✗ ${name}\n${error.stack || error}\n`);
    process.exitCode = 1;
  }
}

const approx = (a, b, tolerance = 1e-8) => assert.ok(Math.abs(a - b) <= tolerance, `${a} != ${b}`);
const levelsA = {
  flagellum: 3, cilia: 2, phase: 3, plating: 2, regen: 1, magnet: 3,
  net: 2, enzymes: 1, fission: 2, taxis: 3, volt: 3, barbs: 1,
};
const levelsB = Object.fromEntries(Object.entries(levelsA).reverse());


test('every mutation has a distinct visual preview mode and identity tint', () => {
  const mutationIds = MUTATIONS.map((mutation) => mutation.id).sort();
  const previewIds = Object.keys(MUTATION_PREVIEW_STYLES).sort();
  assert.deepEqual(previewIds, mutationIds, 'every gameplay mutation must have a dedicated preview style');
  const modes = MUTATIONS.map((mutation) => MUTATION_PREVIEW_STYLES[mutation.id].mode);
  assert.equal(new Set(modes).size, MUTATIONS.length, 'each mutation must use a different visual signature mode');
  const tints = MUTATIONS.map((mutation) => MUTATION_PREVIEW_STYLES[mutation.id].tint);
  assert.equal(new Set(tints).size, MUTATIONS.length, 'each mutation must have its own preview tint');
  const hues = MUTATIONS.map((mutation) => MUTATION_PREVIEW_STYLES[mutation.id].hue);
  assert.equal(new Set(hues).size, MUTATIONS.length, 'each mutation preview must have its own hue');
});

test('gameplay background no longer relies on a repeating canvas tile', () => {
  const source = fs.readFileSync(require.resolve('../src/game/draw.ts'), 'utf8');
  assert.ok(source.includes('function getFluidField'), 'continuous world-space fluid field should exist');
  assert.ok(source.includes('function drawFluid'), 'continuous backdrop renderer should exist');
  assert.ok(source.includes('world-anchored fluid backdrop'), 'background intent should be documented next to its generator');
  assert.ok(!source.includes('createPattern('), 'no repeating CanvasPattern should remain');
  assert.ok(!source.includes('tileCache'), 'the old periodically tiled texture cache should be removed');
  assert.ok(!source.includes('getTile('), 'the old clipped texture tile generator should be removed');
});

test('current-lane artwork no longer paints hard-edged rectangular panels', () => {
  const source = fs.readFileSync(require.resolve('../src/game/draw.ts'), 'utf8');
  const start = source.indexOf('function drawCurrents(');
  const end = source.indexOf('function drawDecor(', start);
  assert.ok(start >= 0 && end > start, 'current drawing function should be present');
  const body = source.slice(start, end);
  assert.ok(body.includes('broad, curved strokes'), 'currents should be represented by flowing curves');
  assert.ok(body.includes('flowGradient.addColorStop(0, "rgba(80,170,255,0)")'), 'flow glow should fade to transparency at its ends');
  assert.ok(!body.includes('ctx.fillRect(r.x, r.y, r.w, r.h)'), 'the old solid rectangular current fill must not return');
  assert.ok(!body.includes('ctx.rect(r.x, r.y, r.w, r.h)'), 'current boundaries must not be drawn as a visible rectangle');
});

test('mutation preview scales large gameplay fields into a transparent thumbnail canvas', () => {
  const source = fs.readFileSync(require.resolve('../src/game/draw.ts'), 'utf8');
  const previewComponent = fs.readFileSync(require.resolve('../src/components/VirusPreview.tsx'), 'utf8');
  assert.ok(source.includes('aura: Math.min(traits.aura, 62)'), 'gameplay-scale magnet radius must not clip the thumbnail');
  assert.ok(source.includes('drawMutationSignature(ctx, style.mode'), 'mutation-specific visual layer must be drawn');
  assert.ok(previewComponent.includes('size={144}') === false, 'canvas dimensions are configured in the overlay, not the reusable component');
  const overlays = fs.readFileSync(require.resolve('../src/components/Overlays.tsx'), 'utf8');
  assert.ok(overlays.includes('size={144}') && overlays.includes('scale={0.78}'), 'mutation card preview must use the larger transparent canvas and contain the halo');
  const css = fs.readFileSync(require.resolve('../src/index.css'), 'utf8');
  assert.match(css, /\.mutation-preview-canvas\s*\{[^}]*position:\s*absolute[^}]*transform:\s*translate\(-50%,\s*-50%\)/s, 'preview canvas should be centered and not clipped by its smaller circular frame');
});

test('zone briefing stays open indefinitely until Enter/confirm is explicitly triggered', () => {
  const originalWindow = global.window;
  const originalDocument = global.document;
  const originalRaf = global.requestAnimationFrame;
  const originalCancelRaf = global.cancelAnimationFrame;
  const makeEventTarget = () => ({
    addEventListener() {},
    removeEventListener() {},
  });
  global.window = {
    ...makeEventTarget(),
    devicePixelRatio: 1,
    matchMedia: () => ({ matches: false }),
  };
  global.document = {
    ...makeEventTarget(),
    hidden: false,
  };
  global.requestAnimationFrame = () => 1;
  global.cancelAnimationFrame = () => {};

  let game;
  try {
    const canvas = {
      ...makeEventTarget(),
      style: {},
      getContext: () => ({}),
    };
    const container = {
      getBoundingClientRect: () => ({ width: 800, height: 600 }),
    };
    game = new Game(canvas, container, { onHud() {}, onPhase() {} });
    // We test phase/timing, not canvas rendering.
    game.render = () => {};
    game.emit = () => {};
    game.startRun();
    assert.equal(game.currentPhase, 'briefing');

    // Simulate two minutes of animation ticks; the briefing must not time out.
    for (let frame = 1; frame <= 120 * 60; frame++) {
      game.tick(frame * (1000 / 60));
    }
    assert.equal(game.currentPhase, 'briefing', 'briefing should remain visible after two minutes');

    // Enter is routed by GameShell to the engine's confirm event.
    game.handleEvent('confirm');
    assert.equal(game.currentPhase, 'playing', 'Enter/confirm should start the stage');
    game.beginStage(); // The touch button/backdrop uses this action; it must be harmless after confirmation.
    assert.equal(game.currentPhase, 'playing');
  } finally {
    if (game) game.destroy();
    if (originalWindow === undefined) delete global.window;
    else global.window = originalWindow;
    if (originalDocument === undefined) delete global.document;
    else global.document = originalDocument;
    if (originalRaf === undefined) delete global.requestAnimationFrame;
    else global.requestAnimationFrame = originalRaf;
    if (originalCancelRaf === undefined) delete global.cancelAnimationFrame;
    else global.cancelAnimationFrame = originalCancelRaf;
  }
});

test('a lagged frame stops at the exact tick that requests a mutation choice', () => {
  const originalWindow = global.window;
  const originalDocument = global.document;
  const originalRaf = global.requestAnimationFrame;
  const originalCancelRaf = global.cancelAnimationFrame;
  const makeEventTarget = () => ({ addEventListener() {}, removeEventListener() {} });
  global.window = { ...makeEventTarget(), devicePixelRatio: 1, matchMedia: () => ({ matches: false }) };
  global.document = { ...makeEventTarget(), hidden: false };
  global.requestAnimationFrame = () => 1;
  global.cancelAnimationFrame = () => {};
  let game;
  try {
    const canvas = { ...makeEventTarget(), style: {}, getContext: () => ({}) };
    const container = { getBoundingClientRect: () => ({ width: 800, height: 600 }) };
    game = new Game(canvas, container, { onHud() {}, onPhase() {} });
    let updates = 0;
    game.phase = 'playing';
    game.world = {
      hitStop: 0,
      slowmo: 0,
      pendingEvolve: false,
      finished: null,
      update() { updates++; this.pendingEvolve = true; },
      rollChoices() { return ['flagellum', 'volt', 'net']; },
    };
    game.input.consumeDash = () => false;
    game.input.endFrame = () => {};
    game.last = 0;
    game.time = 0;
    game.acc = 0;
    game.zoom = 1;
    game.hudTimer = 100;
    game.emit = () => {};
    game.render = () => {};
    game.steerVector = () => ({ dir: { x: 0, y: 0 }, mag: 0 });
    // Simulate a delayed RAF callback; normal fixed-step accumulation would have
    // enough time for several updates if the phase guard were missing.
    game.tick(250);
    assert.equal(updates, 1, 'world must not continue simulating after mutation becomes pending');
    assert.equal(game.currentPhase, 'mutate');
    assert.deepEqual(game.choices, ['flagellum', 'volt', 'net']);
    assert.equal(game.acc, 0, 'leftover lag time must not be replayed after the overlay closes');
  } finally {
    if (game) game.destroy();
    if (originalWindow === undefined) delete global.window;
    else global.window = originalWindow;
    if (originalDocument === undefined) delete global.document;
    else global.document = originalDocument;
    if (originalRaf === undefined) delete global.requestAnimationFrame;
    else global.requestAnimationFrame = originalRaf;
    if (originalCancelRaf === undefined) delete global.cancelAnimationFrame;
    else global.cancelAnimationFrame = originalCancelRaf;
  }
});

test('briefing has no timeout and only deliberate tap targets dismiss it', () => {
  const source = fs.readFileSync(require.resolve('../src/components/Overlays.tsx'), 'utf8');
  const start = source.indexOf('export function Briefing(');
  const end = source.indexOf('/* ------------------------------------------------------------------ */', start);
  const component = source.slice(start, end);
  assert.ok(component.includes('onClick={onBegin}'), 'a deliberate touch/click must dismiss the briefing');
  assert.ok(component.includes('НАЧАТЬ (ENTER / КАСАНИЕ)'), 'the visible Start button must advertise touch');
  assert.ok(component.includes('НАЧАТЬ (ENTER / КАСАНИЕ)'), 'the control must advertise its supported input');
  assert.ok(!/setTimeout|setInterval|introTimer|briefingTimer/.test(component), 'the briefing UI must not contain an auto-close timer');
  const engine = fs.readFileSync(require.resolve('../src/game/engine.ts'), 'utf8');
  assert.ok(engine.includes('Keep the zone briefing open until the player explicitly confirms it.'), 'engine must keep the phase until explicit confirmation');
  assert.ok(!/phase === "briefing"[^\n]*setTimeout/.test(engine), 'engine must not schedule a briefing timeout');
});

test('Windows launcher validates dependencies after an interrupted npm install', () => {
  const launcher = fs.readFileSync(require.resolve('../START_VIRUS.bat'), 'utf8');
  assert.ok(launcher.includes('call npm ls --depth=0'), 'launcher must validate node_modules rather than trusting folder existence');
  assert.ok(launcher.includes('major===22&&minor>=12'), 'launcher must explain/guard the Node version required by Vite');
  assert.ok(launcher.includes('goto :install_dependencies'), 'missing or partial dependencies trigger npm ci again');
  assert.ok(launcher.includes(':dependency_failed'), 'dependency failure is distinguished from TypeScript source errors');
  assert.ok(launcher.includes(':typecheck_failed'), 'source typecheck failure has its own diagnostic');
});

test('trait rebuild is independent of mutation selection/order', () => {
  assert.deepEqual(buildTraits(levelsA), buildTraits(levelsB));
  approx(buildTraits({ flagellum: 3, cilia: 3 }).speed, 252 * 1.54 + 48);
  approx(buildTraits({ flagellum: 3, phase: 3 }).dashTime, 0.2 + 0.06 + 0.09);
  approx(buildTraits({ magnet: 3, net: 3, taxis: 3 }).aura, 64 + 258 + 78 + 42);
});

test('applying the same mutations in different orders produces identical final traits', () => {
  const ids = Object.entries(levelsA).flatMap(([id, level]) => Array(level).fill(id));
  const a = new World(0, {}, 0);
  const b = new World(0, {}, 0);
  // Compare the actual gameplay mutation method, not just its pure calculator.
  for (const id of ids) a.applyMutation(id);
  for (const id of [...ids].reverse()) b.applyMutation(id);
  assert.deepEqual(a.levels, b.levels);
  assert.deepEqual(a.traits, b.traits);
  assert.equal(a.virus.r, b.virus.r);
  assert.equal(a.virus.hp, b.virus.hp);
  assert.equal(a.virus.shield, b.virus.shield);
});

test('campaign expansion contains eight ordered stages with a final boss', () => {
  assert.equal(STAGES.length, 8);
  assert.deepEqual(STAGES.map((s) => s.id), [1, 2, 3, 4, 5, 6, 7, 8]);
  assert.ok(STAGES.every((s) => s.quota > 0 && s.pickupCount >= 50));
  assert.ok(STAGES.every((s, i) => i === 0 || s.quota > STAGES[i - 1].quota), 'DNA quotas should scale across the campaign');
  assert.equal(STAGES[7].boss, true);
  assert.ok(STAGES[7].spawns.sentinel >= 1, 'final zone must contain the Sentinel boss');
});

test('late-game enemy population grows at every zone from 6 through 8', () => {
  const total = (stage) => Object.values(stage.spawns).reduce((sum, n) => sum + n, 0);
  // The last three zones should each add enemies rather than thin out the waves.
  assert.ok(total(STAGES[5]) > total(STAGES[4]), `zone 6 (${total(STAGES[5])}) must exceed zone 5 (${total(STAGES[4])})`);
  assert.ok(total(STAGES[6]) > total(STAGES[5]), `zone 7 (${total(STAGES[6])}) must exceed zone 6 (${total(STAGES[5])})`);
  assert.ok(total(STAGES[7]) > total(STAGES[6]), `zone 8 (${total(STAGES[7])}) must exceed zone 7 (${total(STAGES[6])})`);

  // Every regular enemy family already present in a late-game stage must be
  // at least as numerous in the next stage. The Sentinel remains the final boss.
  for (let i = 4; i < 7; i++) {
    for (const [kind, count] of Object.entries(STAGES[i].spawns)) {
      if (kind === 'sentinel') continue;
      assert.ok(STAGES[i + 1].spawns[kind] >= count,
        `${kind} count must not drop from zone ${STAGES[i].id} to ${STAGES[i + 1].id}`);
    }
  }
  assert.equal(STAGES[7].spawns.sentinel, 1, 'zone 8 keeps exactly one final Sentinel');
  assert.ok(STAGES[5].respawnEvery > STAGES[6].respawnEvery && STAGES[6].respawnEvery > STAGES[7].respawnEvery,
    'enemy respawn intervals must shorten as the late-game intensity increases');
});

test('difficulty progression is smooth and strictly increasing through all eight zones', () => {
  const totals = STAGES.map((stage) => Object.values(stage.spawns).reduce((sum, n) => sum + (n ?? 0), 0));
  assert.deepEqual(totals, [20, 30, 40, 50, 60, 72, 84, 95]);
  assert.deepEqual(STAGES.map((stage) => stage.quota), [14, 25, 36, 47, 58, 69, 80, 91]);
  assert.deepEqual(STAGES.map((stage) => stage.respawnEvery), [7, 6.5, 6, 5.5, 5, 4.5, 4, 3.5]);
  assert.deepEqual(STAGES.map((stage) => stage.pickupCount), [54, 62, 70, 80, 90, 100, 110, 120]);
  assert.deepEqual(STAGES.map((stage) => Object.values(stage.respawn).reduce((sum, n) => sum + (n ?? 0), 0)), [2, 3, 4, 5, 6, 8, 11, 13]);
  for (let i = 1; i < STAGES.length; i++) {
    assert.ok(totals[i] > totals[i - 1], `enemy count must rise at zone ${i + 1}`);
    assert.ok(STAGES[i].quota > STAGES[i - 1].quota, `DNA quota must rise at zone ${i + 1}`);
    assert.ok(STAGES[i].respawnEvery < STAGES[i - 1].respawnEvery, `reinforcements must arrive faster at zone ${i + 1}`);
  }
});


test('new specialist enemy families are introduced in zones 6, 7 and 8 and persist into later waves', () => {
  assert.equal(STAGES[5].spawns.symbiote, 2, 'zone 6 introduces the Symbiote');
  assert.equal(STAGES[5].spawns.phantom ?? 0, 0, 'Phantoms should not appear before zone 7');
  assert.equal(STAGES[5].spawns.incubator ?? 0, 0, 'Incubators should not appear before zone 8');
  assert.equal(STAGES[6].spawns.symbiote, 2, 'the healer family remains in zone 7');
  assert.equal(STAGES[6].spawns.phantom, 2, 'zone 7 introduces the Phantom');
  assert.equal(STAGES[6].spawns.incubator ?? 0, 0, 'Incubators remain exclusive to zone 8');
  assert.equal(STAGES[7].spawns.symbiote, 2);
  assert.equal(STAGES[7].spawns.phantom, 2);
  assert.equal(STAGES[7].spawns.incubator, 1, 'zone 8 introduces one non-respawning Incubator');
  assert.equal(STAGES[7].spawns.sentinel, 1, 'the final Sentinel remains a separate boss');
  assert.ok(STAGES[7].spawns.incubator > 0 && !STAGES[7].respawn.incubator,
    'the nest should be a tactical objective, not an endlessly respawning source');
});

test('Symbiote channels a heal into a damaged nearby ally, never itself or the boss', () => {
  const world = new World(5, {}, 0);
  world.virus.pos = { x: 500, y: 500 };
  const healer = world.spawnEnemy('symbiote', { x: 1480, y: 1050 });
  const ally = world.spawnEnemy('chaser', { x: 1540, y: 1050 });
  const boss = world.spawnEnemy('sentinel', { x: 1620, y: 1050 });
  healer.hp = 25;
  healer.maxHp = 68;
  ally.hp = 20;
  ally.maxHp = 100;
  boss.hp = 400;
  boss.maxHp = 900;
  healer.specialCooldown = 0;
  world.enemies = [healer, ally, boss];
  for (let i = 0; i < 24; i++) world.updateEnemies(0.1);
  assert.equal(ally.hp, 36, 'one completed channel restores 16% of the ally maximum health');
  assert.equal(healer.hp, 25, 'the Symbiote cannot heal itself');
  assert.equal(boss.hp, 400, 'the support unit cannot heal the Sentinel boss');
  assert.equal(healer.specialState, 'idle', 'the channel returns to its cooldown state');
  assert.ok(healer.specialCooldown > 3.2 && healer.specialCooldown <= 5.8, 'a successful heal starts a meaningful cooldown');
});

test('Phantom telegraphs its target line before a fast, dodgeable ambush dash', () => {
  const world = new World(6, {}, 0);
  world.virus.pos = { x: 1500, y: 1100 };
  const phantom = world.spawnEnemy('phantom', { x: 1100, y: 1100 });
  phantom.specialCooldown = 0;
  world.enemies = [phantom];
  world.updateEnemies(0.05);
  assert.equal(phantom.specialState, 'telegraph', 'the attack starts with a visible wind-up');
  assert.ok(phantom.specialTimer >= 0.7 && phantom.specialTarget, 'the aim line has a warning window');
  world.updateEnemies(0.8);
  assert.equal(phantom.specialState, 'active', 'the dash starts only after the warning expires');
  world.updateEnemies(0.05);
  assert.ok(Math.abs(Math.hypot(phantom.vel.x, phantom.vel.y) - 520) < 1e-6,
    'the Phantom commits to a readable high-speed dash');
  assert.equal(phantom.stealth, 0, 'the Phantom reveals itself during its dash');
  world.updateEnemies(0.5);
  assert.equal(phantom.specialState, 'idle', 'the dash ends rather than becoming permanent pursuit');
  assert.ok(phantom.specialCooldown >= 4, 'the Phantom has a recovery window after its ambush');
});

test('Phantom ambush contact has a defined burst hit and immediately ends the dash', () => {
  const world = new World(6, {}, 0);
  const phantom = world.spawnEnemy('phantom', { x: 1200, y: 1200 });
  world.virus.pos = { ...phantom.pos };
  world.virus.hp = 100;
  world.virus.invuln = 0;
  world.virus.shield = 0;
  phantom.specialState = 'active';
  phantom.specialTimer = 0.3;
  phantom.specialVector = { x: 1, y: 0 };
  world.enemies = [phantom];
  world.updateEnemies(0.01);
  assert.equal(world.virus.hp, 73, 'ambush contact deals 1.35x the Phantom contact damage');
  assert.equal(phantom.specialState, 'idle', 'the hit consumes the active ambush');
  assert.ok(phantom.specialCooldown >= 4, 'the Phantom cannot chain another instant dash');
});

test('Incubator hatches alternating larvae and never exceeds four living offspring', () => {
  const world = new World(7, {}, 0);
  world.virus.invuln = 999;
  const nest = world.spawnEnemy('incubator', { x: 1700, y: 1320 });
  world.enemies = [nest];
  nest.specialCooldown = 0;
  world.updateEnemies(0.05);
  assert.equal(nest.specialState, 'telegraph', 'egg chambers charge visibly before hatching');
  for (let i = 0; i < 14; i++) world.updateEnemies(0.1);
  let larvae = world.enemies.filter((enemy) => enemy.summonedBy === nest.uid && enemy.alive);
  assert.equal(larvae.length, 2, 'one hatch event creates two minions');
  assert.deepEqual(new Set(larvae.map((enemy) => enemy.kind)), new Set(['mite', 'spore']), 'the brood has two alternating familiar forms');
  nest.specialCooldown = 0;
  world.updateEnemies(0.05);
  for (let i = 0; i < 14; i++) world.updateEnemies(0.1);
  larvae = world.enemies.filter((enemy) => enemy.summonedBy === nest.uid && enemy.alive);
  assert.equal(larvae.length, 4, 'the nest reaches, but never exceeds, its living brood cap');
  const broodSpore = larvae.find((enemy) => enemy.kind === 'spore');
  assert.ok(broodSpore, 'at least one incubator hatch is a spore larva');
  const enemyCountBeforeSporeDeath = world.enemies.length;
  world.killEnemy(broodSpore);
  assert.equal(world.enemies.length, enemyCountBeforeSporeDeath,
    'incubator-born spore larvae cannot recursively split and bypass the four-larva cap');
  nest.specialCooldown = 0;
  world.updateEnemies(0.05);
  assert.equal(nest.specialState, 'telegraph', 'the nest may refill only the single slot opened by a defeated larva');
  for (let i = 0; i < 14; i++) world.updateEnemies(0.1);
  larvae = world.enemies.filter((enemy) => enemy.summonedBy === nest.uid && enemy.alive);
  assert.equal(larvae.length, 4, 'the hatch fills the open slot and returns to the exact brood cap');
  nest.specialCooldown = 0;
  world.updateEnemies(0.05);
  assert.equal(nest.specialState, 'idle', 'a full brood prevents an extra hatch cycle');
  assert.ok(nest.specialCooldown > 0, 'a full brood uses a short retry cooldown, not a hot loop');
});

test('destroying the Incubator stops future hatches while already hatched minions remain independent', () => {
  const world = new World(7, {}, 0);
  const nest = world.spawnEnemy('incubator', { x: 1700, y: 1320 });
  world.enemies = [nest];
  nest.specialCooldown = 0;
  world.updateEnemies(0.05);
  for (let i = 0; i < 14; i++) world.updateEnemies(0.1);
  const before = world.enemies.filter((enemy) => enemy.summonedBy === nest.uid && enemy.alive).length;
  assert.equal(before, 2);
  world.killEnemy(nest);
  for (let i = 0; i < 200; i++) world.updateEnemies(0.1);
  const after = world.enemies.filter((enemy) => enemy.summonedBy === nest.uid && enemy.alive).length;
  assert.equal(after, before, 'destroyed nests cannot spawn replacement larvae');
});

test('all nine enemy kinds have distinct presentation and readable special telegraphs', () => {
  const source = fs.readFileSync(require.resolve('../src/game/draw.ts'), 'utf8');
  const overlays = fs.readFileSync(require.resolve('../src/components/Overlays.tsx'), 'utf8');
  for (const kind of ['mite', 'spore', 'chaser', 'spiker', 'hunter', 'symbiote', 'phantom', 'incubator', 'sentinel']) {
    assert.ok(source.includes(`case "${kind}"`), `${kind} needs its own rendered silhouette`);
  }
  assert.ok(source.includes('e.kind === "symbiote" && e.specialState === "telegraph"'), 'healing tether must be visible before the heal');
  assert.ok(source.includes('e.kind === "phantom" && e.specialState === "telegraph"'), 'ambush line must be visible before the dash');
  assert.ok(source.includes('e.kind === "incubator" && e.specialState === "telegraph"'), 'hatch progress must be visible before spawning');
  const worldSource = fs.readFileSync(require.resolve('../src/game/world.ts'), 'utf8');
  assert.ok(worldSource.includes('e.kind === "spore" && e.phase < 2 && e.summonedBy === null'),
    'Incubator-born spores cannot recursively split around the four-larva cap');
  for (const label of ['СИМБИОНТ · ЛЕЧИТ', 'ФАНТОМ · ЗАСАДА', 'ИНКУБАТОР · ВЫВОДОК']) {
    assert.ok(overlays.includes(label), `${label} must be documented in the zone briefing`);
  }
});

test('new specialist enemy simulations stay finite and respect the per-nest brood cap in all late zones', () => {
  for (const stageIndex of [5, 6, 7]) {
    const world = new World(stageIndex, {}, 0);
    world.virus.invuln = 999;
    for (let frame = 0; frame < 900; frame++) world.update(1 / 60, { x: 0.4, y: -0.2 }, 0.45, frame % 180 === 0);
    for (const enemy of world.enemies) {
      for (const value of [enemy.pos.x, enemy.pos.y, enemy.vel.x, enemy.vel.y, enemy.hp, enemy.specialTimer, enemy.specialCooldown, enemy.stealth]) {
        assert.ok(Number.isFinite(value), `stage ${stageIndex + 1} ${enemy.kind} state must remain finite`);
      }
      if (enemy.kind === 'incubator') {
        const brood = world.enemies.filter((candidate) => candidate.alive && candidate.summonedBy === enemy.uid);
        assert.ok(brood.length <= 4, 'no Incubator may exceed four living larvae');
      }
    }
  }
});

test('stage progression continues to zone 8 and only the final zone completes the run', () => {
  const makeWorld = (stageIndex) => ({
    stageIndex, score: 1234, levels: { flagellum: 2 }, dnaTotal: 3, kills: 2,
    time: 50, evolutionCount: 1,
  });
  const game = Object.create(Game.prototype);
  game.world = makeWorld(6);
  game.runTotals = { dna: 12, kills: 5, time: 250, evolutions: 8 };
  let loaded;
  game.loadStage = (...args) => { loaded = args; };
  game.nextStage();
  assert.equal(loaded[0], 7, 'clearing zone 7 should load zone 8');

  const finalGame = Object.create(Game.prototype);
  finalGame.world = makeWorld(7);
  finalGame.runTotals = { dna: 12, kills: 5, time: 250, evolutions: 8 };
  let finalResult;
  finalGame.finishRun = (victory, score) => { finalResult = { victory, score }; };
  finalGame.nextStage();
  assert.deepEqual(finalResult, { victory: true, score: 1234 }, 'clearing zone 8 should finish the campaign');
});

test('evolution-map UI documents all mutation branches and is available from menu and pause', () => {
  const overlays = fs.readFileSync(require.resolve('../src/components/Overlays.tsx'), 'utf8');
  const shell = fs.readFileSync(require.resolve('../src/components/GameShell.tsx'), 'utf8');
  assert.ok(overlays.includes('export function EvolutionMap('));
  assert.ok(overlays.includes('КАРТА ЭВОЛЮЦИИ'));
  assert.ok(overlays.includes('def.levels.map'));
  assert.ok(shell.includes('onEvolutionMap={openEvolutionMap}'));
  assert.ok(shell.includes('<EvolutionMap levels={hud.levels}'));
});

test('victory produces a skippable animated ending before the results screen', () => {
  const overlays = fs.readFileSync(require.resolve('../src/components/Overlays.tsx'), 'utf8');
  const styles = fs.readFileSync(require.resolve('../src/index.css'), 'utf8');
  assert.ok(overlays.includes('function VictoryCinematic('));
  assert.ok(overlays.includes('ПРОПУСТИТЬ ЗАСТАВКУ / К ИТОГАМ'));
  assert.ok(overlays.includes('window.setTimeout(() => setShowCinematic(false), 10500)'));
  assert.ok(styles.includes('@keyframes victoryVirusFloat'));
  assert.ok(styles.includes('@media (prefers-reduced-motion: reduce)'));
});

test('all listed mutations stay inside defined level caps', () => {
  for (const def of MUTATIONS) {
    for (let level = 1; level <= def.max; level++) {
      const traits = buildTraits({ [def.id]: level });
      for (const [key, value] of Object.entries(traits)) {
        assert.equal(typeof value, 'number', `${def.id} ${level}: ${key} is not numeric`);
        assert.ok(Number.isFinite(value), `${def.id} ${level}: ${key} is not finite`);
      }
    }
    assert.deepEqual(buildTraits({ [def.id]: 999 }), buildTraits({ [def.id]: def.max })); // levels are clamped to legal caps
  }
});

test('electric-shock damage matches the three mutation descriptions', () => {
  assert.equal(buildTraits({ volt: 1 }).shockDamage, 26);
  assert.equal(buildTraits({ volt: 2 }).shockDamage, 48);
  assert.equal(buildTraits({ volt: 3 }).shockDamage, 80);
});

test('lytic enzymes respect the small/medium/large target sizes described by each tier', () => {
  const makeChaser = (level) => {
    const world = new World(0, { enzymes: level }, 0);
    world.traits = buildTraits({ enzymes: level });
    world.virus.invuln = 10; // keep the test focused on enzyme damage, not player damage
    const enemy = world.spawnEnemy('chaser');
    enemy.pos = { x: world.virus.pos.x + 10, y: world.virus.pos.y };
    enemy.vel = { x: 0, y: 0 };
    enemy.hp = 78;
    enemy.maxHp = 78;
    world.enemies = [enemy];
    world.updateEnemies(1 / 60);
    return enemy;
  };
  assert.equal(makeChaser(1).hp, 78, 'tier 1 should not digest a medium chaser');
  assert.equal(makeChaser(2).hp, 16, 'tier 2 should deal the documented 62 damage to a chaser');
  assert.equal(makeChaser(3).alive, false, 'tier 3 should digest a chaser in one contact tick');
});

test('focused UI controls do not trigger an accidental gameplay dash', () => {
  const OriginalElement = global.Element;
  class FakeElement {
    closest() { return { interactive: true }; }
  }
  global.Element = FakeElement;
  try {
    const input = new Input();
    const event = {
      key: ' ', target: new FakeElement(), repeat: false, prevented: false,
      preventDefault() { this.prevented = true; },
    };
    input.keyDown(event);
    assert.equal(input.dashQueued, false);
    assert.equal(input.keys.has(' '), false);
    assert.equal(event.prevented, false, 'focused button should keep native Space activation');
  } finally {
    if (OriginalElement === undefined) delete global.Element;
    else global.Element = OriginalElement;
  }
});

test('held dash keys do not auto-queue repeats and blur clears stale input', () => {
  const OriginalElement = global.Element;
  class FakeElement { closest() { return null; } }
  global.Element = FakeElement;
  try {
    const input = new Input();
    const event = (repeat = false) => ({
      key: ' ', target: new FakeElement(), repeat,
      preventDefault() {},
    });
    input.gameInput = true;
    input.keyDown(event(false));
    assert.equal(input.consumeDash(), true, 'first Space keydown queues one dash');
    input.keyDown(event(true));
    assert.equal(input.dashQueued, false, 'OS key-repeat must not queue another dash while held');
    input.dashQueued = true;
    input.pressed.add(' ');
    input.blur();
    assert.equal(input.dashQueued, false, 'losing browser focus cancels a pending dash');
    assert.equal(input.pressed.size, 0, 'losing focus clears one-frame key presses');
    assert.equal(input.keys.size, 0, 'losing focus clears held movement keys');
    assert.equal(input.stick.active, false);
    assert.deepEqual(input.stickVec, { x: 0, y: 0 });
  } finally {
    if (OriginalElement === undefined) delete global.Element;
    else global.Element = OriginalElement;
  }
});

test('Taxis increases DNA score, not DNA quota progress', () => {
  const world = new World(0, { taxis: 1 }, 0);
  world.score = 0;
  world.dna = 0;
  world.dnaTotal = 0;
  world.collected = 0;
  world.combo = 1;
  world.collect({
    kind: 'dna', pos: { ...world.virus.pos }, vel: { x: 0, y: 0 }, r: 9,
    t: 0, alive: true, value: 1, seed: 1,
  });
  assert.equal(world.dna, 1);
  assert.equal(world.dnaTotal, 1);
  assert.equal(world.collected, 1);
  assert.equal(world.score, 17); // combo increments to 1.25 before scoring
});

test('death stops pickup collection and cancels pending mutation', () => {
  const world = new World(0, {}, 0);
  world.virus.hp = 1;
  world.virus.invuln = 0;
  world.pendingEvolve = true;
  world.damagePlayer(10, { x: world.virus.pos.x - 10, y: world.virus.pos.y }, true);
  assert.equal(world.virus.hp, 0);
  assert.ok(world.deathT > 0);
  assert.equal(world.pendingEvolve, false);
  const pickup = {
    kind: 'heal', pos: { ...world.virus.pos }, vel: { x: 0, y: 0 }, r: 14,
    t: 0, alive: true, value: 0, seed: 123,
  };
  world.pickups = [pickup];
  world.update(1 / 60, { x: 0, y: 0 }, 0, false);
  assert.equal(world.virus.hp, 0);
  assert.equal(pickup.alive, true);
});

test('infection animation stops DNA pickup, score and spawn simulation', () => {
  const world = new World(0, {}, 10);
  world.infectT = 1.2;
  const pickup = {
    kind: 'dna', pos: { ...world.virus.pos }, vel: { x: 0, y: 0 }, r: 9,
    t: 0, alive: true, value: 1, seed: 124,
  };
  world.pickups = [pickup];
  const score = world.score;
  const dna = world.dnaTotal;
  const enemyCount = world.enemies.length;
  world.update(0.1, { x: 0, y: 0 }, 0, false);
  assert.equal(world.score, score);
  assert.equal(world.dnaTotal, dna);
  assert.equal(pickup.alive, true);
  assert.equal(world.enemies.length, enemyCount);
  assert.ok(world.infectT < 1.2);
});

test('4,000 generated worlds keep all initial entities in valid geometry across eight stages', () => {
  assert.equal(STAGES.length, 8);
  for (let stageIndex = 0; stageIndex < STAGES.length; stageIndex++) {
    for (let run = 0; run < 500; run++) {
      const world = new World(stageIndex, {}, 0);
      const inBounds = (pos, r) => pos.x >= r && pos.y >= r &&
        pos.x <= world.stage.world.w - r && pos.y <= world.stage.world.h - r;
      const clearOfWalls = (pos, r) => !world.stage.walls.some((wall) => circleRect(pos, r + 1, wall));
      const clearOfAcid = (pos, r) => !world.stage.acids.some((acid) => dist2(pos, acid) < (r + acid.r) ** 2);
      assert.ok(inBounds(world.virus.pos, world.virus.r), `player out of bounds stage ${stageIndex + 1}`);
      assert.ok(clearOfWalls(world.virus.pos, world.virus.r), `player inside wall stage ${stageIndex + 1}`);
      assert.ok(clearOfAcid(world.virus.pos, world.virus.r), `player inside acid stage ${stageIndex + 1}`);
      assert.ok(inBounds(world.target.pos, world.target.r), `target out of bounds stage ${stageIndex + 1}`);
      assert.ok(clearOfWalls(world.target.pos, world.target.r), `target inside wall stage ${stageIndex + 1}`);
      assert.ok(clearOfAcid(world.target.pos, world.target.r), `target inside acid stage ${stageIndex + 1}`);
      for (const pickup of world.pickups) {
        assert.ok(inBounds(pickup.pos, pickup.r), `pickup out of bounds stage ${stageIndex + 1}`);
        assert.ok(clearOfWalls(pickup.pos, pickup.r), `pickup inside wall stage ${stageIndex + 1}`);
        assert.ok(clearOfAcid(pickup.pos, pickup.r), `pickup inside acid stage ${stageIndex + 1}`);
      }
      for (const enemy of world.enemies) {
        assert.ok(inBounds(enemy.pos, enemy.r), `enemy out of bounds stage ${stageIndex + 1}`);
        assert.ok(clearOfWalls(enemy.pos, enemy.r), `enemy inside wall stage ${stageIndex + 1}`);
        assert.ok(clearOfAcid(enemy.pos, enemy.r), `enemy inside acid stage ${stageIndex + 1}`);
      }
      // Explicit child-spawn positions can land beside walls or at map edges;
      // they must be relocated safely rather than trusted verbatim.
      const child = world.spawnEnemy('spore', { x: -500, y: world.stage.world.h + 500 }, 1);
      assert.ok(inBounds(child.pos, child.r), `child out of bounds stage ${stageIndex + 1}`);
      assert.ok(clearOfWalls(child.pos, child.r), `child inside wall stage ${stageIndex + 1}`);
      assert.ok(clearOfAcid(child.pos, child.r), `child inside acid stage ${stageIndex + 1}`);
    }
  }
});

test('seeded combat simulation remains finite across every zone and input pattern', () => {
  const originalRandom = Math.random;
  let seed = 0x51A7E;
  const seededRandom = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 0x100000000;
  };
  Math.random = seededRandom;
  try {
    for (let stageIndex = 0; stageIndex < STAGES.length; stageIndex++) {
      for (let trial = 0; trial < 5; trial++) {
        const starting = trial === 0 ? { flagellum: 3, plating: 2, regen: 1 } : {};
        const world = new World(stageIndex, starting, trial * 100);
        for (let frame = 0; frame < 1_000 && !world.finished; frame++) {
          if (world.pendingEvolve) {
            const choices = world.rollChoices();
            assert.ok(choices.length > 0, `zone ${stageIndex + 1} must offer a mutation when evolution is pending`);
            world.applyMutation(choices[Math.floor(seededRandom() * choices.length)]);
          }
          const angle = seededRandom() * Math.PI * 2;
          const magnitude = seededRandom();
          world.update(1 / 60, { x: Math.cos(angle), y: Math.sin(angle) }, magnitude, seededRandom() < 0.025);
          if (frame % 100 === 0) {
            for (const [name, value] of Object.entries({
              score: world.score, dna: world.dna, dnaTotal: world.dnaTotal, dnaNeeded: world.dnaNeeded,
              time: world.time, hp: world.virus.hp, virusX: world.virus.pos.x, virusY: world.virus.pos.y,
              virusVx: world.virus.vel.x, virusVy: world.virus.vel.y,
            })) assert.ok(Number.isFinite(value), `${name} must remain finite in zone ${stageIndex + 1}, trial ${trial}`);
            for (const entity of [...world.enemies, ...world.pickups, ...world.bullets]) {
              assert.ok(Number.isFinite(entity.pos.x) && Number.isFinite(entity.pos.y),
                `all entity coordinates must stay finite in zone ${stageIndex + 1}`);
            }
          }
        }
        assert.ok(Number.isFinite(world.score) && Number.isFinite(world.time));
      }
    }
  } finally {
    Math.random = originalRandom;
  }
});

test('a baseline dash safely exits a large acid pool without granting combat immunity', () => {
  const world = new World(1, {}, 0);
  const acid = world.stage.acids.find((area) => area.r >= 200);
  assert.ok(acid, 'stage 2 should contain a large acid pool');
  world.virus.pos = { x: acid.x, y: acid.y };
  world.virus.vel = { x: 0, y: 0 };
  world.virus.hp = 100;
  world.virus.invuln = 0;
  world.virus.dashCd = 0;
  world.virus.dashTime = 0;
  world.virus.acidGrace = 0;
  world.acidTick = 0;
  let exited = false;
  for (let frame = 0; frame < 120; frame++) {
    world.updateVirus(1 / 60, { x: 1, y: 0 }, 1, frame === 0);
    const stillInAcid = world.stage.acids.some((area) =>
      dist2(world.virus.pos, area) < area.r * area.r,
    );
    if (!stillInAcid) { exited = true; break; }
  }
  assert.ok(exited, 'dash path should exit the tested acid pool');
  assert.equal(world.virus.hp, 100, 'acid crossing should not drain health');
  world.virus.invuln = 0;
  world.virus.acidGrace = 0.5;
  world.damagePlayer(1, { x: world.virus.pos.x - 1, y: world.virus.pos.y });
  assert.equal(world.virus.hp, 99, 'acid grace must not protect from combat damage');
});

test('mutation choices are unique and statistically uniform over the full pool', () => {
  const world = new World(0, {}, 0);
  const counts = Object.fromEntries(Object.keys(MUTATION_BY_ID).map((id) => [id, 0]));
  const iterations = 120000;
  for (let i = 0; i < iterations; i++) {
    const choices = world.rollChoices();
    assert.equal(choices.length, 3);
    assert.equal(new Set(choices).size, 3);
    for (const id of choices) counts[id]++;
  }
  const expected = iterations * 3 / Object.keys(MUTATION_BY_ID).length;
  for (const [id, count] of Object.entries(counts)) {
    assert.ok(Math.abs(count - expected) < expected * 0.035, `${id}: ${count} vs expected ${expected}`);
  }
});

test('retry restores stage-start levels and totals, not failed-attempt progress', () => {
  const game = Object.create(Game.prototype);
  game.world = { stageIndex: 2, levels: { flagellum: 3, volt: 2 }, score: 999 };
  game.stageStartScore = 400;
  game.stageStartLevels = { cilia: 1 };
  game.stageStartTotals = { dna: 20, kills: 4, time: 55, evolutions: 3 };
  let args;
  game.loadStage = (...values) => { args = values; };
  game.retryStage();
  assert.equal(args[0], 2);
  assert.equal(args[1], 400);
  assert.deepEqual(args[2], { cilia: 1 });
  assert.deepEqual(args[3], { dna: 20, kills: 4, time: 55, evolutions: 3 });
});

test('run statistics aggregate prior sectors plus the current sector exactly once', () => {
  const game = Object.create(Game.prototype);
  game.runTotals = { dna: 20, kills: 5, time: 40, evolutions: 4 };
  game.world = { dnaTotal: 7, kills: 2, time: 12.5, evolutionCount: 1 };
  assert.deepEqual(game.currentRunTotals(), { dna: 27, kills: 7, time: 52.5, evolutions: 5 });
});

test('cleared zones and the next campaign zone are selectable while future zones stay locked', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    storage.delete('virus.campaign-progress.v1');
    assert.equal(campaignSave.canSelectStage(1), true, 'zone 1 must always be available');
    for (let id = 2; id <= 8; id++) assert.equal(campaignSave.canSelectStage(id), false, `zone ${id} starts locked`);

    campaignSave.markStageCompleted(1, { flagellum: 2, cilia: 1 });
    assert.deepEqual(campaignSave.loadCompletedStages(), [1]);
    assert.equal(campaignSave.canSelectStage(1), true);
    assert.equal(campaignSave.canSelectStage(2), true, 'clearing zone 1 unlocks zone 2 before it is beaten');
    assert.equal(campaignSave.canSelectStage(3), false, 'zones beyond the next campaign zone remain locked');
    assert.deepEqual(campaignSave.loadStageLoadout(1), { flagellum: 2, cilia: 1 });

    const game = Object.create(Game.prototype);
    game.result = null;
    game.scores = null;
    game.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    let loadedArgs = null;
    game.loadStage = (...values) => { loadedArgs = values; };
    assert.equal(game.startSelectedStage(3), false, 'engine must reject attempts to start a future locked level');
    assert.equal(game.startSelectedStage(2), true, 'engine must allow the newly unlocked next zone');
    assert.equal(loadedArgs[0], 1);
    assert.deepEqual(loadedArgs[2], { flagellum: 2, cilia: 1 }, "the open frontier inherits the preceding zone's cleared build when no entry record exists yet");
    assert.equal(game.startSelectedStage(1), true);
    assert.equal(loadedArgs[0], 0);
    assert.deepEqual(loadedArgs[2], { flagellum: 2, cilia: 1 });

    campaignSave.markStageCompleted(2, { flagellum: 3 });
    assert.equal(campaignSave.canSelectStage(2), true);
    assert.equal(campaignSave.canSelectStage(3), true, 'clearing zone 2 unlocks zone 3');
    assert.equal(campaignSave.canSelectStage(4), false, 'zone 4 stays locked until zone 3 is cleared');
    campaignSave.markStageCompleted(1, { flagellum: 1 });
    assert.deepEqual(campaignSave.loadStageLoadout(1), { flagellum: 2, cilia: 1 }, 'weaker replay must not replace the best saved loadout');

    const engineSource = fs.readFileSync(require.resolve('../src/game/engine.ts'), 'utf8');
    assert.ok(engineSource.includes('markStageCompleted(w.stage.id, w.levels)'), 'clearing a zone must persist progress and its loadout');
    const shellSource = fs.readFileSync(require.resolve('../src/components/GameShell.tsx'), 'utf8');
    assert.ok(shellSource.includes('<LevelSelect'), 'selector overlay must be integrated into the game shell');
    assert.ok(shellSource.includes('onLevelSelect={openLevelSelect}'), 'selector must be reachable after clearing a level and from results');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('the next campaign zone stays selectable after advancing and later losing on any unlocked frontier', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1',
      'virus.campaign-progress.backup.v1',
      'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);

    campaignSave.markStageCompleted(1, { flagellum: 2 });
    campaignSave.markStageCompleted(2, { cilia: 2, volt: 1 });
    assert.deepEqual(campaignSave.loadCompletedStages(), [1, 2]);
    assert.equal(campaignSave.canSelectStage(1), true);
    assert.equal(campaignSave.canSelectStage(2), true);
    assert.equal(campaignSave.canSelectStage(3), true, 'zone 3 is unlocked by clearing zone 2 even before zone 3 is cleared');
    assert.equal(campaignSave.canSelectStage(4), false, 'zone 4 remains locked until zone 3 is cleared');

    // Reproduce a stale primary save (the kind of state that could make a
    // previously cleared zone look locked). Backup/monotonic keys must win.
    storage.set('virus.campaign-progress.v1', JSON.stringify({ completedStages: [], loadouts: {} }));
    assert.deepEqual(campaignSave.loadCompletedStages(), [1, 2]);
    assert.equal(campaignSave.canSelectStage(1), true, 'zone 1 must remain open after the stale write');
    assert.equal(campaignSave.canSelectStage(2), true, 'zone 2 must remain open after the stale write');
    assert.equal(campaignSave.canSelectStage(3), true, 'zone 3 must remain unlocked after the stale write');

    // Ending a later run in defeat does not alter campaign completion.
    const game = Object.create(Game.prototype);
    game.world = { stageIndex: 2, score: 777, dnaTotal: 4, kills: 3, time: 40, evolutionCount: 1 };
    game.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    game.phase = 'playing';
    game.input = { gameInput: true };
    game.cb = { onPhase() {} };
    game.emit = () => {};
    game.finishRun(false, 777);
    assert.equal(game.phase, 'dead');
    assert.deepEqual(campaignSave.loadCompletedStages(), [1, 2]);
    assert.equal(campaignSave.canSelectStage(1), true);
    assert.equal(campaignSave.canSelectStage(2), true);
    assert.equal(campaignSave.canSelectStage(3), true, 'losing in zone 3 must not re-lock zone 3');
    assert.equal(campaignSave.canSelectStage(4), false, 'zone 4 stays locked until zone 3 is completed');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('level-selection UI derives unlocked state from the completed zone frontier', () => {
  const overlays = fs.readFileSync(require.resolve('../src/components/Overlays.tsx'), 'utf8');
  const saveSource = fs.readFileSync(require.resolve('../src/game/save.ts'), 'utf8');
  assert.ok(overlays.includes('isStageUnlocked, PERMANENT_UPGRADE_DEFS'), 'level selector and permanent-upgrade shop share the save module');
  assert.ok(overlays.includes('STAGES.filter((stage) => isStageUnlocked(stage.id, completedStages))'),
    'available-zone count must include the next unlocked zone');
  assert.ok(overlays.includes('const isAvailable = isStageUnlocked(stage.id, completedStages)'),
    'each zone card must use the same unlock policy as the engine');
  assert.ok(saveSource.includes('return stageId <= frontier'),
    'only the contiguous cleared prefix and the next frontier may be selected');
});

test('campaign unlock frontier advances exactly one zone at a time through all eight zones', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1',
      'virus.campaign-progress.backup.v1',
      'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);

    assert.deepEqual(Array.from({ length: 8 }, (_, i) => campaignSave.canSelectStage(i + 1)),
      [true, false, false, false, false, false, false, false]);

    for (let cleared = 1; cleared <= 8; cleared++) {
      campaignSave.markStageCompleted(cleared, { flagellum: Math.min(3, cleared % 4 + 1) });
      for (let id = 1; id <= 8; id++) {
        const expected = id <= Math.min(8, cleared + 1);
        assert.equal(campaignSave.canSelectStage(id), expected,
          `after clearing zone ${cleared}, zone ${id} should be ${expected ? 'unlocked' : 'locked'}`);
      }
      // A defeat in the currently opened frontier does not change what is unlocked.
      const beforeLoss = Array.from({ length: 8 }, (_, i) => campaignSave.canSelectStage(i + 1));
      const game = Object.create(Game.prototype);
      game.world = { stageIndex: Math.min(cleared, 7), score: 500, dnaTotal: 2, kills: 1, time: 8, evolutionCount: 0 };
      game.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
      game.phase = 'playing';
      game.input = { gameInput: true };
      game.cb = { onPhase() {} };
      game.emit = () => {};
      game.finishRun(false, 500);
      assert.deepEqual(Array.from({ length: 8 }, (_, i) => campaignSave.canSelectStage(i + 1)), beforeLoss,
        `defeat after clearing zone ${cleared} must not change unlock state`);
    }

    assert.equal(campaignSave.canSelectStage(8), true, 'final zone should be unlocked after clearing zone 7');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('active campaign checkpoint persists, validates unlocks, and resumes the last zone entry', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);

    assert.equal(campaignSave.saveActiveRunCheckpoint({
      stageId: 3, score: 700, levels: { flagellum: 2 },
      totals: { dna: 10, kills: 5, time: 42, evolutions: 3 },
    }), false, 'future zones cannot be checkpointed while locked');

    campaignSave.markStageCompleted(1, { flagellum: 2 });
    campaignSave.markStageCompleted(2, { flagellum: 2, cilia: 1 });
    assert.equal(campaignSave.saveActiveRunCheckpoint({
      stageId: 3, score: 700, levels: { flagellum: 2, cilia: 1 },
      totals: { dna: 10, kills: 5, time: 42, evolutions: 3 },
    }), true);
    const checkpoint = campaignSave.loadActiveRunCheckpoint();
    assert.deepEqual(checkpoint && {
      stageId: checkpoint.stageId, score: checkpoint.score, levels: checkpoint.levels, totals: checkpoint.totals,
    }, {
      stageId: 3, score: 700, levels: { flagellum: 2, cilia: 1 },
      totals: { dna: 10, kills: 5, time: 42, evolutions: 3 },
    });

    let loadedArgs = null;
    const game = Object.create(Game.prototype);
    game.result = null;
    game.scores = null;
    game.loadStage = (...args) => { loadedArgs = args; };
    assert.equal(game.continueRun(), true);
    assert.equal(loadedArgs[0], 2, 'continue starts at the saved zone, not at zone 1');
    assert.equal(loadedArgs[1], 700);
    assert.deepEqual(loadedArgs[2], { flagellum: 2, cilia: 1 });
    assert.deepEqual(loadedArgs[3], { dna: 10, kills: 5, time: 42, evolutions: 3 });

    // Corrupt primary checkpoint: the independent backup can restore it.
    storage.set('virus.active-run.v1', '{broken');
    assert.equal(campaignSave.loadActiveRunCheckpoint()?.stageId, 3);
    campaignSave.clearActiveRunCheckpoint();
    assert.equal(campaignSave.loadActiveRunCheckpoint(), null);
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('standalone level replay does not overwrite or clear a suspended campaign checkpoint', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);
    campaignSave.markStageCompleted(1, { flagellum: 2 });
    assert.equal(campaignSave.saveActiveRunCheckpoint({
      stageId: 2, score: 321, levels: { flagellum: 2 }, totals: { dna: 4, kills: 2, time: 13, evolutions: 1 },
    }), true);
    const before = storage.get('virus.active-run.v1');

    const game = Object.create(Game.prototype);
    game.result = null;
    game.scores = null;
    game.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    game.loadStage = () => {};
    assert.equal(game.startSelectedStage(1), true);
    assert.equal(game.runMode, 'replay');
    assert.equal(storage.get('virus.active-run.v1'), before);
    assert.equal(campaignSave.loadActiveRunCheckpoint()?.stageId, 2);
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('zone-entry mutation builds survive defeat and are restored when replaying the open frontier', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);

    campaignSave.markStageCompleted(1, { flagellum: 2, cilia: 1 });
    // First entry into zone 2 inherits the zone-1 build and is saved separately
    // from the strongest post-clear loadout.
    campaignSave.saveStageEntryBuild(2, { flagellum: 2, cilia: 1 });
    assert.deepEqual(campaignSave.loadStageEntryBuild(2), { flagellum: 2, cilia: 1 });
    assert.deepEqual(campaignSave.loadStageLoadout(2), {}, 'entry build and completion build are distinct records');

    campaignSave.saveActiveRunCheckpoint({
      stageId: 2, score: 300, levels: { flagellum: 2, cilia: 1 },
      totals: { dna: 8, kills: 3, time: 15, evolutions: 2 },
    });
    const defeated = Object.create(Game.prototype);
    defeated.world = { stageIndex: 1, score: 300, stage: { id: 2 }, dnaTotal: 0, kills: 0, time: 0, evolutionCount: 0 };
    defeated.runTotals = { dna: 8, kills: 3, time: 15, evolutions: 2 };
    defeated.runMode = 'campaign';
    defeated.result = null;
    defeated.scores = null;
    defeated.phase = 'playing';
    defeated.input = { gameInput: true };
    defeated.cb = { onPhase() {} };
    defeated.emit = () => {};
    defeated.finishRun(false, 300);
    assert.equal(campaignSave.loadActiveRunCheckpoint(), null, 'failed run checkpoint is ended');
    assert.equal(campaignSave.canSelectStage(2), true, 'the opened frontier remains selectable');
    assert.deepEqual(campaignSave.loadStageEntryBuild(2), { flagellum: 2, cilia: 1 }, 'zone entry build survives defeat');

    let loaded = null;
    const replay = Object.create(Game.prototype);
    replay.result = null;
    replay.scores = null;
    replay.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    replay.loadStage = (...args) => { loaded = args; };
    assert.equal(replay.startSelectedStage(2), true);
    assert.deepEqual(loaded[2], { flagellum: 2, cilia: 1 }, 'replay starts with the saved entry build');
    assert.equal(replay.runMode, 'replay');

    // A weaker later campaign entry cannot overwrite the recorded best entry build.
    campaignSave.saveStageEntryBuild(2, { flagellum: 1 });
    assert.deepEqual(campaignSave.loadStageEntryBuild(2), { flagellum: 2, cilia: 1 });
    const engineSource = fs.readFileSync(require.resolve('../src/game/engine.ts'), 'utf8');
    assert.ok(engineSource.includes('saveStageEntryBuild(this.world.stage.id, this.stageStartLevels)'),
      'campaign zone entry must persist its build');
    assert.ok(engineSource.includes('const stageLevels = loadStageEntryBuild(stageId)'),
      'level selector must restore the zone entry build');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('campaign defeat clears only the run checkpoint; replay defeat preserves the suspended campaign', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
      'virus.highscores.v1',
    ]) storage.delete(key);
    campaignSave.markStageCompleted(1, { flagellum: 1 });
    campaignSave.saveActiveRunCheckpoint({
      stageId: 2, score: 200, levels: { flagellum: 1 }, totals: { dna: 1, kills: 2, time: 3, evolutions: 1 },
    });

    const campaign = Object.create(Game.prototype);
    campaign.world = { stageIndex: 1, score: 200, stage: { id: 2 }, dnaTotal: 1, kills: 2, time: 3, evolutionCount: 1 };
    campaign.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    campaign.runMode = 'campaign';
    campaign.result = null;
    campaign.scores = null;
    campaign.phase = 'playing';
    campaign.input = { gameInput: true };
    campaign.cb = { onPhase() {} };
    campaign.emit = () => {};
    campaign.finishRun(false, 200);
    assert.equal(campaignSave.loadActiveRunCheckpoint(), null, 'a defeated campaign run is ended');
    assert.equal(campaignSave.canSelectStage(2), true, 'defeat must not revoke the unlocked zone');

    campaignSave.saveActiveRunCheckpoint({
      stageId: 2, score: 200, levels: { flagellum: 1 }, totals: { dna: 1, kills: 2, time: 3, evolutions: 1 },
    });
    const replay = Object.create(Game.prototype);
    replay.world = { stageIndex: 0, score: 80, stage: { id: 1 }, dnaTotal: 1, kills: 1, time: 2, evolutionCount: 0 };
    replay.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    replay.runMode = 'replay';
    replay.result = null;
    replay.scores = null;
    replay.phase = 'playing';
    replay.input = { gameInput: true };
    replay.cb = { onPhase() {} };
    replay.emit = () => {};
    replay.finishRun(false, 80);
    assert.equal(campaignSave.loadActiveRunCheckpoint()?.stageId, 2, 'replay must not clear the suspended campaign');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('permanent evolution earns essence once per first clear and purchases persist', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);

    assert.equal(campaignSave.loadMetaProgress().essence, 0);
    campaignSave.markStageCompleted(1, { flagellum: 1 });
    assert.equal(campaignSave.loadMetaProgress().essence, 5, 'first clear grants 5 essence');
    campaignSave.markStageCompleted(1, { flagellum: 3 });
    assert.equal(campaignSave.loadMetaProgress().essence, 5, 'replaying a cleared stage cannot farm essence');

    let purchase = campaignSave.buyPermanentUpgrade('vitality');
    assert.equal(purchase.ok, true);
    assert.equal(purchase.progress.essence, 3);
    assert.equal(purchase.progress.upgrades.vitality, 1);
    purchase = campaignSave.buyPermanentUpgrade('mobility');
    assert.equal(purchase.ok, true);
    assert.equal(purchase.progress.essence, 1);
    purchase = campaignSave.buyPermanentUpgrade('harvest');
    assert.equal(purchase.ok, false, 'insufficient essence must not buy an upgrade');
    assert.equal(campaignSave.loadMetaProgress().upgrades.harvest, 0);

    campaignSave.markStageCompleted(2, { cilia: 1 });
    assert.equal(campaignSave.loadMetaProgress().essence, 6, 'the first clear of a different zone grants one reward');
    for (let n = 0; n < 10; n++) {
      const attempt = campaignSave.buyPermanentUpgrade('vitality');
      if (!attempt.ok) break;
    }
    const saved = campaignSave.loadMetaProgress();
    assert.equal(saved.upgrades.vitality, 2, 'upgrade ranks persist and cannot exceed available essence');
    assert.equal(saved.rewardedStages.includes(1), true);
    assert.equal(saved.rewardedStages.includes(2), true);
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('permanent upgrades are applied by actual World instances at zone creation', () => {
  const base = new World(0, { flagellum: 1 }, 0);
  const upgraded = new World(0, { flagellum: 1 }, 0, { vitality: 2, mobility: 2, harvest: 2 });
  assert.equal(upgraded.traits.maxHp, base.traits.maxHp + 16);
  approx(upgraded.traits.speed, base.traits.speed * 1.08);
  approx(upgraded.traits.dnaValue, base.traits.dnaValue * 1.1);
  assert.equal(upgraded.virus.hp, upgraded.traits.maxHp, 'new world starts at upgraded max HP');
  assert.deepEqual(upgraded.levels, base.levels, 'permanent ranks do not pollute temporary mutation levels');
});

test('permanent upgrades apply as small deterministic bonuses without changing temporary mutation levels', () => {
  const base = buildTraits({});
  const vitality = buildTraits({}, { vitality: 1 });
  const mobility = buildTraits({}, { mobility: 1 });
  const harvest = buildTraits({}, { harvest: 1 });
  assert.equal(vitality.maxHp, base.maxHp + 8);
  approx(mobility.speed, base.speed * 1.04);
  approx(harvest.dnaValue, base.dnaValue * 1.05);
  assert.deepEqual(
    buildTraits(levelsA, { vitality: 2, mobility: 3, harvest: 1 }),
    buildTraits(levelsB, { vitality: 2, mobility: 3, harvest: 1 }),
    'permanent bonuses should not make the order of temporary mutations matter',
  );
});

test('fresh-run start cannot silently overwrite an available campaign checkpoint', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);
    assert.equal(campaignSave.saveActiveRunCheckpoint({
      stageId: 1, score: 0, levels: {}, totals: { dna: 0, kills: 0, time: 0, evolutions: 0 },
    }), true);
    const before = storage.get('virus.active-run.v1');
    const game = Object.create(Game.prototype);
    game.result = null;
    game.scores = null;
    game.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    game.loadStage = () => { throw new Error('should not start without explicit replace confirmation'); };
    assert.equal(game.startRun(), false);
    assert.equal(storage.get('virus.active-run.v1'), before);
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('eight first clears grant enough essence for all nine permanent upgrade ranks', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);
    for (let stageId = 1; stageId <= 8; stageId++) campaignSave.markStageCompleted(stageId, {});
    assert.equal(campaignSave.loadMetaProgress().essence, 40);
    for (const id of ['vitality', 'mobility', 'harvest']) {
      for (let rank = 1; rank <= 3; rank++) assert.equal(campaignSave.buyPermanentUpgrade(id).ok, true, `${id} rank ${rank} should be affordable`);
    }
    const final = campaignSave.loadMetaProgress();
    assert.deepEqual(final.upgrades, { vitality: 3, mobility: 3, harvest: 3 });
    assert.equal(final.essence, 4, 'the full upgrade tree costs 36 of 40 essence');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('main menu exposes continue checkpoint and permanent evolution controls', () => {
  const overlays = fs.readFileSync(require.resolve('../src/components/Overlays.tsx'), 'utf8');
  const shell = fs.readFileSync(require.resolve('../src/components/GameShell.tsx'), 'utf8');
  assert.ok(overlays.includes('↻ ПРОДОЛЖИТЬ ЗАБЕГ'));
  assert.ok(overlays.includes('ПОСТОЯННАЯ ЭВОЛЮЦИЯ'));
  assert.ok(overlays.includes('Эссенция выдаётся один раз за первое прохождение каждой зоны'));
  assert.ok(shell.includes('onContinue={continueRun}'));
  assert.ok(shell.includes('onPermanentEvolution={openPermanentShop}'));
  assert.equal(shell.includes('saveActiveRunCheckpoint'), false, 'checkpoint persistence belongs to the engine, not the React shell');
});

test('the engine confirm adapter cannot advance a clear screen twice', () => {
  const game = Object.create(Game.prototype);
  game.phase = 'clear';
  let advances = 0;
  game.nextStage = () => { advances++; };
  game.handleEvent('confirm');
  assert.equal(advances, 0, 'the shared UI handler is the single owner of clear-screen advancement');
});

test('meta progression repairs lost first-clear reward records without allowing reward farming', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (let stageId = 1; stageId <= 3; stageId++) campaignSave.markStageCompleted(stageId, { flagellum: stageId });
    // Simulate a partially restored metadata save: the campaign and reward marker
    // only remember zone 1 although the campaign history records zones 1-3.
    const staleMeta = {
      essence: 5,
      upgrades: { vitality: 0, mobility: 0, harvest: 0 },
      rewardedStages: [1],
      revision: 20,
    };
    storage.set('virus.meta-progress.v1', JSON.stringify(staleMeta));
    storage.set('virus.meta-progress.backup.v1', JSON.stringify({ ...staleMeta, revision: 19 }));
    storage.set('virus.meta-rewarded-stages.v1', JSON.stringify([1]));
    storage.set('virus.completed-stages.v1', JSON.stringify([1, 2, 3]));

    const repaired = campaignSave.loadMetaProgress();
    assert.equal(repaired.essence, 15, 'missing rewards for zones 2 and 3 are restored once');
    assert.deepEqual(repaired.rewardedStages, [1, 2, 3]);
    assert.equal(campaignSave.loadMetaProgress().essence, 15, 'a second load must not grant duplicate essence');
    campaignSave.markStageCompleted(2, { flagellum: 3 });
    assert.equal(campaignSave.loadMetaProgress().essence, 15, 'replaying a completed zone cannot farm repaired rewards');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('first-clear essence is recoverable when both meta writes fail but campaign save succeeds', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  const failWrite = new Set();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) {
      if (failWrite.has(key)) throw new Error(`simulated write failure: ${key}`);
      storage.set(key, String(value));
    },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.active-run-epoch.v1', 'virus.active-run-epoch.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);

    campaignSave.markStageCompleted(1, { flagellum: 1 });
    assert.equal(campaignSave.loadMetaProgress().essence, 5);
    // Fail only meta writes while the second zone is cleared. The campaign
    // completion is saved, but a standalone marker must not get ahead of meta.
    failWrite.add('virus.meta-progress.v1');
    failWrite.add('virus.meta-progress.backup.v1');
    campaignSave.markStageCompleted(2, { cilia: 1 });
    assert.deepEqual(campaignSave.loadCompletedStages(), [1, 2]);
    assert.deepEqual(JSON.parse(storage.get('virus.meta-rewarded-stages.v1')), [1],
      'reward marker must not advance when neither metadata copy was written');

    failWrite.clear();
    const recovered = campaignSave.loadMetaProgress();
    assert.equal(recovered.essence, 10, 'zone 2 reward is recovered from saved campaign history');
    assert.deepEqual(recovered.rewardedStages, [1, 2]);
    assert.equal(campaignSave.loadMetaProgress().essence, 10, 'recovery is durable and not duplicated on a second load');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('campaign progress and checkpoints recover when one redundant storage write fails', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  const failKeys = new Set(['virus.campaign-progress.v1', 'virus.active-run.v1', 'virus.meta-progress.v1']);
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) {
      if (failKeys.has(key)) throw new Error(`simulated storage failure: ${key}`);
      storage.set(key, String(value));
    },
    removeItem(key) { storage.delete(key); },
  };
  try {
    campaignSave.markStageCompleted(1, { cilia: 2 });
    assert.deepEqual(campaignSave.loadCompletedStages(), [1], 'backup/monotonic completion copy keeps zone history');
    assert.equal(campaignSave.canSelectStage(2), true, 'one failed campaign write must not re-lock next zone');
    assert.equal(campaignSave.saveActiveRunCheckpoint({
      stageId: 2, score: 125, levels: { cilia: 2 },
      totals: { dna: 5, kills: 2, time: 10, evolutions: 1 },
    }), true, 'checkpoint save succeeds via backup when primary write fails');
    const checkpoint = campaignSave.loadActiveRunCheckpoint();
    assert.equal(checkpoint?.stageId, 2);
    assert.equal(checkpoint?.score, 125);
    const purchase = campaignSave.buyPermanentUpgrade('vitality');
    assert.equal(purchase.ok, true, 'meta upgrade persists via backup when primary write fails');
    assert.equal(campaignSave.loadMetaProgress().upgrades.vitality, 1);
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('single-key storage failures do not lose campaign, essence, or checkpoint progress', () => {
  const originalStorage = global.localStorage;
  const writeKeys = [
    'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
    'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
  ];
  try {
    for (const failedKey of writeKeys) {
      const storage = new Map();
      global.localStorage = {
        getItem(key) { return storage.has(key) ? storage.get(key) : null; },
        setItem(key, value) {
          if (key === failedKey) throw new Error(`simulated write failure: ${key}`);
          storage.set(key, String(value));
        },
        removeItem(key) { storage.delete(key); },
      };
      campaignSave.markStageCompleted(1, { flagellum: 1 });
      assert.deepEqual(campaignSave.loadCompletedStages(), [1],
        `campaign completion must survive failing ${failedKey}`);
      assert.equal(campaignSave.canSelectStage(2), true,
        `the next zone must remain unlocked when ${failedKey} fails`);
      assert.equal(campaignSave.loadMetaProgress().essence, 5,
        `first-clear essence must survive failing ${failedKey}`);
      assert.deepEqual(campaignSave.loadMetaProgress().rewardedStages, [1]);
    }

    for (const failedKey of ['virus.active-run.v1', 'virus.active-run.backup.v1']) {
      const storage = new Map();
      global.localStorage = {
        getItem(key) { return storage.has(key) ? storage.get(key) : null; },
        setItem(key, value) {
          if (key === failedKey) throw new Error(`simulated write failure: ${key}`);
          storage.set(key, String(value));
        },
        removeItem(key) { storage.delete(key); },
      };
      const saved = campaignSave.saveActiveRunCheckpoint({
        stageId: 1, score: 222, levels: { cilia: 2 },
        totals: { dna: 5, kills: 4, time: 12.5, evolutions: 1 },
      });
      assert.equal(saved, true, `checkpoint should persist through the other copy when ${failedKey} fails`);
      assert.equal(campaignSave.loadActiveRunCheckpoint()?.score, 222);
    }
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('checkpoint invalidation survives a failed removeItem and a later run replaces it safely', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  const failRemove = new Set();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) {
      if (failRemove.has(key)) throw new Error(`simulated remove failure: ${key}`);
      storage.delete(key);
    },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.active-run-epoch.v1', 'virus.active-run-epoch.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);
    const initial = {
      stageId: 1, score: 10, levels: { flagellum: 1 },
      totals: { dna: 2, kills: 1, time: 3, evolutions: 1 },
    };
    assert.equal(campaignSave.saveActiveRunCheckpoint(initial), true);
    const stale = JSON.parse(storage.get('virus.active-run.v1'));
    assert.equal(stale.generation, 0);
    failRemove.add('virus.active-run.v1');
    failRemove.add('virus.active-run.backup.v1');
    campaignSave.clearActiveRunCheckpoint();
    assert.ok(storage.has('virus.active-run.v1'), 'simulate an old primary checkpoint that could not be removed');
    assert.ok(storage.has('virus.active-run.backup.v1'), 'simulate an old backup checkpoint that could not be removed');
    assert.equal(campaignSave.loadActiveRunCheckpoint(), null,
      'generation tombstone must invalidate both stale copies even when both removeItem calls fail');

    failRemove.clear();
    const fresh = { ...initial, score: 99, levels: { flagellum: 2 } };
    assert.equal(campaignSave.saveActiveRunCheckpoint(fresh), true);
    const restored = campaignSave.loadActiveRunCheckpoint();
    assert.equal(restored?.score, 99, 'a checkpoint saved after the tombstone is valid');
    assert.equal(restored?.generation, 1, 'new checkpoint uses the current generation');
    assert.deepEqual(restored?.levels, { flagellum: 2 });
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('redundant checkpoint generation tombstone works when its primary write fails', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  const failRemove = new Set(['virus.active-run.v1', 'virus.active-run.backup.v1']);
  const failWrite = new Set(['virus.active-run-epoch.v1']);
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) {
      if (failWrite.has(key)) throw new Error(`simulated write failure: ${key}`);
      storage.set(key, String(value));
    },
    removeItem(key) {
      if (failRemove.has(key)) throw new Error(`simulated remove failure: ${key}`);
      storage.delete(key);
    },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.active-run-epoch.v1', 'virus.active-run-epoch.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);
    assert.equal(campaignSave.saveActiveRunCheckpoint({
      stageId: 1, score: 3, levels: {}, totals: { dna: 0, kills: 0, time: 0, evolutions: 0 },
    }), true);
    campaignSave.clearActiveRunCheckpoint();
    assert.equal(storage.get('virus.active-run-epoch.backup.v1'), '1', 'backup generation marker should persist independently');
    assert.equal(campaignSave.loadActiveRunCheckpoint(), null,
      'the backup tombstone invalidates stale checkpoint copies when primary marker write fails');
    failRemove.clear();
    failWrite.clear();
    assert.equal(campaignSave.saveActiveRunCheckpoint({
      stageId: 1, score: 77, levels: { cilia: 1 }, totals: { dna: 4, kills: 1, time: 6, evolutions: 1 },
    }), true);
    assert.equal(campaignSave.loadActiveRunCheckpoint()?.score, 77,
      'a new generation can be saved and loaded after the invalidation');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('open-frontier entry builds survive defeat across all eight levels', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.active-run-epoch.v1', 'virus.active-run-epoch.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);

    for (let stageId = 1; stageId <= 8; stageId++) {
      if (stageId > 1) campaignSave.markStageCompleted(stageId - 1, { flagellum: Math.min(3, stageId - 1) });
      const entryBuild = { flagellum: Math.min(3, stageId % 3 + 1), cilia: stageId % 2 ? 1 : 2 };
      assert.equal(campaignSave.canSelectStage(stageId), true, `zone ${stageId} should be open before entry`);
      campaignSave.saveStageEntryBuild(stageId, entryBuild);
      assert.deepEqual(campaignSave.loadStageEntryBuild(stageId), entryBuild,
        `zone ${stageId} must preserve the entry build independently`);
      assert.equal(campaignSave.saveActiveRunCheckpoint({
        stageId, score: stageId * 10, levels: entryBuild,
        totals: { dna: stageId, kills: stageId * 2, time: stageId * 10, evolutions: stageId },
      }), true);

      const game = Object.create(Game.prototype);
      game.world = {
        stageIndex: stageId - 1, stage: { id: stageId }, score: stageId * 10,
        dnaTotal: stageId, kills: stageId * 2, time: stageId * 10, evolutionCount: stageId,
      };
      game.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
      game.runMode = 'campaign';
      game.result = null;
      game.scores = null;
      game.phase = 'playing';
      game.input = { gameInput: true };
      game.cb = { onPhase() {} };
      game.emit = () => {};
      game.finishRun(false, stageId * 10);

      assert.equal(campaignSave.canSelectStage(stageId), true,
        `zone ${stageId} must stay open after losing there`);
      assert.deepEqual(campaignSave.loadStageEntryBuild(stageId), entryBuild,
        `zone ${stageId} entry mutations must survive defeat`);
      assert.equal(campaignSave.loadActiveRunCheckpoint(), null,
        `failed run ${stageId} should not leave a Continue checkpoint`);
    }
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('invalid newest checkpoint is ignored in favor of an older valid backup', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.active-run-epoch.v1', 'virus.active-run-epoch.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);
    campaignSave.markStageCompleted(1, { flagellum: 1 });
    assert.equal(campaignSave.saveActiveRunCheckpoint({
      stageId: 2, score: 123, levels: { flagellum: 1 },
      totals: { dna: 2, kills: 3, time: 4, evolutions: 1 },
    }), true);
    const backup = JSON.parse(storage.get('virus.active-run.backup.v1'));
    storage.set('virus.active-run.v1', JSON.stringify({
      ...backup, stageId: 8, score: 999, savedAt: backup.savedAt + 1000,
    }));
    const restored = campaignSave.loadActiveRunCheckpoint();
    assert.equal(restored?.stageId, 2,
      'a newer checkpoint for a locked zone must not mask the valid backup');
    assert.equal(restored?.score, 123);
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('real Game engine saves a clear transition, resumes it after reload, and isolates replay', () => {
  const originalStorage = global.localStorage;
  const originalWindow = global.window;
  const originalDocument = global.document;
  const originalRaf = global.requestAnimationFrame;
  const originalCancelRaf = global.cancelAnimationFrame;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  const eventTarget = { addEventListener() {}, removeEventListener() {} };
  global.window = { ...eventTarget, devicePixelRatio: 1, matchMedia: () => ({ matches: false }) };
  global.document = { ...eventTarget, hidden: false };
  global.requestAnimationFrame = () => 1;
  global.cancelAnimationFrame = () => {};
  const makeGame = () => new Game(
    { ...eventTarget, style: {}, getContext: () => ({}), width: 0, height: 0 },
    { getBoundingClientRect: () => ({ width: 800, height: 600 }) },
    { onHud() {}, onPhase() {} },
  );
  const games = [];
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.active-run-epoch.v1', 'virus.active-run-epoch.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
      'virus.highscores.v1',
    ]) storage.delete(key);

    const campaign = makeGame();
    games.push(campaign);
    campaign.render = () => {};
    assert.equal(campaign.startRun(), true);
    campaign.beginStage();
    campaign.world.levels.flagellum = 2;
    campaign.world.score = 500;
    campaign.world.dnaTotal = 4;
    campaign.world.kills = 3;
    campaign.world.time = 20;
    campaign.world.evolutionCount = 2;
    campaign.runTotals = { dna: 5, kills: 2, time: 10, evolutions: 1 };
    campaign.world.update = () => { campaign.world.finished = 'clear'; };
    campaign.tick(100);
    assert.equal(campaign.currentPhase, 'clear', 'real engine should enter the clear phase');
    assert.deepEqual(campaignSave.loadCompletedStages(), [1], 'the actual clear event should commit zone 1');
    const checkpoint = campaignSave.loadActiveRunCheckpoint();
    assert.equal(checkpoint?.stageId, 2, 'the actual clear event should prepare the next zone checkpoint');
    assert.equal(checkpoint?.score, 500);
    assert.deepEqual(checkpoint?.levels, { flagellum: 2 });
    assert.deepEqual(checkpoint?.totals, { dna: 9, kills: 5, time: 30, evolutions: 3 });

    const continued = makeGame();
    games.push(continued);
    continued.render = () => {};
    assert.equal(continued.continueRun(), true, 'new engine instance should resume the saved checkpoint');
    assert.equal(continued.world?.stage.id, 2);
    assert.equal(continued.world?.score, 500);
    assert.deepEqual(continued.world?.levels, { flagellum: 2 });
    assert.equal(continued.currentPhase, 'briefing', 'resume intentionally starts at the zone briefing');
    const suspendedCheckpoint = campaignSave.loadActiveRunCheckpoint();
    assert.equal(suspendedCheckpoint?.stageId, 2);

    const replay = makeGame();
    games.push(replay);
    replay.render = () => {};
    assert.equal(replay.startSelectedStage(1), true, 'cleared zone should start as a replay');
    assert.equal(replay.world?.stage.id, 1);
    assert.equal(replay.runMode, 'replay');
    assert.deepEqual(campaignSave.loadActiveRunCheckpoint(), suspendedCheckpoint,
      'real replay-stage load must not write over the suspended campaign checkpoint');
    replay.finishRun(false, 99);
    assert.deepEqual(campaignSave.loadActiveRunCheckpoint(), suspendedCheckpoint,
      'real replay defeat must leave the suspended campaign checkpoint intact');
  } finally {
    for (const game of games) game.destroy();
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
    if (originalWindow === undefined) delete global.window;
    else global.window = originalWindow;
    if (originalDocument === undefined) delete global.document;
    else global.document = originalDocument;
    if (originalRaf === undefined) delete global.requestAnimationFrame;
    else global.requestAnimationFrame = originalRaf;
    if (originalCancelRaf === undefined) delete global.cancelAnimationFrame;
    else global.cancelAnimationFrame = originalCancelRaf;
  }
});

test('legacy saves migrate already-cleared zones into one-time essence rewards', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);
    const oldProgress = { completedStages: [1, 2, 3], loadouts: { '1': { flagellum: 1 } } };
    storage.set('virus.campaign-progress.v1', JSON.stringify(oldProgress));
    storage.set('virus.campaign-progress.backup.v1', JSON.stringify(oldProgress));
    storage.set('virus.completed-stages.v1', JSON.stringify([1, 2, 3]));
    const migrated = campaignSave.loadMetaProgress();
    assert.equal(migrated.essence, 15, 'old completed zones receive the first-clear reward during migration');
    assert.deepEqual(migrated.rewardedStages, [1, 2, 3]);
    campaignSave.markStageCompleted(2, { flagellum: 2 });
    assert.equal(campaignSave.loadMetaProgress().essence, 15, 'replaying a legacy-cleared zone cannot duplicate migrated rewards');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('corrupted high-score entries are filtered before sorting and display', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    const good = { score: 420, stage: 2, victory: false, evolutions: 3, date: '2026-10-29' };
    storage.set('virus.highscores.v1', JSON.stringify([
      good,
      { ...good, score: null },
      { ...good, score: 1e300 },
      { ...good, score: -10 },
      { ...good, stage: 88 },
      { ...good, victory: 'yes' },
      { ...good, evolutions: Infinity },
      { ...good, date: 'not-a-date' },
      { ...good, date: '2026-02-31' },
      { ...good, date: '2026-13-01' },
      null,
      'not an entry',
    ]));
    assert.deepEqual(campaignSave.loadScores(), [good], 'only well-formed finite score entries survive');
    const saved = campaignSave.saveScore({ score: 512, stage: 7, victory: true, evolutions: 8, date: '2026-10-29' });
    assert.equal(saved[0].score, 512);
    assert.equal(saved.length, 2);
    assert.ok(saved.every((entry) => Number.isSafeInteger(entry.score) && entry.stage >= 0 && entry.stage <= 7));
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('malformed high metadata revision cannot outrank a healthy backup', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    campaignSave.markStageCompleted(1, { flagellum: 1 });
    storage.set('virus.meta-progress.v1', JSON.stringify({
      essence: 999999999999999999999999, revision: 1e300,
      upgrades: { vitality: 3 }, rewardedStages: [1],
    }));
    storage.set('virus.meta-progress.backup.v1', JSON.stringify({
      essence: 3, revision: 7,
      upgrades: { vitality: 1, mobility: 0, harvest: 0 }, rewardedStages: [1],
    }));
    storage.set('virus.meta-rewarded-stages.v1', JSON.stringify([1]));
    const loaded = campaignSave.loadMetaProgress();
    assert.equal(loaded.essence, 3, 'healthy backup wins over a malformed oversized primary');
    assert.equal(loaded.revision, 7);
    assert.equal(loaded.upgrades.vitality, 1);
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('corrupted completion gaps cannot unlock impossible zones or grant unreachable clears', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    const gapSave = JSON.stringify({ completedStages: [1, 3, 8], loadouts: { '3': { flagellum: 3 } } });
    storage.set('virus.campaign-progress.v1', gapSave);
    storage.set('virus.campaign-progress.backup.v1', gapSave);
    storage.set('virus.completed-stages.v1', JSON.stringify([1, 3, 8]));
    assert.deepEqual(campaignSave.loadCompletedStages(), [1], 'non-contiguous completion history is normalized to its reachable prefix');
    assert.equal(campaignSave.canSelectStage(1), true);
    assert.equal(campaignSave.canSelectStage(2), true, 'the current frontier following zone 1 stays open');
    for (const id of [3, 4, 5, 6, 7, 8]) {
      assert.equal(campaignSave.canSelectStage(id), false, `zone ${id} must remain locked across a corrupted history gap`);
    }
    campaignSave.markStageCompleted(3, { flagellum: 3 });
    assert.deepEqual(campaignSave.loadCompletedStages(), [1], 'the save API must reject completion of an unreachable zone');
    assert.equal(campaignSave.loadMetaProgress().essence, 5, 'unreachable corrupted zones must not create first-clear currency');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('checkpoint timestamps, generation and score are validated independently', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    campaignSave.markStageCompleted(1, { flagellum: 1 });
    storage.set('virus.active-run-epoch.v1', '7');
    storage.set('virus.active-run-epoch.backup.v1', '7');
    const now = Date.now();
    const valid = { stageId: 2, score: 200, levels: { flagellum: 1 }, totals: { dna: 2, kills: 1, time: 5, evolutions: 1 }, generation: 7, savedAt: now - 1000 };
    storage.set('virus.active-run.backup.v1', JSON.stringify(valid));
    storage.set('virus.active-run.v1', JSON.stringify({ ...valid, score: Number.MAX_VALUE, generation: 99, savedAt: Number.MAX_VALUE }));
    const loaded = campaignSave.loadActiveRunCheckpoint();
    assert.equal(loaded?.score, 200, 'invalid newest checkpoint must not mask a valid backup');
    assert.equal(loaded?.generation, 7, 'checkpoint generation must exactly match the active generation');
    assert.equal(campaignSave.saveActiveRunCheckpoint({ stageId: 2, score: Number.MAX_VALUE, levels: {}, totals: {} }), false,
      'unrepresentably large scores must not be saved');
    assert.equal(campaignSave.saveActiveRunCheckpoint({ stageId: 2, score: 250, levels: { flagellum: 0.5, cilia: 1.9 }, totals: { dna: 1e300, kills: 1.7, time: 1e300, evolutions: -1 } }), true);
    const afterSave = campaignSave.loadActiveRunCheckpoint();
    assert.equal(afterSave?.score, 250);
    assert.deepEqual(afterSave?.levels, { cilia: 1 }, 'fractional ranks below 1 are discarded; valid fractional ranks are floored');
    assert.ok((afterSave?.savedAt ?? 0) <= Date.now() + 1000, 'corrupt future timestamps must not poison subsequent saves');
    assert.deepEqual(afterSave?.totals, { dna: 1_000_000_000, kills: 1, time: 1_000_000_000, evolutions: 0 },
      'saved counters must be integer-normalized and bounded');
    // Clearing advances the generation. A preserved, validly shaped checkpoint
    // from the previous generation must not come back even if removeItem fails.
    const stale = JSON.parse(storage.get('virus.active-run.v1'));
    storage.set('virus.active-run.v1', JSON.stringify({ ...stale, generation: 7, savedAt: Date.now() }));
    storage.set('virus.active-run.backup.v1', JSON.stringify({ ...stale, generation: 7, savedAt: Date.now() }));
    storage.setItem = function(key, value) {
      if (key === 'virus.active-run-epoch.v1' || key === 'virus.active-run-epoch.backup.v1') storage.set(key, String(value));
      else if (key !== 'virus.active-run.v1' && key !== 'virus.active-run.backup.v1') storage.set(key, String(value));
    };
    storage.remove = function(key) { if (key !== 'virus.active-run.v1' && key !== 'virus.active-run.backup.v1') storage.delete(key); };
    const realLocalStorage = global.localStorage;
    global.localStorage = {
      getItem: realLocalStorage.getItem,
      setItem: realLocalStorage.setItem,
      removeItem(key) { if (key === 'virus.active-run.v1' || key === 'virus.active-run.backup.v1') throw new Error('simulated remove failure'); storage.delete(key); },
    };
    campaignSave.clearActiveRunCheckpoint();
    assert.equal(campaignSave.loadActiveRunCheckpoint(), null, 'old-generation checkpoint must not resurrect after clear');
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('fractional mutation levels that floor to zero are removed from saves', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    campaignSave.markStageCompleted(1, { flagellum: 0.5, cilia: 1.9, volt: 4 });
    assert.deepEqual(campaignSave.loadStageLoadout(1), { cilia: 1, volt: 3 });
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('corrupted and adversarial save payloads are sanitized without unlocking impossible zones', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    const keys = [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.active-run-epoch.v1', 'virus.active-run-epoch.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ];
    const malformed = [
      '', '{broken', 'null', '[]', '42', '"string"',
      JSON.stringify({ completedStages: [0, -1, 1.5, 1, 1, 9, '2', null], loadouts: { '1': { flagellum: 99, hidden: 3, cilia: -1 } } }),
      JSON.stringify({ completedStages: [1], entryBuilds: { '1': { constructor: 3, flagellum: Infinity }, '9': { volt: 3 } } }),
      JSON.stringify({ stageId: 8, score: 1e300, savedAt: Number.MAX_VALUE, levels: { __proto__: 3 }, totals: { dna: -5, kills: Infinity } }),
      JSON.stringify({ stageId: -2, score: -1, savedAt: -1, generation: -100 }),
      JSON.stringify({ essence: -50, revision: Infinity, upgrades: { vitality: 999, mobility: -3, harvest: 1.7 }, rewardedStages: [1, 1, 9] }),
      JSON.stringify({ essence: 50, revision: 1e300, upgrades: null, rewardedStages: 'not-an-array' }),
    ];
    for (let round = 0; round < 120; round++) {
      for (const key of keys) storage.delete(key);
      const primary = malformed[round % malformed.length];
      const backup = malformed[(round * 7 + 3) % malformed.length];
      storage.set('virus.campaign-progress.v1', primary);
      storage.set('virus.campaign-progress.backup.v1', backup);
      storage.set('virus.completed-stages.v1', malformed[(round * 5 + 1) % malformed.length]);
      storage.set('virus.active-run.v1', malformed[(round * 3 + 2) % malformed.length]);
      storage.set('virus.active-run.backup.v1', malformed[(round * 11 + 4) % malformed.length]);
      storage.set('virus.meta-progress.v1', malformed[(round * 13 + 5) % malformed.length]);
      storage.set('virus.meta-progress.backup.v1', malformed[(round * 17 + 6) % malformed.length]);
      storage.set('virus.meta-rewarded-stages.v1', malformed[(round * 19 + 7) % malformed.length]);

      const progress = campaignSave.loadCampaignProgress();
      assert.deepEqual(progress.completedStages, [...new Set(progress.completedStages)].sort((a, b) => a - b));
      assert.ok(progress.completedStages.every((id) => Number.isInteger(id) && id >= 1 && id <= 8));
      for (const build of [...Object.values(progress.loadouts), ...Object.values(progress.entryBuilds)]) {
        for (const [id, level] of Object.entries(build)) {
          assert.ok(MUTATION_BY_ID[id], `unknown mutation id ${id} must be removed`);
          assert.ok(Number.isInteger(level) && level >= 1 && level <= 3);
        }
      }
      const meta = campaignSave.loadMetaProgress();
      assert.ok(Number.isFinite(meta.essence) && meta.essence >= 0);
      assert.ok(Number.isSafeInteger(meta.revision) && meta.revision >= 0);
      for (const level of Object.values(meta.upgrades)) assert.ok(Number.isInteger(level) && level >= 0 && level <= 3);
      const checkpoint = campaignSave.loadActiveRunCheckpoint();
      if (checkpoint) {
        assert.ok(Number.isInteger(checkpoint.stageId) && checkpoint.stageId >= 1 && checkpoint.stageId <= 8);
        assert.equal(campaignSave.canSelectStage(checkpoint.stageId), true,
          'a restored checkpoint can never be for a currently locked level');
        assert.ok(Number.isFinite(checkpoint.score) && checkpoint.score >= 0);
      }
      for (let stageId = 1; stageId <= 8; stageId++) {
        assert.equal(campaignSave.canSelectStage(stageId), campaignSave.isStageUnlocked(stageId, progress.completedStages));
      }
    }
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('saved loadouts discard unknown mutation ids and malformed ranks', () => {
  const originalStorage = global.localStorage;
  const storage = new Map();
  global.localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); },
  };
  try {
    for (const key of [
      'virus.campaign-progress.v1', 'virus.campaign-progress.backup.v1', 'virus.completed-stages.v1',
      'virus.active-run.v1', 'virus.active-run.backup.v1',
      'virus.meta-progress.v1', 'virus.meta-progress.backup.v1', 'virus.meta-rewarded-stages.v1',
    ]) storage.delete(key);
    campaignSave.markStageCompleted(1, { flagellum: 2, unknownCheat: 3, constructor: 3, cilia: 99 });
    assert.deepEqual(campaignSave.loadStageLoadout(1), { flagellum: 2, cilia: 3 });
  } finally {
    if (originalStorage === undefined) delete global.localStorage;
    else global.localStorage = originalStorage;
  }
});

test('mutation card bars show owned ranks, preview next rank, and lock later ranks', () => {
  assert.deepEqual([1, 2, 3].map((tier) => getMutationTierStatus(0, tier)), ['preview', 'locked', 'locked'],
    'a new mutation should preview tier 1 without showing it as already owned');
  assert.deepEqual([1, 2, 3].map((tier) => getMutationTierStatus(1, tier)), ['owned', 'preview', 'locked'],
    'tier 2 should remain a preview until selected');
  assert.deepEqual([1, 2, 3].map((tier) => getMutationTierStatus(2, tier)), ['owned', 'owned', 'preview'],
    'tier 3 must not appear unlocked before the player chooses the tier-3 upgrade');
  assert.deepEqual([1, 2, 3].map((tier) => getMutationTierStatus(3, tier)), ['owned', 'owned', 'owned'],
    'a max-rank mutation should show all three acquired ranks');
  assert.deepEqual([1, 2, 3].map((tier) => getMutationTierStatus(2.9, tier)), ['owned', 'owned', 'preview'],
    'fractional incoming rank data is safely floored for display');
  assert.deepEqual([1, 2, 3].map((tier) => getMutationTierStatus(Number.NaN, tier)), ['preview', 'locked', 'locked'],
    'invalid rank data must not accidentally display tiers as acquired');
  const ui = fs.readFileSync(require('node:path').join(__dirname, '../src/components/Overlays.tsx'), 'utf8');
  assert.match(ui, /getMutationTierStatus\(currentLevel, tier\)/,
    'mutation card bars must use the tested tier-status helper');
  assert.doesNotMatch(ui, /background:\s*i <= next \? def\.tint/,
    'upcoming rank must never be rendered as already owned');
});

test('Enter does not bypass the visible mutation-card selection', () => {
  const game = Object.create(Game.prototype);
  game.phase = 'mutate';
  game.choices = ['cilia', 'volt', 'net'];
  game.menuIndex = 0;
  let chosen = false;
  game.choose = () => { chosen = true; };
  game.handleEvent('confirm');
  assert.equal(chosen, false);
});

process.stdout.write(`\n${passed} regression tests passed.\n`);
