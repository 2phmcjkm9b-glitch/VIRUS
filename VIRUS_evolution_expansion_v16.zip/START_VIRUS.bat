@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto :no_node
where npm >nul 2>nul
if errorlevel 1 goto :no_npm

rem Vite 7 requires Node 20.19+ or 22.12+. Node 22 LTS is recommended.
node -e "const [major,minor]=process.versions.node.split('.').map(Number); process.exit((major===20&&minor>=19)||(major===22&&minor>=12)||major>22?0:1)" >nul 2>nul
if errorlevel 1 goto :unsupported_node

rem An interrupted npm ci can leave node_modules behind. Do not infer that the
rem install succeeded merely because the folder exists; check npm's dependency tree.
if not exist "node_modules\" goto :install_dependencies
call npm ls --depth=0 >nul 2>nul
if errorlevel 1 goto :install_dependencies
goto :check_types

:install_dependencies
echo Checking or installing dependencies for this computer...
call npm ci
if errorlevel 1 goto :dependency_failed
call npm ls --depth=0 >nul 2>nul
if errorlevel 1 goto :dependency_failed

:check_types
call npm run typecheck
if errorlevel 1 goto :typecheck_failed
call npm run dev -- --open
if errorlevel 1 goto :dev_failed
exit /b 0

:no_node
echo Node.js is required. Install Node.js 22 LTS (22.12 or newer), then run this file again.
pause
exit /b 1

:no_npm
echo npm was not found. Reinstall Node.js 22 LTS and make sure npm is on PATH.
pause
exit /b 1

:unsupported_node
echo This project needs Node.js 20.19+ or 22.12+. Recommended: Node.js 22 LTS, version 22.12 or newer.
pause
exit /b 1

:dependency_failed
echo Dependency installation or validation failed. Check internet access and the npm error above.
echo The game source has not yet been typechecked; this is not necessarily a source-code error.
pause
exit /b 1

:typecheck_failed
echo TypeScript typecheck failed. Read the first TS error above; this usually indicates a source or type-definition issue.
pause
exit /b 1

:dev_failed
echo Vite failed to start the development server. Read the error above.
pause
exit /b 1
