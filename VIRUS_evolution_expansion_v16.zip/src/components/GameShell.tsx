import { useCallback, useEffect, useRef, useState } from "react";
import { Game } from "../game/engine";
import { Hud } from "./Hud";
import {
  Briefing,
  EvolutionMap,
  HelpModal,
  LevelSelect,
  MutationModal,
  PauseOverlay,
  PermanentEvolutionShop,
  RunEnd,
  StageClear,
  StartScreen,
} from "./Overlays";
import {
  buyPermanentUpgrade,
  loadActiveRunCheckpoint,
  loadCompletedStages,
  loadMetaProgress,
  loadScores,
  type PermanentUpgradeId,
} from "../game/save";
import type { HudSnapshot, Phase, ScoreEntry } from "../game/types";

const EMPTY_HUD: HudSnapshot = {
  phase: "menu",
  hp: 100,
  maxHp: 100,
  dna: 0,
  dnaNeeded: 8,
  collected: 0,
  quota: 18,
  score: 0,
  combo: 1,
  stageIndex: 0,
  stageCount: 8,
  stageName: "",
  stageSubtitle: "",
  time: 0,
  kills: 0,
  shield: 0,
  shieldMax: 0,
  dashReady: 1,
  hint: "",
  choices: [],
  levels: {},
  dnaTotal: 0,
  evolutions: 0,
  locked: true,
  bossHp: -1,
  touch: false,
  muted: false,
};

export function GameShell() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);

  const [hud, setHud] = useState<HudSnapshot>(EMPTY_HUD);
  const [phase, setPhase] = useState<Phase>("menu");
  const [help, setHelp] = useState(false);
  const [evolutionMap, setEvolutionMap] = useState(false);
  const [showLevelSelect, setShowLevelSelect] = useState(false);
  const [showPermanentShop, setShowPermanentShop] = useState(false);
  const [hasContinue, setHasContinue] = useState(() => loadActiveRunCheckpoint() !== null);
  const [completedStages, setCompletedStages] = useState<number[]>(() => loadCompletedStages());
  const [metaProgress, setMetaProgress] = useState(() => loadMetaProgress());
  const [sel, setSel] = useState(0);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const muted = hud.muted;

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const game = new Game(canvas, wrap, {
      onHud: setHud,
      onPhase: setPhase,
    });
    gameRef.current = game;
    game.start();
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  // Refresh the local high-score table whenever a run ends.
  useEffect(() => {
    if (phase === "dead" || phase === "won") setScores(loadScores());
    setCompletedStages(loadCompletedStages());
    setMetaProgress(loadMetaProgress());
    setHasContinue(loadActiveRunCheckpoint() !== null);
  }, [phase]);

  useEffect(() => {
    if (phase === "mutate") setSel(0);
  }, [phase]);

  const g = () => gameRef.current;

  const openLevelSelect = useCallback(() => {
    setCompletedStages(loadCompletedStages());
    setHelp(false);
    setEvolutionMap(false);
    setShowLevelSelect(true);
  }, []);
  const closeLevelSelect = useCallback(() => setShowLevelSelect(false), []);
  const selectLevel = useCallback((stageId: number) => {
    const started = g()?.startSelectedStage(stageId) ?? false;
    if (started) {
      setShowLevelSelect(false);
      setHelp(false);
      setEvolutionMap(false);
    }
  }, []);

  const start = useCallback(() => {
    // Preserve an unfinished run unless the player explicitly confirms replacing it.
    if (loadActiveRunCheckpoint() && !window.confirm(
      "Есть незавершённый забег. Начало нового забега заменит точку продолжения. Продолжить и начать заново?",
    )) return;
    g()?.startRun(true);
  }, []);
  const continueRun = useCallback(() => {
    const resumed = g()?.continueRun() ?? false;
    setHasContinue(loadActiveRunCheckpoint() !== null);
    if (!resumed) {
      window.alert("Не удалось восстановить забег. Проверьте сохранение и попробуйте начать новую игру.");
    }
  }, []);
  const openPermanentShop = useCallback(() => {
    setHelp(false);
    setEvolutionMap(false);
    setShowLevelSelect(false);
    setShowPermanentShop(true);
  }, []);
  const closePermanentShop = useCallback(() => setShowPermanentShop(false), []);
  const buyUpgrade = useCallback((id: PermanentUpgradeId) => {
    const result = buyPermanentUpgrade(id);
    setMetaProgress(result.progress);
    g()?.refreshPermanentUpgrades();
  }, []);
  const openHelp = useCallback(() => {
    const game = g();
    if (game && game.phase === "playing") game.pause();
    setHelp(true);
  }, []);
  const closeHelp = useCallback(() => setHelp(false), []);
  const openEvolutionMap = useCallback(() => {
    const game = g();
    if (game?.phase === "playing") game.pause();
    setEvolutionMap(true);
  }, []);
  const closeEvolutionMap = useCallback(() => setEvolutionMap(false), []);
  const toggleMute = useCallback(() => {
    g()?.toggleMute();
  }, []);

  // Keyboard shortcuts for the overlay screens (the engine handles in-game keys).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      const game = gameRef.current;
      if (!game) return;
      const target = e.target instanceof Element ? e.target : null;
      const interactive = target?.closest(
        "button, a[href], input, textarea, select, [role=button], [contenteditable=true]",
      );
      // Repeated keydown events must not toggle pause/mute or advance multiple
      // screens. Movement remains held through Input's key state instead.
      if (e.repeat && ["escape", "p", "r", "m", "h", "enter", "?", "1", "2", "3"].includes(k)) return;
      // Native Space activation belongs to the focused control. Enter on a
      // mutation card is handled here so it activates the visually selected
      // card, not whichever button happened to retain DOM focus after arrows.
      if (interactive && k === " " ) return;
      if (showPermanentShop) {
        if (k === "escape") {
          e.preventDefault();
          setShowPermanentShop(false);
        }
        return;
      }
      if (showLevelSelect) {
        if (k === "escape") {
          e.preventDefault();
          setShowLevelSelect(false);
        }
        return;
      }
      if (evolutionMap) {
        if (k === "escape" || k === "enter") {
          e.preventDefault();
          setEvolutionMap(false);
        }
        return;
      }
      if (interactive && k === "enter" && phase !== "mutate") return;
      if (interactive && k === "enter" && phase === "mutate") e.preventDefault();
      if (help) {
        if (k === "escape" || k === "enter" || k === "h" || k === "?") {
          e.preventDefault();
          setHelp(false);
        }
        return;
      }
      if (k === "escape" || k === "p") {
        e.preventDefault();
        if (phase === "playing") game.pause();
        else if (phase === "paused") game.resume();
        return;
      }
      if (k === "r" && (phase === "paused" || phase === "dead" || phase === "won")) {
        e.preventDefault();
        if (loadActiveRunCheckpoint() && !window.confirm(
          "Есть незавершённый забег. Начало нового забега заменит точку продолжения. Продолжить и начать заново?",
        )) return;
        game.startRun(true);
        return;
      }
      if (k === "m") {
        game.toggleMute();
        return;
      }
      if (k === "h" || k === "?") {
        if (phase === "playing") game.pause();
        setHelp(true);
        return;
      }
      if (k === "enter") {
        e.preventDefault();
        if (phase === "briefing") game.beginStage();
        else if (phase === "mutate" && hud.choices[sel]) game.choose(hud.choices[sel].id);
        else if (phase === "dead") start();
        // Victory owns its own skippable cinematic; Enter must not accidentally
        // discard the ending and immediately start another run. Use R or a button.
        else if (phase === "clear") game.nextStage();
        return;
      }
      if (phase === "mutate") {
        const n = hud.choices.length;
        if (k === "arrowleft" || k === "arrowup") {
          const next = n > 0 ? (sel - 1 + n) % n : 0;
          setSel(next);
          game.setMenuIndex(next);
          e.preventDefault();
        } else if (k === "arrowright" || k === "arrowdown") {
          const next = n > 0 ? (sel + 1) % n : 0;
          setSel(next);
          game.setMenuIndex(next);
          e.preventDefault();
        } else if (k === "1" || k === "2" || k === "3") {
          const idx = Number(k) - 1;
          if (hud.choices[idx]) game.choose(hud.choices[idx].id);
        } else if (k === "enter") {
          if (hud.choices[sel]) game.choose(hud.choices[sel].id);
        }
        return;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, help, evolutionMap, showLevelSelect, showPermanentShop, hud.choices, sel, start]);

  const showHud =
    phase === "playing" ||
    phase === "paused" ||
    phase === "briefing" ||
    phase === "mutate" ||
    phase === "clear" ||
    phase === "dead" ||
    phase === "won";

  return (
    <div
      ref={wrapRef}
      className="absolute inset-0 overflow-hidden bg-[#030a0e]"
      style={{ touchAction: help || phase === "mutate" ? "pan-y" : "none" }}
    >
      <canvas
        ref={canvasRef}
        className="block h-full w-full"
        style={{ touchAction: "none" }}
      />

      {showHud && (
        <Hud
          hud={hud}
          muted={muted}
          onPause={() => g()?.pause()}
          onMute={toggleMute}
          onDash={() => g()?.requestDash()}
        />
      )}

      {phase === "menu" && !help && (
        <StartScreen
          onStart={start}
          onContinue={continueRun}
          hasContinue={hasContinue}
          onHelp={openHelp}
          onEvolutionMap={openEvolutionMap}
          onLevelSelect={openLevelSelect}
          onPermanentEvolution={openPermanentShop}
          essence={metaProgress.essence}
          scores={scores}
          muted={muted}
          onMute={toggleMute}
        />
      )}

      {phase === "briefing" && (
        <Briefing hud={hud} onBegin={() => g()?.beginStage()} />
      )}

      {phase === "mutate" && (
        <MutationModal
          hud={hud}
          selected={sel}
          onSelect={setSel}
          onChoose={(id) => g()?.choose(id)}
        />
      )}

      {phase === "paused" && !help && (
        <PauseOverlay
          hud={hud}
          onResume={() => g()?.resume()}
          onNewRun={start}
          onRetryStage={() => g()?.retryStage()}
          onMenu={() => g()?.toMenu()}
          onHelp={openHelp}
          onEvolutionMap={openEvolutionMap}
          muted={muted}
          onMute={toggleMute}
        />
      )}

      {phase === "clear" && (
        <StageClear
          hud={hud}
          onNext={() => g()?.nextStage()}
          onRetry={() => g()?.retryStage()}
          onLevelSelect={openLevelSelect}
        />
      )}

      {(phase === "dead" || phase === "won") && (
        <RunEnd
          hud={hud}
          scores={scores}
          victory={phase === "won"}
          onNewRun={start}
          onRetry={() => g()?.retryStage()}
          onMenu={() => g()?.toMenu()}
          onLevelSelect={openLevelSelect}
        />
      )}

      {help && <HelpModal onClose={closeHelp} />}
      {evolutionMap && <EvolutionMap levels={hud.levels} onClose={closeEvolutionMap} />}
      {showPermanentShop && (
        <PermanentEvolutionShop
          progress={metaProgress}
          onBuy={buyUpgrade}
          onClose={closePermanentShop}
        />
      )}
      {showLevelSelect && (
        <LevelSelect
          completedStages={completedStages}
          onSelect={selectLevel}
          onBack={closeLevelSelect}
        />
      )}

      <div className="portrait-hint pointer-events-none absolute inset-x-0 bottom-0 justify-center pb-1">
        <span className="mono rounded-full bg-black/60 px-2.5 py-1 text-[8px] tracking-[0.2em] text-emerald-200/60">
          ↻ ROTATE FOR A WIDER VIEW
        </span>
      </div>
    </div>
  );
}
