import { useEffect, useState } from "react";
import type { EnemyKind, HudSnapshot, MutationDef, ScoreEntry } from "../game/types";
import { MUTATIONS, STAGES } from "../game/data";
import { formatTime } from "../game/math";
import { getMutationTierStatus } from "../game/mutationTier";
import { VirusPreview } from "./VirusPreview";
import { isStageUnlocked, PERMANENT_UPGRADE_DEFS, type MetaProgress, type PermanentUpgradeId } from "../game/save";

/* ------------------------------------------------------------------ */

const ENEMY_LABEL_RU: Record<EnemyKind, string> = {
  mite: "КЛЕЩ",
  spore: "СПОРА",
  chaser: "ПРЕСЛЕДОВАТЕЛЬ",
  spiker: "ШИПАСТЫЙ",
  hunter: "ОХОТНИК",
  symbiote: "СИМБИОНТ · ЛЕЧИТ",
  phantom: "ФАНТОМ · ЗАСАДА",
  incubator: "ИНКУБАТОР · ВЫВОДОК",
  sentinel: "СТРАЖ · БОСС",
};

const ENEMY_TINT_RU: Record<EnemyKind, string> = {
  mite: "#ffad72",
  spore: "#c69aff",
  chaser: "#ff8bce",
  spiker: "#ff9a55",
  hunter: "#9adfff",
  symbiote: "#76ffd0",
  phantom: "#c4adff",
  incubator: "#ff9b80",
  sentinel: "#ffd27a",
};

const MUTATION_KIND_RU: Record<string, string> = {
  attack: "АТАКА",
  offensive: "АТАКА",
  offense: "АТАКА",
  defense: "ЗАЩИТА",
  defensive: "ЗАЩИТА",
  mobility: "ПОДВИЖНОСТЬ",
  move: "ДВИЖЕНИЕ",
  movement: "ДВИЖЕНИЕ",
  collect: "СБОР ДНК",
  harvest: "СБОР ДНК",
  regeneration: "ВОССТАНОВЛЕНИЕ",
  survival: "ВЫЖИВАНИЕ",
  utility: "ПОЛЕЗНЫЕ",
  adaptation: "АДАПТАЦИЯ",
  evolution: "ЭВОЛЮЦИЯ",
};

function translateMutationKind(kind: string) {
  return MUTATION_KIND_RU[kind.toLowerCase()] ?? kind.toUpperCase();
}

export function ScoreTable({
  scores,
  title = "ЛУЧШИЕ РЕЗУЛЬТАТЫ",
}: {
  scores: ScoreEntry[];
  title?: string;
}) {
  return (
    <div className="w-full">
      <div className="mono mb-1.5 text-[9px] tracking-[0.3em] text-emerald-200/50">
        {title}
      </div>
      {scores.length === 0 ? (
        <div className="mono rounded-lg border border-emerald-300/10 bg-black/30 px-3 py-3 text-center text-[10px] tracking-widest text-emerald-200/40">
          ПОКА НЕТ РЕКОРДОВ — УСТАНОВИ ПЕРВЫЙ!
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-emerald-300/12 bg-black/35">
          {scores.map((s, i) => (
            <div
              key={`${s.date}-${i}-${s.score}`}
              className={`mono flex items-center gap-2 px-2.5 py-1.5 text-[10px] tracking-wider ${
                i % 2 ? "bg-white/[0.02]" : ""
              }`}
            >
              <span
                className="w-5 shrink-0 text-center font-bold"
                style={{ color: i === 0 ? "#ffe066" : "#7dffb0aa" }}
              >
                {i + 1}
              </span>
              <span className="flex-1 text-right text-emerald-100">
                {s.score.toLocaleString("ru-RU")}
              </span>
              <span className="w-20 shrink-0 text-center text-emerald-200/50">
                {s.victory ? "★ ПОБЕДА" : `ЗОНА ${s.stage + 1}`}
              </span>
              <span className="hidden w-16 shrink-0 text-center text-emerald-200/40 sm:block">
                {s.evolutions} МУТ.
              </span>
              <span className="hidden w-16 shrink-0 text-right text-emerald-200/30 sm:block">
                {s.date}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatBox({ label, value, tint }: { label: string; value: string; tint?: string }) {
  return (
    <div className="rounded-lg border border-emerald-300/12 bg-black/30 px-2 py-1.5 text-center">
      <div className="mono text-[8px] tracking-[0.2em] text-emerald-200/45">
        {label}
      </div>
      <div
        className="display text-sm sm:text-base"
        style={{ color: tint ?? "#dff7e6" }}
      >
        {value}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function StartScreen({
  onStart,
  onContinue,
  hasContinue,
  onHelp,
  onEvolutionMap,
  onLevelSelect,
  onPermanentEvolution,
  essence,
  scores,
  muted,
  onMute,
}: {
  onStart: () => void;
  onContinue: () => void;
  hasContinue: boolean;
  onHelp: () => void;
  onEvolutionMap: () => void;
  onLevelSelect: () => void;
  onPermanentEvolution: () => void;
  essence: number;
  scores: ScoreEntry[];
  muted: boolean;
  onMute: () => void;
}) {
  return (
    <div className="start-screen absolute inset-0 flex flex-col items-center justify-between overflow-hidden p-4 sm:p-8">
      <div className="scanlines pointer-events-none absolute inset-0 opacity-40" />

      <header className="relative z-10 mt-2 text-center sm:mt-6">
        <div className="mono mb-1 text-[9px] tracking-[0.5em] text-emerald-300/60 sm:text-[11px]">
          ОБРАЗЕЦ 0-1 · ЖИВАЯ КУЛЬТУРА
        </div>
        <h1
          className="display title-glitch text-5xl leading-none sm:text-7xl md:text-8xl"
          style={{
            color: "#c8ff4d",
            textShadow:
              "0 0 22px rgba(200,255,77,0.55), 0 0 70px rgba(125,255,94,0.28), 0 6px 0 #0b3b18",
          }}
        >
          VIRUS
        </h1>
        <div className="mono mt-2 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[9px] tracking-[0.28em] text-emerald-200/60 sm:text-[11px]">
          <span>СОБИРАЙ ДНК</span>
          <span className="text-lime-400">◆</span>
          <span>ЭВОЛЮЦИОНИРУЙ</span>
          <span className="text-lime-400">◆</span>
          <span>ЗАРАЗИ ХОЗЯИНА</span>
        </div>
      </header>

      <div className="relative z-10 hidden flex-1 sm:block" />

      <div className="relative z-10 mb-1 w-full max-w-5xl">
        <div className="grid gap-3 sm:grid-cols-[1.1fr_0.9fr]">
          <div className="glass pop-in rounded-2xl p-4">
            <div className="mono mb-2 text-[9px] tracking-[0.3em] text-emerald-200/50">
              ЗАДАНИЕ
            </div>
            <p className="mono mb-3 text-[11px] leading-relaxed text-emerald-100/80 sm:text-xs">
              Ты — недавно появившийся колючий вирус в микроскопической экосистеме.
              Собирай генетический материал, мутируй, становись сильнее и пробивайся
              к клетке хозяина через восемь всё более опасных зон.
            </p>
            <div className="flex flex-wrap gap-2">
              <button className="btn btn-primary glow-pulse" onClick={onStart}>
                ▶ НОВОЕ ЗАРАЖЕНИЕ
              </button>
              {hasContinue && (
                <button
                  className="btn border-lime-300/50 text-lime-100"
                  onClick={onContinue}
                  title="Продолжение с начала последней сохранённой зоны"
                >
                  ↻ ПРОДОЛЖИТЬ ЗАБЕГ · С НАЧАЛА ЗОНЫ
                </button>
              )}
              <button className="btn" onClick={onHelp}>
                ? КАК ИГРАТЬ
              </button>
              <button className="btn" onClick={onEvolutionMap}>
                ✦ КАРТА ЭВОЛЮЦИИ
              </button>
              <button className="btn" onClick={onPermanentEvolution}>
                ◈ ПОСТОЯННАЯ ЭВОЛЮЦИЯ · {essence}
              </button>
              <button className="btn" onClick={onLevelSelect}>
                ▦ ВЫБОР УРОВНЯ
              </button>
              <button className="btn btn-ghost !px-3" onClick={onMute}>
                {muted ? "🔇 ЗВУК ВЫКЛЮЧЕН" : "🔊 ЗВУК ВКЛЮЧЁН"}
              </button>
            </div>
            <div className="mono mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[9px] tracking-[0.14em] text-emerald-200/45">
              <span>WASD / СТРЕЛКИ / МЫШЬ / КАСАНИЕ</span>
              <span>ПРОБЕЛ — РЫВОК</span>
              <span>ESC — ПАУЗА</span>
            </div>
          </div>
          <div className="glass-soft rounded-2xl p-3">
            <ScoreTable scores={scores} />
            <div className="mono mt-2 text-[9px] leading-relaxed tracking-wider text-emerald-200/40">
              8 ЗОН · 12 ВЕТОК МУТАЦИЙ × 3 УРОВНЯ · РЕКОРДЫ СОХРАНЯЮТСЯ НА УСТРОЙСТВЕ
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function PermanentEvolutionShop({
  progress,
  onBuy,
  onClose,
}: {
  progress: MetaProgress;
  onBuy: (id: PermanentUpgradeId) => void;
  onClose: () => void;
}) {
  const ids: PermanentUpgradeId[] = ["vitality", "mobility", "harvest"];
  return (
    <div className="absolute inset-0 z-[85] flex items-center justify-center bg-black/85 p-3 backdrop-blur-md sm:p-6">
      <div role="dialog" aria-modal="true" aria-label="Постоянная эволюция" className="glass pop-in no-scrollbar max-h-full w-full max-w-3xl overflow-y-auto rounded-2xl p-4 sm:p-6">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <div className="mono text-[9px] tracking-[0.38em] text-emerald-200/50">МЕТА-ПРОГРЕССИЯ · МЕЖДУ ЗАБЕГАМИ</div>
            <h2 className="display mt-1 text-3xl sm:text-4xl" style={{ color: "#c8ff4d" }}>ПОСТОЯННАЯ ЭВОЛЮЦИЯ</h2>
            <p className="mono mt-1 text-[10px] leading-relaxed text-emerald-100/55">Эссенция выдаётся один раз за первое прохождение каждой зоны. Купленные бонусы сохраняются после поражения и действуют в новых зонах.</p>
          </div>
          <button className="btn btn-ghost shrink-0 !px-3" onClick={onClose} aria-label="Закрыть постоянную эволюцию">✕</button>
        </div>

        <div className="mb-4 flex items-center justify-between rounded-xl border border-lime-300/20 bg-lime-300/5 px-4 py-3">
          <span className="mono text-xs tracking-[0.2em] text-emerald-100/70">БИО-ЭССЕНЦИЯ</span>
          <span className="display text-2xl" style={{ color: "#c8ff4d" }}>{progress.essence}</span>
        </div>

        <div className="grid gap-3 md:grid-cols-3">
          {ids.map((id) => {
            const def = PERMANENT_UPGRADE_DEFS[id];
            const level = progress.upgrades[id];
            const maxed = level >= def.costs.length;
            const cost = maxed ? 0 : def.costs[level];
            const canBuy = !maxed && progress.essence >= cost;
            return (
              <section key={id} className="glass-soft rounded-xl border border-emerald-300/15 p-3">
                <div className="display text-lg text-emerald-50">{def.name}</div>
                <p className="mono mt-2 min-h-12 text-[10px] leading-relaxed text-emerald-100/55">{def.description}</p>
                <div className="my-3 flex items-center justify-between">
                  <span className="mono text-[9px] tracking-wider text-emerald-200/50">УРОВЕНЬ</span>
                  <span className="display text-lg" style={{ color: "#c8ff4d" }}>{level}/3</span>
                </div>
                <div className="space-y-1.5">
                  {def.effect.map((effect, index) => (
                    <div key={effect} className={`mono rounded-lg px-2 py-1.5 text-[10px] ${index < level ? "bg-lime-300/10 text-lime-100" : "bg-black/20 text-emerald-100/35"}`}>
                      {index < level ? "✓ " : `${index + 1}. `}{effect}
                    </div>
                  ))}
                </div>
                <button
                  type="button"
                  disabled={!canBuy}
                  onClick={() => onBuy(id)}
                  className={`btn mt-3 w-full ${canBuy ? "btn-primary" : "cursor-not-allowed opacity-45"}`}
                >
                  {maxed ? "МАКСИМУМ" : `УЛУЧШИТЬ · ${cost} ЭССЕНЦИИ`}
                </button>
              </section>
            );
          })}
        </div>
        <p className="mono mt-4 text-[9px] leading-relaxed text-emerald-100/35">Постоянные бонусы умеренные и не заменяют временные мутации, которые можно получить только в ходе текущего забега.</p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

/** Cleared zones and the next campaign zone can be selected; later zones stay locked. */
export function LevelSelect({
  completedStages,
  onSelect,
  onBack,
}: {
  completedStages: number[];
  onSelect: (stageId: number) => void;
  onBack: () => void;
}) {
  const completed = new Set(completedStages);
  const availableCount = STAGES.filter((stage) => isStageUnlocked(stage.id, completedStages)).length;
  return (
    <div className="absolute inset-0 z-[70] flex items-center justify-center bg-black/80 p-3 backdrop-blur-md sm:p-6">
      <div role="dialog" aria-modal="true" aria-label="Выбор уровня" className="glass pop-in no-scrollbar max-h-full w-full max-w-4xl overflow-y-auto rounded-2xl p-4 sm:p-6">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <div className="mono text-[9px] tracking-[0.38em] text-emerald-200/50">АРХИВ ЗАРАЖЁННЫХ ЗОН</div>
            <h2 className="display mt-1 text-3xl sm:text-4xl" style={{ color: "#c8ff4d", textShadow: "0 0 22px rgba(200,255,77,0.3)" }}>ВЫБОР УРОВНЯ</h2>
            <p className="mono mt-1 text-[10px] leading-relaxed text-emerald-100/55">Пройденные зоны можно переиграть. Следующая зона открывается после прохождения предыдущей и остаётся доступной после поражения.</p>
          </div>
          <button className="btn btn-ghost shrink-0 !px-3" onClick={onBack} aria-label="Закрыть выбор уровня">✕</button>
        </div>

        <div className="mb-3 flex items-center justify-between gap-3 rounded-lg border border-emerald-300/10 bg-black/25 px-3 py-2">
          <span className="mono text-[9px] tracking-[0.16em] text-emerald-100/60">ДОСТУПНО ЗОН</span>
          <span className="display text-lg" style={{ color: "#c8ff4d" }}>{availableCount} / {STAGES.length}</span>
        </div>

        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {STAGES.map((stage) => {
            const isCompleted = completed.has(stage.id);
            const isAvailable = isStageUnlocked(stage.id, completedStages);
            return (
              <button
                key={stage.id}
                type="button"
                disabled={!isAvailable}
                onClick={() => onSelect(stage.id)}
                className={`relative min-h-[112px] overflow-hidden rounded-xl border p-3 text-left transition ${isAvailable ? "border-emerald-300/25 bg-emerald-950/35 hover:border-lime-300/70 hover:bg-emerald-900/35" : "cursor-not-allowed border-white/5 bg-black/25 opacity-55"}`}
                style={isAvailable ? { boxShadow: isCompleted ? "inset 0 0 0 1px rgba(200,255,77,0.08)" : undefined } : undefined}
                aria-label={`Уровень ${stage.id}: ${stage.name}${isCompleted ? ", пройден" : isAvailable ? ", доступен" : ", закрыт"}`}
              >
                <div className="mb-2 flex items-center justify-between gap-2">
                  <span className="mono text-[9px] tracking-[0.2em] text-emerald-200/50">ЗОНА {String(stage.id).padStart(2, "0")}</span>
                  <span className={`mono rounded-full px-2 py-1 text-[8px] tracking-wider ${isCompleted ? "bg-lime-300/15 text-lime-200" : isAvailable ? "bg-cyan-300/10 text-cyan-100" : "bg-white/5 text-white/35"}`}>
                    {isCompleted ? "ПРОЙДЕНА" : isAvailable ? "ДОСТУПНА" : "ЗАКРЫТА 🔒"}
                  </span>
                </div>
                <div className={`display text-base leading-tight ${isAvailable ? "text-emerald-50" : "text-white/45"}`}>{stage.name}</div>
                <div className="mono mt-1.5 text-[9px] leading-relaxed text-emerald-100/45">ДНК: {stage.quota} · Враги: {Object.values(stage.spawns).reduce((total, count) => total + (count ?? 0), 0)}</div>
                {!isAvailable && <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/20"><span className="text-3xl opacity-35">🔒</span></div>}
              </button>
            );
          })}
        </div>

        <div className="mono mt-4 text-center text-[9px] leading-relaxed tracking-wide text-emerald-100/35">Выбор открытой зоны начинает отдельный забег с сохранённым лучшим набором мутаций этой зоны. Открытая следующая зона не блокируется, если вы проиграли в ней; дальнейшие зоны остаются закрытыми до прохождения предыдущей.</div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function Briefing({ hud, onBegin }: { hud: HudSnapshot; onBegin: () => void }) {
  const stage = STAGES[hud.stageIndex];
  const threats = Object.entries(stage.spawns)
    .filter(([, count]) => (count ?? 0) > 0)
    .map(([kind]) => kind as EnemyKind);
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Брифинг зоны"
      className="absolute inset-0 flex items-center justify-center bg-black/45 p-4 backdrop-blur-[2px]"
      // A deliberate touch/click anywhere on the briefing or its button starts
      // the level. There is no timer-based dismissal; Enter is handled by GameShell.
      onClick={onBegin}
    >
      <div className="glass pop-in w-full max-w-lg rounded-2xl p-5 text-center">
        <div className="mono text-[9px] tracking-[0.4em] text-emerald-300/60">
          ЗОНА {hud.stageIndex + 1} ИЗ {hud.stageCount}
        </div>
        <h2
          className="display mt-1 text-2xl sm:text-4xl"
          style={{ color: "#c8ff4d", textShadow: "0 0 24px rgba(200,255,77,0.4)" }}
        >
          {stage.name}
        </h2>
        <div className="mono mt-1 text-[10px] tracking-[0.2em] text-emerald-200/60">
          {stage.subtitle}
        </div>
        <p className="mono mt-3 text-[11px] leading-relaxed text-emerald-100/75 sm:text-xs">
          {stage.brief}
        </p>

        <div className="mt-4 grid grid-cols-3 gap-2">
          <StatBox label="ЦЕЛЬ ПО ДНК" value={`${stage.quota}`} tint="#c8ff4d" />
          <StatBox label="ТИПЫ ВРАГОВ" value={`${threats.length}`} tint="#ff8a8a" />
          <StatBox label="ОПАСНОСТИ" value={`${stage.acids.length + stage.currents.length}`} tint="#ffd45e" />
        </div>
        <div className="mt-3 flex flex-wrap justify-center gap-1.5" aria-label="Типы противников в зоне">
          {threats.map((kind) => (
            <span
              key={kind}
              className="mono rounded-full border px-2 py-1 text-[8px] tracking-[0.08em]"
              style={{ color: ENEMY_TINT_RU[kind], borderColor: `${ENEMY_TINT_RU[kind]}45`, backgroundColor: `${ENEMY_TINT_RU[kind]}12` }}
            >
              {ENEMY_LABEL_RU[kind]}
            </span>
          ))}
        </div>

        {Object.values(hud.levels).some((v) => v > 0) && (
          <div className="mono mt-3 text-[9px] tracking-[0.18em] text-emerald-200/50">
            УЖЕ ЕСТЬ МУТАЦИЙ: {Object.entries(hud.levels).filter(([, v]) => v > 0).length}
          </div>
        )}

        <button type="button" className="btn btn-primary mt-4 w-full" onClick={onBegin}>
          ▶ НАЧАТЬ (ENTER / КАСАНИЕ)
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

/** A discoverable skill-tree map for the 12 in-run mutation branches. */
export function EvolutionMap({
  levels,
  onClose,
}: {
  levels: Record<string, number>;
  onClose: () => void;
}) {
  const branches = [
    { kind: "move" as const, title: "ПОДВИЖНОСТЬ", tint: "#5ef0ff", sub: "Скорость, рывок и контроль пространства" },
    { kind: "defense" as const, title: "ЗАЩИТА", tint: "#ffd45e", sub: "Запас здоровья, восстановление и щиты" },
    { kind: "collect" as const, title: "СБОР ДНК", tint: "#c98bff", sub: "Притяжение, автоматический сбор и бонусы" },
    { kind: "attack" as const, title: "АТАКА", tint: "#ff758e", sub: "Контактный урон и эффекты рывка" },
  ];
  const nodeLabel = ["I", "II", "III"];
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Карта эволюции"
      className="absolute inset-0 z-40 flex items-center justify-center bg-[#02090c]/90 p-3 backdrop-blur-lg sm:p-6"
      onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}
    >
      <div className="glass pop-in no-scrollbar max-h-full w-full max-w-6xl overflow-y-auto rounded-2xl p-4 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="mono text-[9px] tracking-[0.42em] text-emerald-300/65">ГЕНЕТИЧЕСКАЯ СХЕМА · 12 ВЕТОК</div>
            <h2 className="display mt-1 text-2xl sm:text-4xl" style={{ color: "#c8ff4d", textShadow: "0 0 22px rgba(200,255,77,0.25)" }}>
              КАРТА ЭВОЛЮЦИИ
            </h2>
            <p className="mono mt-2 max-w-2xl text-[10px] leading-relaxed text-emerald-100/60 sm:text-xs">
              Каждая ветка имеет три последовательных уровня. Собирай ДНК во время забега, выбирай мутации и открывай более сильные версии. Светящиеся узлы уже получены в текущем забеге.
            </p>
          </div>
          <button className="btn btn-ghost shrink-0 !px-4" onClick={onClose} aria-label="Закрыть карту эволюции">✕ ЗАКРЫТЬ (ESC)</button>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {branches.map((branch, branchIndex) => {
            const defs = MUTATIONS.filter((def) => def.kind === branch.kind);
            const completed = defs.reduce((sum, def) => sum + Math.min(3, levels[def.id] ?? 0), 0);
            return (
              <section key={branch.kind} className="rounded-xl border bg-black/30 p-3" style={{ borderColor: `${branch.tint}35`, boxShadow: `inset 0 1px 0 ${branch.tint}12` }}>
                <div className="flex items-center justify-between gap-2">
                  <div className="mono text-[10px] font-bold tracking-[0.18em]" style={{ color: branch.tint }}>{branchIndex + 1}. {branch.title}</div>
                  <span className="mono text-[9px] text-white/40">{completed}/{defs.length * 3}</span>
                </div>
                <p className="mono mb-3 mt-1 text-[9px] leading-relaxed text-emerald-100/45">{branch.sub}</p>
                <div className="space-y-3">
                  {defs.map((def) => {
                    const current = Math.min(3, Math.max(0, levels[def.id] ?? 0));
                    return (
                      <div key={def.id} className="rounded-lg border border-white/[0.07] bg-white/[0.025] p-2.5">
                        <div className="flex items-start justify-between gap-2">
                          <div className="display text-[13px] leading-tight text-emerald-50">{def.name}</div>
                          <span className="mono shrink-0 text-[8px]" style={{ color: current > 0 ? branch.tint : "#78918a" }}>{current}/3</span>
                        </div>
                        <div className="mono mt-1 text-[9px] leading-relaxed text-emerald-100/45">{def.tagline}</div>
                        <div className="mt-2 space-y-2">
                          {def.levels.map((description, tier) => {
                            const active = current >= tier + 1;
                            return (
                              <div key={tier} className="relative flex gap-2.5">
                                <div className="relative flex w-7 shrink-0 justify-center">
                                  {tier < 2 && <span className="absolute top-6 bottom-[-9px] w-px" style={{ background: active ? `${branch.tint}80` : "rgba(150,180,170,0.18)" }} />}
                                  <span className="relative z-10 flex h-6 w-6 items-center justify-center rounded-full border text-[9px] font-black" style={{ borderColor: active ? branch.tint : "rgba(150,180,170,0.24)", color: active ? "#06130c" : "#9bb2a8", background: active ? branch.tint : "rgba(6,20,22,0.9)", boxShadow: active ? `0 0 12px ${branch.tint}55` : "none" }}>{nodeLabel[tier]}</span>
                                </div>
                                <div className="min-w-0 flex-1 pb-1">
                                  <div className="mono text-[8px] tracking-[0.15em]" style={{ color: active ? branch.tint : "rgba(200,225,215,0.32)" }}>{active ? "УРОВЕНЬ ПОЛУЧЕН" : `УРОВЕНЬ ${tier + 1}`}</div>
                                  <div className={`mt-0.5 text-[10px] leading-snug ${active ? "text-emerald-50/90" : "text-emerald-100/45"}`}>{description}</div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>
        <div className="mono mt-4 rounded-lg border border-emerald-200/10 bg-emerald-200/[0.035] p-3 text-[9px] leading-relaxed tracking-wide text-emerald-100/50">
          ВАЖНО: это карта мутаций текущего забега, не отдельный магазин постоянных улучшений. После поражения уровни сбрасываются; во время забега они переносятся между зонами.
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function MutationCard({
  def,
  level,
  levels,
  selected,
  index,
  onChoose,
  onHover,
}: {
  def: MutationDef;
  level: number;
  levels: Record<string, number>;
  selected: boolean;
  index: number;
  onChoose: () => void;
  onHover: () => void;
}) {
  const currentLevel = Number.isFinite(level)
    ? Math.max(0, Math.min(3, Math.floor(level)))
    : 0;
  const next = Math.min(3, currentLevel + 1);
  return (
    <button
      onClick={onChoose}
      onMouseEnter={onHover}
      className={`card-sel mutation-card glass relative flex flex-col items-center overflow-hidden rounded-2xl p-3 text-center ${
        selected ? "sel" : ""
      }`}
      style={{
        borderColor: selected ? def.tint : "rgba(125,255,150,0.14)",
        boxShadow: selected
          ? `0 0 34px ${def.tint}66, inset 0 0 30px ${def.tint}22`
          : undefined,
      }}
    >
      <span
        className="mono absolute left-2 top-2 rounded px-1.5 py-0.5 text-[8px] tracking-widest"
        style={{ color: def.tint, border: `1px solid ${def.tint}55` }}
      >
        {index + 1}
      </span>
      <span
        className="mono absolute right-2 top-2 rounded px-1.5 py-0.5 text-[8px] tracking-widest"
        style={{ color: def.tint, border: `1px solid ${def.tint}55` }}
      >
        {currentLevel >= 3 ? "МАКСИМУМ" : currentLevel > 0 ? `УР. ${currentLevel} → ${next}` : "НОВАЯ"}
      </span>

      <div
        className="mutation-specimen-frame mt-3"
        style={{
          borderColor: `${def.tint}42`,
          background: `radial-gradient(circle at 50% 45%, ${def.tint}1c 0%, ${def.tint}08 48%, transparent 72%)`,
          boxShadow: `inset 0 0 24px ${def.tint}0e, 0 0 22px ${def.tint}0b`,
        }}
      >
        <VirusPreview
          levels={levels}
          preview={def}
          size={144}
          scale={0.78}
          className="mutation-preview-canvas"
        />
      </div>

      <div className="display mt-1 text-base leading-tight" style={{ color: def.tint }}>
        {def.name}
      </div>
      <div className="mono text-[8px] tracking-[0.22em] text-emerald-200/45">
        {translateMutationKind(def.kind)}
      </div>
      <p className="mono mt-2 text-[10px] leading-snug text-emerald-100/75">
        {def.levels[Math.min(2, next - 1)]}
      </p>
      <div
        className="mt-2 flex gap-1"
        role="img"
        aria-label={
          currentLevel >= 3
            ? "Мутация полностью улучшена: 3 из 3 уровней"
            : `Уже получено: ${currentLevel} из 3. Следующий уровень ${next} показан контуром и будет получен после выбора.`
        }
        title={currentLevel >= 3 ? "Максимальный уровень" : `Сейчас ${currentLevel}/3; после выбора станет ${next}/3`}
      >
        {[1, 2, 3].map((tier) => {
          const status = getMutationTierStatus(currentLevel, tier);
          const owned = status === "owned";
          const previewTier = status === "preview";
          return (
            <span
              key={tier}
              className="h-1.5 w-5 rounded-full"
              title={owned ? `Уровень ${tier} уже получен` : previewTier ? `Уровень ${tier} — предпросмотр улучшения` : `Уровень ${tier} пока закрыт`}
              style={{
                background: owned ? def.tint : previewTier ? `${def.tint}24` : "rgba(255,255,255,0.12)",
                boxShadow: owned ? `0 0 8px ${def.tint}` : previewTier ? `0 0 5px ${def.tint}44` : "none",
                outline: previewTier ? `1px solid ${def.tint}cc` : "none",
                outlineOffset: "1px",
              }}
            />
          );
        })}
      </div>
    </button>
  );
}

export function MutationModal({
  hud,
  selected,
  onChoose,
  onSelect,
}: {
  hud: HudSnapshot;
  selected: number;
  onChoose: (id: string) => void;
  onSelect: (i: number) => void;
}) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Выбор мутации"
      className="mutation-overlay absolute inset-0 flex flex-col items-center justify-start overflow-y-auto bg-black/60 p-3 backdrop-blur-sm sm:justify-center sm:p-6"
    >
      <div className="pop-in w-full max-w-4xl py-2">
        <div className="mb-3 text-center">
          <div className="mono text-[9px] tracking-[0.45em] text-lime-300/70">
            ГЕНОМ ПЕРЕПОЛНЕН
          </div>
          <h2
            className="display text-2xl sm:text-4xl"
            style={{
              color: "#c8ff4d",
              textShadow: "0 0 26px rgba(200,255,77,0.45)",
            }}
          >
            ДОСТУПНА МУТАЦИЯ
          </h2>
          <div className="mono mt-1 text-[10px] tracking-[0.2em] text-emerald-200/60">
            ВЫБЕРИ ОДНУ МУТАЦИЮ — ОНА ИЗМЕНИТ ТВОЁ ТЕЛО
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {hud.choices.map((def, i) => (
            <MutationCard
              key={def.id}
              def={def}
              level={hud.levels[def.id] ?? 0}
              index={i}
              selected={i === selected}
              levels={hud.levels}
              onChoose={() => onChoose(def.id)}
              onHover={() => onSelect(i)}
            />
          ))}
        </div>

        <div className="mono mt-3 text-center text-[9px] tracking-[0.22em] text-emerald-200/45">
          НАЖМИ 1 · 2 · 3 ИЛИ ВЫБЕРИ МЫШЬЮ — МУТАЦИИ УСИЛИВАЮТСЯ В ТЕЧЕНИЕ ЗАБЕГА
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function PauseOverlay({
  hud,
  onResume,
  onNewRun,
  onRetryStage,
  onMenu,
  onHelp,
  onEvolutionMap,
  muted,
  onMute,
}: {
  hud: HudSnapshot;
  onResume: () => void;
  onNewRun: () => void;
  onRetryStage: () => void;
  onMenu: () => void;
  onHelp: () => void;
  onEvolutionMap: () => void;
  muted: boolean;
  onMute: () => void;
}) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Пауза"
      className="absolute inset-0 flex items-center justify-center bg-black/65 p-4 backdrop-blur-md"
    >
      <div className="glass pop-in w-full max-w-md rounded-2xl p-5">
        <div className="mono text-center text-[9px] tracking-[0.45em] text-emerald-300/60">
          ИГРА ПРИОСТАНОВЛЕНА
        </div>
        <h2
          className="display mb-3 text-center text-3xl sm:text-4xl"
          style={{ color: "#7dff5e", textShadow: "0 0 22px rgba(125,255,94,0.4)" }}
        >
          ПАУЗА
        </h2>

        <div className="mb-3 grid grid-cols-3 gap-2">
          <StatBox label="ОЧКИ" value={hud.score.toLocaleString("ru-RU")} tint="#c8ff4d" />
          <StatBox label="ДНК" value={`${hud.collected}/${hud.quota}`} />
          <StatBox label="ВРЕМЯ" value={formatTime(hud.time)} />
        </div>

        <div className="grid gap-2">
          <button className="btn btn-primary" onClick={onResume}>
            ▶ ПРОДОЛЖИТЬ (ESC)
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button className="btn" onClick={onRetryStage}>
              ↻ ПОВТОРИТЬ ЗОНУ
            </button>
            <button className="btn" onClick={onHelp}>
              ? УПРАВЛЕНИЕ
            </button>
            <button className="btn !px-2 !text-[10px] !tracking-[0.06em]" onClick={onEvolutionMap}>
              ✦ ЭВОЛЮЦИЯ
            </button>
            <button className="btn" onClick={onMute}>
              {muted ? "🔇 ЗВУК ВЫКЛЮЧЕН" : "🔊 ЗВУК ВКЛЮЧЁН"}
            </button>
            <button className="btn btn-ghost" onClick={onNewRun}>
              ⟲ НОВЫЙ ЗАБЕГ
            </button>
          </div>
          <button className="btn btn-ghost" onClick={onMenu}>
            ⌂ ГЛАВНОЕ МЕНЮ
          </button>
        </div>
        <div className="mono mt-3 text-center text-[9px] tracking-[0.2em] text-emerald-200/40">
          ВСЕ ТАЙМЕРЫ И ОРГАНИЗМЫ ЗАМОРОЖЕНЫ
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function StageClear({
  hud,
  onNext,
  onRetry,
  onLevelSelect,
}: {
  hud: HudSnapshot;
  onNext: () => void;
  onRetry: () => void;
  onLevelSelect: () => void;
}) {
  const nextStage = STAGES[Math.min(hud.stageIndex + 1, STAGES.length - 1)];
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Зона пройдена"
      className="absolute inset-0 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md"
    >
      <div className="glass pop-in w-full max-w-md rounded-2xl p-5 text-center">
        <div className="mono text-[9px] tracking-[0.45em] text-lime-300/70">
          ЗАЩИТА КЛЕТКИ ПРОРВАНА
        </div>
        <h2
          className="display text-3xl sm:text-5xl"
          style={{ color: "#c8ff4d", textShadow: "0 0 28px rgba(200,255,77,0.5)" }}
        >
          ЗОНА ПРОЙДЕНА
        </h2>

        <div className="my-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <StatBox label="ОЧКИ" value={hud.score.toLocaleString("ru-RU")} tint="#c8ff4d" />
          <StatBox label="СОБРАНО ДНК" value={`${hud.dnaTotal}`} />
          <StatBox label="ПОБЕЖДЕНО ВРАГОВ" value={`${hud.kills}`} />
          <StatBox label="ВРЕМЯ" value={formatTime(hud.time)} />
        </div>

        <div className="glass-soft mb-3 rounded-xl p-3">
          <div className="mono text-[8px] tracking-[0.3em] text-emerald-200/45">
            СЛЕДУЮЩАЯ ЗОНА
          </div>
          <div className="display text-lg text-emerald-100">{nextStage.name}</div>
          <div className="mono text-[9px] tracking-[0.18em] text-emerald-200/50">
            {nextStage.subtitle}
          </div>
        </div>

        <div className="grid gap-2">
          <button className="btn btn-primary glow-pulse" onClick={onNext}>
            ▶ ПЕРЕЙТИ В СЛЕДУЮЩУЮ ЗОНУ
          </button>
          <button className="btn" onClick={onLevelSelect}>
            ▦ ВЫБРАТЬ ПРОЙДЕННУЮ ЗОНУ
          </button>
          <button className="btn btn-ghost" onClick={onRetry}>
            ↻ ПОВТОРИТЬ ЭТУ ЗОНУ
          </button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

/** Lightweight procedural ending scene: no external video asset or codec required. */
function VictoryCinematic({ score, onSkip }: { score: number; onSkip: () => void }) {
  const surroundingCells = [
    [95, 112, 22], [180, 315, 15], [292, 82, 13], [340, 345, 19],
    [630, 75, 18], [740, 330, 21], [860, 120, 14], [825, 400, 10],
    [515, 388, 11], [120, 410, 9], [700, 150, 9], [260, 215, 8],
  ];
  return (
    <div role="dialog" aria-modal="true" aria-label="Победная заставка VIRUS" className="absolute inset-0 z-50 flex items-center justify-center overflow-hidden bg-[#010609] p-4 sm:p-8">
      <div className="victory-backdrop pointer-events-none absolute inset-0" />
      <div className="relative z-10 flex w-full max-w-5xl flex-col items-center text-center">
        <div className="mono victory-reveal text-[9px] tracking-[0.48em] text-lime-200/65 sm:text-xs">ФИНАЛЬНЫЙ ПРОТОКОЛ · ХОЗЯИН ПОРАЖЁН</div>
        <div className="victory-scene mt-2 w-full">
          <svg viewBox="0 0 960 470" className="mx-auto block w-full max-w-4xl overflow-visible" role="img" aria-label="Анимированное заражение клетки вирусом">
            <defs>
              <radialGradient id="victoryHostFill"><stop offset="0%" stopColor="#173d45" stopOpacity="0.9" /><stop offset="74%" stopColor="#0a2832" stopOpacity="0.72" /><stop offset="100%" stopColor="#35cbd0" stopOpacity="0.12" /></radialGradient>
              <radialGradient id="victoryVirusFill"><stop offset="0%" stopColor="#efff9d" /><stop offset="38%" stopColor="#b2ff4d" /><stop offset="100%" stopColor="#31ab43" /></radialGradient>
              <filter id="victoryGlow"><feGaussianBlur stdDeviation="7" result="blur" /><feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
            </defs>
            {surroundingCells.map(([x, y, r], i) => (
              <g key={`cell-${i}`} className="victory-cell" style={{ animationDelay: `${i * -0.31}s` }}>
                <circle cx={x} cy={y} r={r * 1.9} fill={i % 3 === 0 ? "#5ef0ff" : "#c8ff4d"} opacity="0.08" />
                <circle cx={x} cy={y} r={r} fill={i % 3 === 0 ? "#2ea8b7" : "#70c950"} fillOpacity="0.18" stroke={i % 3 === 0 ? "#74e9ff" : "#c8ff4d"} strokeOpacity="0.55" strokeWidth="1.5" />
                <circle cx={x + r * 0.18} cy={y - r * 0.16} r={r * 0.34} fill="#edfff0" opacity="0.6" />
              </g>
            ))}
            <circle className="victory-wave" cx="480" cy="228" r="182" fill="none" stroke="#9bff61" strokeWidth="2" />
            <circle className="victory-wave victory-wave-delay" cx="480" cy="228" r="182" fill="none" stroke="#5ef0ff" strokeWidth="2" />
            <circle cx="480" cy="228" r="146" fill="url(#victoryHostFill)" stroke="#77f7e0" strokeOpacity="0.75" strokeWidth="5" filter="url(#victoryGlow)" />
            <circle cx="480" cy="228" r="124" fill="none" stroke="#7be9da" strokeOpacity="0.32" strokeWidth="2" strokeDasharray="8 12" />
            <path className="victory-membrane" d="M 391 140 C 440 98, 525 111, 565 153 S 602 249, 562 287 S 448 329, 394 286 S 355 184, 391 140" fill="none" stroke="#b1fff0" strokeOpacity="0.45" strokeWidth="3" />
            <g transform="translate(480 228)" filter="url(#victoryGlow)">
              <g className="victory-virus-float">
                <g className="victory-virus-rotate">
                {Array.from({ length: 18 }, (_, i) => (
                  <g key={`spike-${i}`} transform={`rotate(${i * 20})`}>
                    <path d="M -5 -56 L 0 -91 L 5 -56 Z" fill="#a8ff45" stroke="#ddff89" strokeWidth="2" />
                    <circle cx="0" cy="-88" r="4.5" fill="#efff9b" />
                  </g>
                ))}
                <circle r="61" fill="url(#victoryVirusFill)" stroke="#dbff98" strokeWidth="4" />
                <circle r="42" fill="#51be42" stroke="#1b7c39" strokeWidth="3" />
                <circle cx="-12" cy="-9" r="13" fill="#e6ffab" opacity="0.55" />
                <circle cx="15" cy="13" r="9" fill="#e6ffab" opacity="0.38" />
                {Array.from({ length: 8 }, (_, i) => <circle key={`genome-${i}`} cx={Math.cos(i * Math.PI / 4) * 25} cy={Math.sin(i * Math.PI / 4) * 25} r="3.8" fill="#ecff9d" opacity="0.85" />)}
                </g>
              </g>
            </g>
            <g className="victory-genome" fill="none" stroke="#d9ff70" strokeWidth="3" strokeLinecap="round">
              <path d="M 455 210 C 500 225, 460 246, 505 261" />
              <path d="M 505 210 C 460 225, 500 246, 455 261" />
              {Array.from({ length: 4 }, (_, i) => <path key={`rung-${i}`} d={`M ${464 + (i % 2) * 7} ${218 + i * 10} L ${496 - (i % 2) * 7} ${218 + i * 10}`} opacity="0.6" />)}
            </g>
          </svg>
        </div>
        <div className="victory-reveal" style={{ animationDelay: "0.7s" }}>
          <div className="display text-4xl leading-none sm:text-7xl" style={{ color: "#c8ff4d", textShadow: "0 0 28px rgba(200,255,77,0.48), 0 0 80px rgba(94,240,255,0.2)" }}>VIRUS</div>
          <div className="mono mt-2 text-[10px] tracking-[0.34em] text-emerald-100/75 sm:text-sm">ПАНДЕМИЯ ЗАПУЩЕНА</div>
          <div className="mono mt-2 text-[9px] tracking-[0.2em] text-emerald-200/45">ИТОГОВЫЙ СЧЁТ · {score.toLocaleString("ru-RU")}</div>
        </div>
        <button className="btn btn-primary mt-5" onClick={onSkip}>ПРОПУСТИТЬ ЗАСТАВКУ / К ИТОГАМ</button>
        <div className="victory-timeline mt-4 h-1 w-full max-w-md overflow-hidden rounded-full bg-emerald-100/10"><div className="h-full rounded-full bg-lime-300" /></div>
        <div className="mono mt-2 text-[8px] tracking-[0.24em] text-emerald-100/30">КИНЕМАТОГРАФИЧЕСКАЯ СЦЕНА · НАЖМИ КНОПКУ, ЧТОБЫ ПРОПУСТИТЬ</div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function RunEnd({
  hud,
  scores,
  victory,
  onNewRun,
  onRetry,
  onMenu,
  onLevelSelect,
}: {
  hud: HudSnapshot;
  scores: ScoreEntry[];
  victory: boolean;
  onNewRun: () => void;
  onRetry: () => void;
  onMenu: () => void;
  onLevelSelect: () => void;
}) {
  const [showCinematic, setShowCinematic] = useState(victory);
  useEffect(() => {
    if (!victory) {
      setShowCinematic(false);
      return;
    }
    setShowCinematic(true);
    const timer = window.setTimeout(() => setShowCinematic(false), 10500);
    return () => window.clearTimeout(timer);
  }, [victory]);

  if (victory && showCinematic) {
    return <VictoryCinematic score={hud.score} onSkip={() => setShowCinematic(false)} />;
  }

  const rank =
    hud.score > 12000
      ? "S — ЛЕГЕНДАРНЫЙ ВИРУС"
      : hud.score > 8000
        ? "A — ВИРУСНЫЙ ШТАММ"
        : hud.score > 4500
          ? "B — АГРЕССИВНЫЙ ШТАММ"
          : hud.score > 2000
            ? "C — УСТОЙЧИВЫЙ ШТАММ"
            : "D — СЛАБЫЙ ШТАММ";

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={victory ? "Итоги победного забега" : "Итоги забега"}
      className="absolute inset-0 flex items-center justify-center bg-black/75 p-3 backdrop-blur-md sm:p-6"
    >
      <div className="pop-in grid w-full max-w-3xl gap-3 sm:grid-cols-[1fr_0.85fr]">
        <div
          className="glass rounded-2xl p-5 text-center"
          style={{
            borderColor: victory ? "rgba(200,255,77,0.4)" : "rgba(255,45,85,0.35)",
          }}
        >
          <div className="mono text-[9px] tracking-[0.45em] text-emerald-300/60">
            {victory ? "ЗАРАЖЕНИЕ ЗАВЕРШЕНО" : "КАПСИД РАЗРУШЕН"}
          </div>
          <h2
            className="display text-3xl sm:text-5xl"
            style={{
              color: victory ? "#c8ff4d" : "#ff5f7e",
              textShadow: `0 0 28px ${victory ? "rgba(200,255,77,0.5)" : "rgba(255,95,126,0.5)"}`,
            }}
          >
            {victory ? "ПАНДЕМИЯ" : "ПОРАЖЕНИЕ"}
          </h2>
          <p className="mono mt-1 text-[10px] leading-relaxed tracking-[0.14em] text-emerald-200/60">
            {victory
              ? "ЯДРО ТЕПЕРЬ ТВОЁ. ОРГАНИЗМ ПОД ТВОИМ КОНТРОЛЕМ."
              : "ИММУННАЯ СИСТЕМА ПОБЕДИЛА. ЭВОЛЮЦИОНИРУЙ И ПОПРОБУЙ СНОВА."}
          </p>

          <div className="display my-3 text-4xl sm:text-5xl" style={{ color: "#ffe066" }}>
            {hud.score.toLocaleString("ru-RU")}
          </div>
          <div className="mono text-[9px] tracking-[0.3em] text-emerald-200/50">
            {rank}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            <StatBox
              label="ЗОНА"
              value={`${hud.stageIndex + 1}/${hud.stageCount}`}
            />
            <StatBox label="СОБРАНО ДНК" value={`${hud.dnaTotal}`} tint="#c8ff4d" />
            <StatBox label="ПОБЕЖДЕНО ВРАГОВ" value={`${hud.kills}`} />
            <StatBox label="МУТАЦИИ" value={`${hud.evolutions}`} tint="#5ef0ff" />
          </div>

          <div className="mt-4 grid gap-2">
            <button className="btn btn-primary glow-pulse" onClick={onNewRun}>
              ⟲ НАЧАТЬ ЗАНОВО (R)
            </button>
            <div className="grid grid-cols-2 gap-2">
              <button className="btn" onClick={onRetry}>
                ↻ ПОВТОРИТЬ ЗОНУ
              </button>
              <button className="btn" onClick={onLevelSelect}>
                ▦ ВЫБОР УРОВНЯ
              </button>
              <button className="btn btn-ghost" onClick={onMenu}>
                ⌂ ГЛАВНОЕ МЕНЮ
              </button>
            </div>
          </div>
        </div>

        <div className="glass-soft rounded-2xl p-3">
          <ScoreTable scores={scores} />
          <div className="mono mt-3 text-[9px] leading-relaxed tracking-wider text-emerald-200/40">
            СОВЕТ: РЫВОК УНИЧТОЖАЕТ МЕЛКИХ ОРГАНИЗМОВ И ПОМОГАЕТ ИЗБЕЖАТЬ УРОНА.
            СНАЧАЛА УСИЛЬ СБОР ДНК, А ЗАТЕМ СОСРЕДОТОЧЬСЯ НА АТАКЕ.
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function HelpModal({ onClose }: { onClose: () => void }) {
  const rows = [
    ["ДВИЖЕНИЕ", "W A S D / клавиши со стрелками"],
    ["МЫШЬ", "Зажми кнопку мыши — вирус следует за курсором"],
    ["СЕНСОРНЫЙ ЭКРАН", "Проведи пальцем в любом месте — появится виртуальный джойстик"],
    ["РЫВОК", "ПРОБЕЛ · SHIFT · правая кнопка мыши · кнопка рывка"],
    ["ПАУЗА", "ESC или P"],
    ["ПЕРЕЗАПУСК", "R (во время паузы или после поражения)"],
    ["МУТАЦИЯ", "1 · 2 · 3 или нажми на карточку"],
  ];
  const bestiary = [
    ["#ff9f5e", "КРОШКА", "Безобидно дрейфует. Соверши рывок сквозь неё, чтобы получить ДНК."],
    ["#c98bff", "СПОРА", "При уничтожении разделяется на две."],
    ["#ff6bd6", "МАКРОФАГ", "Преследует тебя. Отвлеки его и резко смени направление."],
    ["#ff7a2f", "ШИПОВАЯ МИНА", "Не двигается, но смертельно опасна при касании. Взрывается."],
    ["#8fc6ff", "АНТИТЕЛО", "Держится на расстоянии и стреляет самонаводящимися сгустками."],
    ["#ffd45e", "СТРАЖ", "Финальный защитник. Его щит отключится, когда будет собрано нужное количество ДНК."],
  ];
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/75 p-3 backdrop-blur-md sm:p-6">
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Справка по игре"
        className="glass pop-in no-scrollbar max-h-full w-full max-w-2xl overflow-y-auto rounded-2xl p-5"
      >
        <div className="mono text-[9px] tracking-[0.45em] text-emerald-300/60">
          ПАМЯТКА ВИРУСА
        </div>
        <h2
          className="display mb-3 text-2xl sm:text-3xl"
          style={{ color: "#7dff5e" }}
        >
          КАК ИГРАТЬ
        </h2>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <div className="mono mb-1.5 text-[9px] tracking-[0.3em] text-emerald-200/50">
              УПРАВЛЕНИЕ
            </div>
            <div className="overflow-hidden rounded-lg border border-emerald-300/12">
              {rows.map(([k, v]) => (
                <div
                  key={k}
                  className="mono flex items-center justify-between gap-3 px-2.5 py-1.5 text-[10px] tracking-wider odd:bg-white/[0.02]"
                >
                  <span className="text-lime-300">{k}</span>
                  <span className="text-right text-emerald-100/70">{v}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="mono mb-1.5 text-[9px] tracking-[0.3em] text-emerald-200/50">
              ВРАГИ
            </div>
            <div className="space-y-1.5">
              {bestiary.map(([c, n, d]) => (
                <div key={n} className="flex items-start gap-2">
                  <span
                    className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ background: c, boxShadow: `0 0 10px ${c}` }}
                  />
                  <div>
                    <span className="mono text-[10px] font-bold tracking-widest text-emerald-100">
                      {n}
                    </span>
                    <span className="mono block text-[10px] leading-snug text-emerald-200/60">
                      {d}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mono mt-4 rounded-lg border border-lime-300/20 bg-lime-300/5 p-3 text-[10px] leading-relaxed tracking-wider text-lime-200/80">
          <b className="text-lime-300">КАК УСТРОЕНА ИГРА:</b> собирай ДНК → заполняй шкалу эволюции →
          выбирай одну из трёх мутаций → наблюдай, как меняется твоё тело. В каждой зоне
          нужно собрать необходимое количество ДНК, чтобы открылась мембрана клетки хозяина.
          Соверши рывок внутрь открытой клетки, чтобы заразить её и перейти в следующую зону.
        </div>

        <button className="btn btn-primary mt-4 w-full" onClick={onClose}>
          ✓ ПОНЯТНО
        </button>
      </div>
    </div>
  );
}
