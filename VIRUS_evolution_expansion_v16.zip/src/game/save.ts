import type { ScoreEntry } from "./types";

const KEY = "virus.highscores.v1";
const MAX = 8;

function isRealCalendarDate(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function cleanScoreEntry(value: unknown): ScoreEntry | null {
  if (!isRecord(value)) return null;
  const { score, stage, victory, evolutions, date } = value;
  if (typeof score !== "number" || !Number.isFinite(score) || score < 0 || score > Number.MAX_SAFE_INTEGER) return null;
  if (!Number.isInteger(stage) || (stage as number) < 0 || (stage as number) > 7) return null;
  if (typeof victory !== "boolean") return null;
  if (typeof evolutions !== "number" || !Number.isFinite(evolutions) || evolutions < 0 || evolutions > Number.MAX_SAFE_INTEGER) return null;
  if (!isRealCalendarDate(date)) return null;
  return {
    score: Math.floor(score),
    stage: stage as number,
    victory,
    evolutions: Math.floor(evolutions),
    date,
  };
}

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map(cleanScoreEntry)
      .filter((entry): entry is ScoreEntry => entry !== null)
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX);
  } catch {
    return [];
  }
}

export function saveScore(entry: ScoreEntry): ScoreEntry[] {
  const clean = cleanScoreEntry(entry);
  if (!clean) return loadScores();
  const list = loadScores();
  list.push(clean);
  list.sort((a, b) => b.score - a.score);
  const trimmed = list.slice(0, MAX);
  try {
    localStorage.setItem(KEY, JSON.stringify(trimmed));
  } catch {
    /* storage may be unavailable — scores simply won't persist */
  }
  return trimmed;
}

export function clearScores() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

const SEEN = "virus.seen.v1";

export function hasSeenIntro(): boolean {
  try {
    return localStorage.getItem(SEEN) === "1";
  } catch {
    return false;
  }
}

export function markIntroSeen() {
  try {
    localStorage.setItem(SEEN, "1");
  } catch {
    /* ignore */
  }
}


/** Campaign completion is separate from high scores and survives reloads. */
const CAMPAIGN_KEY = "virus.campaign-progress.v1";
// Redundant monotonic records protect previously-cleared zones if a stale or
// partially-written progress object ever replaces the primary save.
const CAMPAIGN_BACKUP_KEY = "virus.campaign-progress.backup.v1";
const COMPLETED_STAGES_KEY = "virus.completed-stages.v1";

export interface CampaignProgress {
  completedStages: number[];
  /** Best mutation loadout recorded when each zone was completed. */
  loadouts: Record<string, Record<string, number>>;
  /** Strongest recorded build at the moment each zone was entered in campaign mode. */
  entryBuilds: Record<string, Record<string, number>>;
}

export interface RunTotals {
  dna: number;
  kills: number;
  time: number;
  evolutions: number;
}

/** A safe zone-entry checkpoint. It resumes from the beginning of the last zone,
 * preserving that zone's entry build and campaign totals rather than serializing
 * transient canvas/physics objects. Standalone level replays never overwrite it. */
export interface ActiveRunCheckpoint {
  stageId: number;
  score: number;
  levels: Record<string, number>;
  totals: RunTotals;
  /** Invalidates checkpoints from a campaign that has already ended/restarted. */
  generation: number;
  savedAt: number;
}

export type PermanentUpgradeId = "vitality" | "mobility" | "harvest";
export type PermanentUpgradeLevels = Record<PermanentUpgradeId, number>;

export interface MetaProgress {
  essence: number;
  upgrades: PermanentUpgradeLevels;
  rewardedStages: number[];
  revision: number;
}

export const PERMANENT_UPGRADE_DEFS: Record<PermanentUpgradeId, {
  name: string;
  description: string;
  effect: string[];
  costs: number[];
}> = {
  vitality: {
    name: "Укреплённая мембрана",
    description: "Увеличивает максимальное здоровье в каждом новом уровне.",
    effect: ["+8 HP", "+16 HP", "+24 HP"],
    costs: [2, 4, 6],
  },
  mobility: {
    name: "Метаболический импульс",
    description: "Постоянно увеличивает скорость перемещения.",
    effect: ["+4% скорости", "+8% скорости", "+12% скорости"],
    costs: [2, 4, 6],
  },
  harvest: {
    name: "Эффективный метаболизм",
    description: "Увеличивает очки за собранную ДНК.",
    effect: ["+5% очков ДНК", "+10% очков ДНК", "+15% очков ДНК"],
    costs: [2, 4, 6],
  },
};

const ACTIVE_RUN_KEY = "virus.active-run.v1";
const ACTIVE_RUN_BACKUP_KEY = "virus.active-run.backup.v1";
// A monotonic generation invalidates stale checkpoint copies even if a localStorage
// removeItem fails. Keep a redundant copy for private-mode/quota edge cases.
const ACTIVE_RUN_EPOCH_KEY = "virus.active-run-epoch.v1";
const ACTIVE_RUN_EPOCH_BACKUP_KEY = "virus.active-run-epoch.backup.v1";
const META_KEY = "virus.meta-progress.v1";
const META_BACKUP_KEY = "virus.meta-progress.backup.v1";
const REWARDED_STAGES_KEY = "virus.meta-rewarded-stages.v1";
const ESSENCE_PER_FIRST_CLEAR = 5;
const MAX_SAVED_COUNTER = 1_000_000_000;
const MAX_CHECKPOINT_FUTURE_SKEW_MS = 30 * 24 * 60 * 60 * 1000;

const EMPTY_UPGRADES = (): PermanentUpgradeLevels => ({ vitality: 0, mobility: 0, harvest: 0 });
const EMPTY_META = (): MetaProgress => ({ essence: 0, upgrades: EMPTY_UPGRADES(), rewardedStages: [], revision: 0 });

const VALID_STAGE_ID = (id: unknown): id is number =>
  typeof id === "number" && Number.isInteger(id) && id >= 1 && id <= 8;

function readStoredJSON(key: string): unknown {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) as unknown : null;
  } catch {
    return null;
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function cleanCompletedStages(value: unknown): number[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter(VALID_STAGE_ID))].sort((a, b) => a - b);
}

const KNOWN_MUTATION_IDS = new Set([
  "flagellum", "cilia", "phase", "plating", "regen", "magnet",
  "net", "enzymes", "fission", "taxis", "volt", "barbs",
]);

function cleanLoadout(value: unknown): Record<string, number> {
  if (!isRecord(value)) return {};
  const clean: Record<string, number> = {};
  for (const [id, level] of Object.entries(value)) {
    // Stored values are untrusted. Keep only real mutation ids and valid ranks.
    if (KNOWN_MUTATION_IDS.has(id) && typeof level === "number" && Number.isFinite(level) && level > 0) {
      const rank = Math.min(3, Math.floor(level));
      // A fractional stored value such as 0.5 floors to zero and is not a real
      // mutation rank. Do not persist zero-valued keys in an otherwise clean build.
      if (rank >= 1) clean[id] = rank;
    }
  }
  return clean;
}

function loadoutStrength(loadout: Record<string, number>): number {
  return Object.values(loadout).reduce((sum, level) => sum + level, 0);
}

/**
 * Loads the union of primary, backup and monotonic completion records.
 * Completed zones are never removed just because another save copy is stale.
 */
export function loadCampaignProgress(): CampaignProgress {
  const candidates = [
    readStoredJSON(CAMPAIGN_KEY),
    readStoredJSON(CAMPAIGN_BACKUP_KEY),
  ].filter(isRecord);

  const completed = new Set<number>();
  const loadouts: Record<string, Record<string, number>> = {};
  const entryBuilds: Record<string, Record<string, number>> = {};

  for (const candidate of candidates) {
    for (const stageId of cleanCompletedStages(candidate.completedStages)) {
      completed.add(stageId);
    }
    for (const [field, target] of [
      ["loadouts", loadouts],
      ["entryBuilds", entryBuilds],
    ] as const) {
      const builds = candidate[field];
      if (!isRecord(builds)) continue;
      for (const [stageId, rawBuild] of Object.entries(builds)) {
        if (!/^([1-8])$/.test(stageId)) continue;
        const build = cleanLoadout(rawBuild);
        if (!Object.prototype.hasOwnProperty.call(target, stageId) ||
            loadoutStrength(build) > loadoutStrength(target[stageId])) {
          target[stageId] = build;
        }
      }
    }
  }

  const standaloneCompleted = cleanCompletedStages(readStoredJSON(COMPLETED_STAGES_KEY));
  for (const stageId of standaloneCompleted) completed.add(stageId);

  // Unlock history is sequential. A corrupt payload such as [1, 3] must not
  // make zones 3–4 selectable while zone 2 is missing. Preserve only the
  // contiguous prefix; valid saves are unchanged because real campaigns are sequential.
  const contiguousCompleted: number[] = [];
  for (let stageId = 1; stageId <= MAX; stageId++) {
    if (!completed.has(stageId)) break;
    contiguousCompleted.push(stageId);
  }

  return {
    completedStages: contiguousCompleted,
    loadouts,
    entryBuilds,
  };
}

function persistCampaignProgress(progress: CampaignProgress): void {
  const payload = JSON.stringify(progress);
  const completedPayload = JSON.stringify(progress.completedStages);
  // Write independently: if one write fails (quota, private mode, etc.), the
  // other copies still retain the monotonically increasing completion list.
  for (const [key, value] of [
    [CAMPAIGN_KEY, payload],
    [CAMPAIGN_BACKUP_KEY, payload],
    [COMPLETED_STAGES_KEY, completedPayload],
  ] as const) {
    try {
      localStorage.setItem(key, value);
    } catch {
      // Keep the game playable even when browser storage is unavailable.
    }
  }
}

function cleanTotals(value: unknown): RunTotals {
  const record = isRecord(value) ? value : {};
  const cleanCount = (v: unknown) =>
    typeof v === "number" && Number.isFinite(v) && v >= 0
      ? Math.min(MAX_SAVED_COUNTER, Math.floor(v))
      : 0;
  const cleanTime = (v: unknown) =>
    typeof v === "number" && Number.isFinite(v) && v >= 0
      ? Math.min(MAX_SAVED_COUNTER, v)
      : 0;
  return {
    dna: cleanCount(record.dna),
    kills: cleanCount(record.kills),
    time: cleanTime(record.time),
    evolutions: cleanCount(record.evolutions),
  };
}

function validRunGeneration(value: unknown): value is number {
  // A real game cannot start a million campaigns in ordinary use. The explicit
  // bound prevents a corrupt but safe integer from poisoning every later save.
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= 1_000_000;
}

function validCheckpointTimestamp(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 &&
    value <= Date.now() + MAX_CHECKPOINT_FUTURE_SKEW_MS;
}

function validCheckpointScore(value: unknown): value is number {
  // Runtime scores are whole numbers; accepting Number.MAX_VALUE here would
  // produce a technically finite but unusable checkpoint.
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}

function loadActiveRunGeneration(): number {
  const generations = [ACTIVE_RUN_EPOCH_KEY, ACTIVE_RUN_EPOCH_BACKUP_KEY]
    .map((key) => readStoredJSON(key))
    .filter(validRunGeneration);
  return generations.length ? Math.max(...generations) : 0;
}

function persistActiveRunGeneration(generation: number): boolean {
  let successes = 0;
  for (const key of [ACTIVE_RUN_EPOCH_KEY, ACTIVE_RUN_EPOCH_BACKUP_KEY]) {
    try { localStorage.setItem(key, JSON.stringify(generation)); successes++; } catch { /* Try the other marker independently. */ }
  }
  return successes > 0;
}

export function loadActiveRunCheckpoint(): ActiveRunCheckpoint | null {
  const generation = loadActiveRunGeneration();
  // Filter all validity criteria before sorting. Otherwise a malformed/newer
  // locked checkpoint could mask an older valid backup and hide Continue.
  const candidates = [readStoredJSON(ACTIVE_RUN_KEY), readStoredJSON(ACTIVE_RUN_BACKUP_KEY)]
    .filter(isRecord)
    .filter((v) => {
      const candidateGeneration = v.generation === undefined ? 0 : v.generation;
      return VALID_STAGE_ID(v.stageId) && canSelectStage(v.stageId) &&
        validCheckpointScore(v.score) && validCheckpointTimestamp(v.savedAt) &&
        validRunGeneration(candidateGeneration) && candidateGeneration === generation;
    });
  if (candidates.length === 0) return null;
  candidates.sort((a, b) => Number(b.savedAt) - Number(a.savedAt));
  const candidate = candidates[0];
  return {
    stageId: candidate.stageId as number,
    score: Math.max(0, Math.floor(candidate.score as number)),
    levels: cleanLoadout(candidate.levels),
    totals: cleanTotals(candidate.totals),
    generation: candidate.generation === undefined ? 0 : candidate.generation as number,
    savedAt: candidate.savedAt as number,
  };
}

export function saveActiveRunCheckpoint(
  checkpoint: Omit<ActiveRunCheckpoint, "savedAt" | "generation">,
): boolean {
  if (!VALID_STAGE_ID(checkpoint.stageId) || !canSelectStage(checkpoint.stageId) ||
      !validCheckpointScore(checkpoint.score)) return false;
  const generation = loadActiveRunGeneration();
  const existing = [readStoredJSON(ACTIVE_RUN_KEY), readStoredJSON(ACTIVE_RUN_BACKUP_KEY)]
    .filter(isRecord)
    .map((v) => v.savedAt)
    .filter(validCheckpointTimestamp);
  const savedAt = Math.max(Date.now(), ...existing.map((value) => value + 1));
  const payload: ActiveRunCheckpoint = {
    stageId: checkpoint.stageId,
    score: Math.floor(checkpoint.score),
    levels: cleanLoadout(checkpoint.levels),
    totals: cleanTotals(checkpoint.totals),
    generation,
    savedAt,
  };
  const json = JSON.stringify(payload);
  let successes = 0;
  for (const key of [ACTIVE_RUN_KEY, ACTIVE_RUN_BACKUP_KEY]) {
    try {
      localStorage.setItem(key, json);
      successes++;
    } catch {
      // Try the backup independently; private mode/quota may reject one write.
    }
  }
  return successes > 0;
}

export function clearActiveRunCheckpoint(): void {
  // Persist the invalidation first. If a stale snapshot survives a failed
  // removeItem, its older generation will still be ignored on the next load.
  const nextGeneration = loadActiveRunGeneration() + 1;
  persistActiveRunGeneration(nextGeneration);
  for (const key of [ACTIVE_RUN_KEY, ACTIVE_RUN_BACKUP_KEY]) {
    try { localStorage.removeItem(key); } catch { /* generation tombstone remains authoritative */ }
  }
}

function cleanMeta(value: unknown): MetaProgress | null {
  if (!isRecord(value)) return null;
  // Revisions and essence are always saved as safe, non-negative integers. A
  // corrupt enormous value must not outrank a healthy backup or create a huge
  // spendable balance. Missing fields are allowed for legacy saves; malformed
  // fields invalidate this copy so the loader can fall back to its backup.
  const validStoredInteger = (v: unknown): v is number =>
    typeof v === "number" && Number.isSafeInteger(v) && v >= 0;
  if (value.revision !== undefined && !validStoredInteger(value.revision)) return null;
  if (value.essence !== undefined && !validStoredInteger(value.essence)) return null;
  const rawUpgrades = isRecord(value.upgrades) ? value.upgrades : {};
  const cleanUpgrade = (id: PermanentUpgradeId) => {
    const raw = rawUpgrades[id];
    return typeof raw === "number" && Number.isFinite(raw) ? Math.max(0, Math.min(3, Math.floor(raw))) : 0;
  };
  const essence = value.essence === undefined ? 0 : value.essence as number;
  const revision = value.revision === undefined ? 0 : value.revision as number;
  return {
    essence,
    upgrades: { vitality: cleanUpgrade("vitality"), mobility: cleanUpgrade("mobility"), harvest: cleanUpgrade("harvest") },
    rewardedStages: cleanCompletedStages(value.rewardedStages),
    revision,
  };
}

export function loadMetaProgress(): MetaProgress {
  const rawPrimary = readStoredJSON(META_KEY);
  const rawBackup = readStoredJSON(META_BACKUP_KEY);
  const candidates = [cleanMeta(rawPrimary), cleanMeta(rawBackup)]
    .filter((v): v is MetaProgress => v !== null)
    .sort((a, b) => b.revision - a.revision);
  const standaloneRewards = cleanCompletedStages(readStoredJSON(REWARDED_STAGES_KEY));

  // One-time migration for saves created before permanent evolution existed:
  // grant the historical first-clear rewards, then mark those zones as rewarded
  // so replaying them cannot farm essence. Do not migrate over corrupted meta
  // copies if the separate monotonic reward record proves meta-progression existed.
  if (candidates.length === 0 && standaloneRewards.length === 0) {
    // If every metadata copy is malformed, recover from campaign history rather
    // than letting a parseable-but-invalid object permanently suppress migration.
    const legacyCompleted = loadCampaignProgress().completedStages;
    if (legacyCompleted.length > 0) {
      const migrated: MetaProgress = {
        ...EMPTY_META(),
        essence: legacyCompleted.length * ESSENCE_PER_FIRST_CLEAR,
        rewardedStages: [...legacyCompleted],
        revision: 0,
      };
      persistMetaProgress(migrated);
      return { ...migrated, revision: 1, upgrades: { ...migrated.upgrades } };
    }
  }

  const selected = candidates[0] ?? EMPTY_META();
  // Treat reward claims as monotonic and reconcile them against campaign history.
  // This recovers a first-clear reward if campaign completion persisted but all
  // reward copies were interrupted/stale. The rewardedStages set prevents farming
  // the reward by replaying the same zone after the recovery is persisted.
  const rewarded = new Set([...selected.rewardedStages, ...standaloneRewards]);
  let essence = selected.essence;
  let recoveredRewards = false;
  for (const stageId of loadCampaignProgress().completedStages) {
    if (rewarded.has(stageId)) continue;
    rewarded.add(stageId);
    essence += ESSENCE_PER_FIRST_CLEAR;
    recoveredRewards = true;
  }
  const reconciled: MetaProgress = {
    ...selected,
    essence,
    upgrades: { ...selected.upgrades },
    rewardedStages: [...rewarded].sort((a, b) => a - b),
  };
  if (recoveredRewards) persistMetaProgress(reconciled);
  return reconciled;
}

function persistMetaProgress(meta: MetaProgress): boolean {
  const next: MetaProgress = { ...meta, revision: meta.revision + 1 };
  const json = JSON.stringify(next);
  let successes = 0;
  for (const key of [META_KEY, META_BACKUP_KEY]) {
    try { localStorage.setItem(key, json); successes++; } catch { /* Try the other copy. */ }
  }
  // The standalone reward marker must not claim a reward was persisted when
  // both metadata copies failed. Otherwise an old meta record plus the newer
  // marker could suppress recovery and permanently lose essence. If no meta
  // copy succeeds, completion history will repair the reward on the next load.
  if (successes > 0) {
    try { localStorage.setItem(REWARDED_STAGES_KEY, JSON.stringify(next.rewardedStages)); } catch { /* Optional monotonic copy. */ }
  }
  return successes > 0;
}

export function buyPermanentUpgrade(id: PermanentUpgradeId): { ok: boolean; progress: MetaProgress } {
  if (!Object.prototype.hasOwnProperty.call(PERMANENT_UPGRADE_DEFS, id)) {
    return { ok: false, progress: loadMetaProgress() };
  }
  const progress = loadMetaProgress();
  const currentLevel = progress.upgrades[id];
  const def = PERMANENT_UPGRADE_DEFS[id];
  if (currentLevel >= def.costs.length) return { ok: false, progress };
  const cost = def.costs[currentLevel];
  if (progress.essence < cost) return { ok: false, progress };
  const next: MetaProgress = {
    ...progress,
    essence: progress.essence - cost,
    upgrades: { ...progress.upgrades, [id]: currentLevel + 1 },
  };
  if (!persistMetaProgress(next)) return { ok: false, progress };
  return { ok: true, progress: loadMetaProgress() };
}

function awardFirstClearEssence(stageId: number): void {
  const meta = loadMetaProgress();
  if (meta.rewardedStages.includes(stageId)) return;
  const next: MetaProgress = {
    ...meta,
    essence: meta.essence + ESSENCE_PER_FIRST_CLEAR,
    rewardedStages: [...new Set([...meta.rewardedStages, stageId])].sort((a, b) => a - b),
  };
  persistMetaProgress(next);
}

export function loadCompletedStages(): number[] {
  return loadCampaignProgress().completedStages;
}

/**
 * Unlocks are sequential: all contiguously cleared zones plus exactly the next
 * campaign frontier remain selectable. A corrupt gap never unlocks future zones,
 * and the frontier stays open after a defeat because the previous zone is cleared.
 */
export function isStageUnlocked(stageId: number, completedStages: number[]): boolean {
  if (!Number.isInteger(stageId) || stageId < 1 || stageId > MAX) return false;
  const completed = new Set(cleanCompletedStages(completedStages));
  let frontier = 1;
  while (frontier < MAX && completed.has(frontier)) frontier++;
  // Only completed stages plus the single next frontier are available. This
  // prevents malformed gaps (e.g. [1, 3]) from unlocking impossible future zones.
  return stageId <= frontier;
}

export function canSelectStage(stageId: number): boolean {
  return isStageUnlocked(stageId, loadCampaignProgress().completedStages);
}

export function loadStageLoadout(stageId: number): Record<string, number> {
  const progress = loadCampaignProgress();
  return { ...(progress.loadouts[String(stageId)] ?? {}) };
}

/**
 * Saves the strongest mutation build seen on campaign entry to a zone.
 * Replays do not call this, so experimenting in replay mode cannot rewrite the
 * build used by the interrupted campaign or the zone's established entry build.
 */
export function saveStageEntryBuild(stageId: number, levels: Record<string, number>): CampaignProgress {
  if (!VALID_STAGE_ID(stageId) || !canSelectStage(stageId)) return loadCampaignProgress();
  const progress = loadCampaignProgress();
  const key = String(stageId);
  const clean = cleanLoadout(levels);
  const hasEntryBuild = Object.prototype.hasOwnProperty.call(progress.entryBuilds, key);
  const oldBuild = progress.entryBuilds[key] ?? {};
  if (!hasEntryBuild || loadoutStrength(clean) >= loadoutStrength(oldBuild)) {
    progress.entryBuilds[key] = clean;
    persistCampaignProgress(progress);
  }
  return progress;
}

/**
 * Restores a zone's recorded campaign-entry build. For legacy saves without this
 * field, fall back to the zone's saved completion build, then the previous zone's
 * completion build (the usual build carried into the next zone).
 */
export function loadStageEntryBuild(stageId: number): Record<string, number> {
  if (!VALID_STAGE_ID(stageId)) return {};
  const progress = loadCampaignProgress();
  const key = String(stageId);
  if (Object.prototype.hasOwnProperty.call(progress.entryBuilds, key)) {
    return { ...progress.entryBuilds[key] };
  }
  if (progress.loadouts[key]) return { ...progress.loadouts[key] };
  if (stageId > 1) return { ...(progress.loadouts[String(stageId - 1)] ?? {}) };
  return {};
}

export function markStageCompleted(
  stageId: number,
  levels: Record<string, number> = {},
): CampaignProgress {
  if (!VALID_STAGE_ID(stageId) || !canSelectStage(stageId)) return loadCampaignProgress();
  const progress = loadCampaignProgress();
  // Completion is monotonic: clear an already completed zone again, never
  // replacing the full history with just the current zone.
  const isFirstClear = !progress.completedStages.includes(stageId);
  if (isFirstClear) awardFirstClearEssence(stageId);
  progress.completedStages = [...new Set([...progress.completedStages, stageId])]
    .sort((a, b) => a - b);

  const cleanLevels = cleanLoadout(levels);
  const oldLoadout = progress.loadouts[String(stageId)] ?? {};
  // Do not replace a previously saved stronger loadout with a weaker replay.
  if (loadoutStrength(cleanLevels) >= loadoutStrength(oldLoadout)) {
    progress.loadouts[String(stageId)] = cleanLevels;
  }
  persistCampaignProgress(progress);
  return progress;
}
