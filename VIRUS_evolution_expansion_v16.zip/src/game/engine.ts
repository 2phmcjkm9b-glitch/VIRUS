import { Input } from "./input";
import { audio } from "./audio";
import { drawScene, drawOverlays, drawVirus, drawPickup } from "./draw";
import { World } from "./world";
import { STAGES, buildTraits, MUTATION_BY_ID, MENU_PALETTE } from "./data";
import {
  canSelectStage,
  clearActiveRunCheckpoint,
  loadActiveRunCheckpoint,
  loadMetaProgress,
  loadStageEntryBuild,
  markStageCompleted,
  saveActiveRunCheckpoint,
  saveStageEntryBuild,
  saveScore,
} from "./save";
import type { HudSnapshot, Phase, RunResult, Vec } from "./types";
import { TAU, clamp, len, norm, rand, sub } from "./math";

const STEP = 1 / 60;

export interface GameCallbacks {
  onHud: (h: HudSnapshot) => void;
  onPhase: (p: Phase) => void;
}

export class Game {
  private canvas: HTMLCanvasElement;
  private container: HTMLElement;
  private ctx: CanvasRenderingContext2D;
  private cb: GameCallbacks;
  private input = new Input();

  private raf = 0;
  private last = 0;
  private acc = 0;
  private time = 0;
  private hudTimer = 0;

  cw = 800;
  ch = 600;
  dpr = 1;
  private viewScale = 1;
  private zoom = 1;

  phase: Phase = "menu";
  world: World | null = null;
  levels: Record<string, number> = {};
  choices: string[] = [];
  menuIndex = 0;
  result: RunResult | null = null;
  private stageStartScore = 0;
  private stageStartLevels: Record<string, number> = {};
  private runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
  private stageStartTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
  private scores: ReturnType<typeof saveScore> | null = null;
  /** Replays are isolated and must never overwrite a suspended campaign checkpoint. */
  private runMode: "campaign" | "replay" = "campaign";
  private permanentUpgrades = loadMetaProgress().upgrades;

  constructor(
    canvas: HTMLCanvasElement,
    container: HTMLElement,
    cb: GameCallbacks,
  ) {
    this.canvas = canvas;
    this.container = container;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.cb = cb;
    this.input.onAnyInput = () => audio.resume();
    this.input.onEvent = (e) => this.handleEvent(e);
    this.input.attach(canvas);
    window.addEventListener("resize", this.resize);
    document.addEventListener("visibilitychange", this.onVisibility);
    this.resize();
    this.buildMenuDecor();
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.input.detach();
    window.removeEventListener("resize", this.resize);
    document.removeEventListener("visibilitychange", this.onVisibility);
  }

  /* ---------------------------------------------------------------- */

  private onVisibility = () => {
    if (document.hidden && this.phase === "playing") this.pause();
  };

  private resize = () => {
    const rect = this.container.getBoundingClientRect();
    this.cw = Math.max(320, Math.round(rect.width));
    this.ch = Math.max(240, Math.round(rect.height));
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.round(this.cw * this.dpr);
    this.canvas.height = Math.round(this.ch * this.dpr);
    this.canvas.style.width = `${this.cw}px`;
    this.canvas.style.height = `${this.ch}px`;
    // Keep a comfortable amount of world visible on any screen.
    this.viewScale = clamp(
      Math.max(this.cw / 1250, this.ch / 1250),
      0.44,
      1.35,
    );
    this.bgGradient = null;
    this.buildMenuDecor();
  };

  private bgGradient: CanvasGradient | null = null;

  /* ---------------------------------------------------------------- */

  private menuDecor: { a: number; d: number; r: number; s: number }[] = [];
  private menuOrbs: { pos: Vec; vel: Vec; seed: number }[] = [];

  private buildMenuDecor() {
    this.menuDecor = [];
    for (let i = 0; i < 16; i++) {
      this.menuDecor.push({
        a: rand(TAU),
        d: rand(420, 90),
        r: rand(140, 40),
        s: rand(0.4, 0.05) * (Math.random() < 0.5 ? -1 : 1),
      });
    }
    this.menuOrbs = [];
    for (let i = 0; i < 12; i++) {
      this.menuOrbs.push({
        pos: { x: rand(this.cw), y: rand(this.ch) },
        vel: { x: rand(30, -30), y: rand(24, -34) },
        seed: rand(100),
      });
    }
  }

  /* ---------------------------------------------------------------- */

  start() {
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.tick);
  }

  private setPhase(p: Phase) {
    if (this.phase === p) return;
    this.phase = p;
    // Drop accumulated fixed-step time at screen transitions. Otherwise a laggy
    // frame can be replayed after a mutation/briefing/pause overlay is dismissed.
    this.acc = 0;
    this.input.gameInput = p === "playing";
    this.cb.onPhase(p);
    this.emit(true);
  }

  private handleEvent(e: string) {
    switch (e) {
      case "pause":
        // Escape pauses active play but never resumes from a pause overlay.
        // This prevents closing Help with Escape from also unpausing the game.
        if (this.phase === "playing") this.pause();
        break;
      case "restart":
        // Global UI handler owns restart confirmation so an active checkpoint
        // cannot be overwritten by this lower-level keyboard listener first.
        break;
      case "confirm":
        if (this.phase === "briefing") this.beginStage();
        // Mutation selection is owned by GameShell's visible keyboard focus;
        // otherwise this second global listener may select stale index zero.
        else if (this.phase === "mutate") break;
        // Dead/won restart is handled by GameShell to avoid duplicate keydown
        // processing and accidental overwrite of a newly created checkpoint.
        else if (this.phase === "dead" || this.phase === "won" || this.phase === "clear") break;
        // The global GameShell key handler advances the clear screen exactly once.
        break;
      case "mute":
        this.toggleMute();
        break;
      default:
        break;
    }
  }

  /* ---------------------------------------------------------------- */

  startRun(forceNew = false): boolean {
    // Do not silently destroy an autosaved run when called from a generic input.
    // The UI asks the player before starting a fresh run over that checkpoint.
    if (loadActiveRunCheckpoint() && !forceNew) return false;
    clearActiveRunCheckpoint();
    this.runMode = "campaign";
    this.result = null;
    this.scores = null;
    this.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    this.loadStage(0, 0, {}, this.runTotals);
    return true;
  }

  /** Continue from the beginning of the last saved zone, using its entry build. */
  continueRun(): boolean {
    const checkpoint = loadActiveRunCheckpoint();
    if (!checkpoint || !canSelectStage(checkpoint.stageId)) return false;
    this.runMode = "campaign";
    this.result = null;
    this.scores = null;
    this.runTotals = { ...checkpoint.totals };
    this.loadStage(
      checkpoint.stageId - 1,
      checkpoint.score,
      { ...checkpoint.levels },
      { ...checkpoint.totals },
    );
    return true;
  }

  /** Start a previously opened zone as an isolated replay. Campaign checkpoint is untouched. */
  startSelectedStage(stageId: number): boolean {
    if (!canSelectStage(stageId)) return false;
    const stageLevels = loadStageEntryBuild(stageId);
    this.runMode = "replay";
    this.result = null;
    this.scores = null;
    this.runTotals = { dna: 0, kills: 0, time: 0, evolutions: 0 };
    this.loadStage(stageId - 1, 0, stageLevels, this.runTotals);
    return true;
  }

  retryStage() {
    const idx = this.world ? this.world.stageIndex : 0;
    this.loadStage(
      idx,
      this.stageStartScore,
      { ...this.stageStartLevels },
      { ...this.stageStartTotals },
    );
  }

  nextStage() {
    const idx = this.world ? this.world.stageIndex : 0;
    const score = this.world ? this.world.score : 0;
    const lv = this.world ? { ...this.world.levels } : {};
    const totals = this.currentRunTotals();
    if (idx + 1 >= STAGES.length) {
      this.finishRun(true, score);
      return;
    }
    this.loadStage(idx + 1, score, lv, totals);
  }

  private currentRunTotals() {
    const w = this.world;
    if (!w) return { ...this.runTotals };
    return {
      dna: this.runTotals.dna + w.dnaTotal,
      kills: this.runTotals.kills + w.kills,
      time: this.runTotals.time + w.time,
      evolutions: this.runTotals.evolutions + w.evolutionCount,
    };
  }

  private loadStage(
    index: number,
    score: number,
    levels: Record<string, number>,
    priorTotals: { dna: number; kills: number; time: number; evolutions: number },
  ) {
    this.stageStartScore = score;
    this.stageStartLevels = { ...levels };
    this.runTotals = { ...priorTotals };
    this.stageStartTotals = { ...priorTotals };
    this.levels = { ...levels };
    this.bgGradient = null;
    const meta = loadMetaProgress();
    this.permanentUpgrades = { ...meta.upgrades };
    this.world = new World(index, this.levels, score, meta.upgrades);
    this.levels = this.world.levels;
    this.menuIndex = 0;
    this.zoom = 1;
    if (this.runMode === "campaign") {
      // Persist a separate zone-entry build so selecting the current frontier
      // after a defeat restores the mutations carried into that zone. A replay
      // never calls this branch and cannot overwrite a suspended campaign build.
      saveStageEntryBuild(this.world.stage.id, this.stageStartLevels);
      saveActiveRunCheckpoint({
        stageId: this.world.stage.id,
        score: this.world.score,
        levels: this.stageStartLevels,
        totals: this.stageStartTotals,
      });
    }
    this.setPhase("briefing");
    audio.play("click");
  }

  pause() {
    if (this.phase !== "playing") return;
    this.setPhase("paused");
    audio.play("click");
  }

  resume() {
    if (this.phase !== "paused") return;
    this.setPhase("playing");
    audio.play("click");
  }

  toMenu() {
    this.world = null;
    this.setPhase("menu");
  }

  toggleMute() {
    audio.setEnabled(!audio.enabled);
    this.emit(true);
  }

  /** Called by the on-screen touch dash button. */
  requestDash() {
    if (this.phase === "playing") this.input.dashQueued = true;
  }

  /** Fired by DOM buttons that need to look like a keyboard press. */
  key(code: string) {
    this.input.onEvent?.(code as never);
  }

  /** Leave the briefing card and take control. */
  beginStage() {
    if (this.phase === "briefing") {
      this.setPhase("playing");
    }
  }

  get currentPhase(): Phase {
    return this.phase;
  }

  choose(id: string) {
    if (this.phase !== "mutate" || !this.world) return;
    const def = MUTATION_BY_ID[id];
    if (!def) return;
    this.world.applyMutation(id);
    this.levels = { ...this.world.levels };
    this.zoom = 1.32;
    this.setPhase("playing");
  }

  moveMenuIndex(delta: number) {
    if (!this.choices.length) return;
    this.menuIndex = (this.menuIndex + delta + this.choices.length) % this.choices.length;
    this.emit(true);
  }

  setMenuIndex(i: number) {
    this.menuIndex = i;
    this.emit(true);
  }

  refreshPermanentUpgrades() {
    // New zone/run constructors read the latest persistent levels. This method
    // refreshes the menu specimen immediately without changing an active world.
    this.permanentUpgrades = { ...loadMetaProgress().upgrades };
    this.emit(true);
  }

  get muted() {
    return !audio.enabled;
  }

  /* ---------------------------------------------------------------- */

  private finishRun(victory: boolean, score: number) {
    if (!this.world) return;
    const totals = this.currentRunTotals();
    this.result = {
      score,
      stageIndex: this.world.stageIndex,
      victory,
      dna: totals.dna,
      kills: totals.kills,
      time: totals.time,
      evolutions: totals.evolutions,
    };
    this.scores = saveScore({
      score: this.result.score,
      stage: this.result.stageIndex,
      victory,
      evolutions: this.result.evolutions,
      date: new Date().toISOString().slice(0, 10),
    });
    if (this.runMode === "campaign") clearActiveRunCheckpoint();
    if (victory) audio.play("win");
    this.setPhase(victory ? "won" : "dead");
  }

  private tick = (now: number) => {
    this.raf = requestAnimationFrame(this.tick);
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.25) dt = 0.25;
    this.time += dt;

    const w = this.world;
    if (this.phase === "playing" && w) {
      const { dir, mag } = this.steerVector();
      let dash = this.input.consumeDash();
      this.acc = Math.min(this.acc + dt, 0.12);
      // Stop immediately when an update raises a modal/terminal state. Without
      // these guards, a lagged frame could advance combat past a pending mutation.
      while (this.acc >= STEP && !w.pendingEvolve && !w.finished) {
        this.acc -= STEP;
        if (w.hitStop > 0) {
          w.hitStop -= STEP;
          continue;
        }
        const ts = w.slowmo > 0 ? 0.35 : 1;
        w.update(STEP * ts, dir, mag, dash);
        dash = false;
        if (w.finished) break;
      }
      this.input.endFrame();

      if (w.pendingEvolve && !w.finished) {
        this.choices = w.rollChoices();
        this.menuIndex = 0;
        this.setPhase("mutate");
      } else if (w.finished === "clear") {
        // Completion and first-clear reward are saved before the clear overlay.
        markStageCompleted(w.stage.id, w.levels);
        if (w.stageIndex + 1 >= STAGES.length) {
          this.finishRun(true, w.score);
        } else {
          // If the browser closes on the clear screen, Continue should resume at
          // the next zone with the completed zone's build and cumulative stats.
          if (this.runMode === "campaign") {
            saveActiveRunCheckpoint({
              stageId: w.stage.id + 1,
              score: w.score,
              levels: w.levels,
              totals: this.currentRunTotals(),
            });
          }
          this.setPhase("clear");
        }
      } else if (w.finished === "dead") {
        this.finishRun(false, w.score);
      }
    } else if (this.phase === "briefing" && w) {
      // Keep the zone briefing open until the player explicitly confirms it.
      // Only ambient animation advances here; elapsed time never starts the level.
      w.virus.pulse += dt * 2;
      w.virus.spin += dt * 0.4;
      w.parts.update(dt * 0.4);
      this.input.endFrame();
    } else {
      this.input.endFrame();
    }

    this.zoom += (1 - this.zoom) * Math.min(1, dt * 4);
    this.render();
    this.hudTimer -= dt;
    if (this.hudTimer <= 0) this.emit(false);
  };

  /** Combines joystick, keys and pointer steering into one direction+intent. */
  private steerVector(): { dir: Vec; mag: number } {
    const w = this.world;
    if (!w) return { dir: { x: 0, y: 0 }, mag: 0 };
    const mv = this.input.moveVector();
    if (mv.x !== 0 || mv.y !== 0) {
      const l = len(mv);
      return { dir: { x: mv.x / l, y: mv.y / l }, mag: clamp(l, 0, 1) };
    }
    if (this.input.pointer.down && this.input.pointer.has) {
      const p = this.screenToWorld(this.input.pointer.x, this.input.pointer.y);
      const d = sub(p, w.virus.pos);
      const l = len(d);
      if (l > 6) {
        const n = norm(d);
        const mag = clamp(l / (150 / this.viewScale), 0.22, 1);
        return { dir: n, mag };
      }
    }
    return { dir: { x: 0, y: 0 }, mag: 0 };
  }

  private screenToWorld(sx: number, sy: number): Vec {
    const w = this.world;
    if (!w) return { x: sx, y: sy };
    const scale = this.viewScale * this.zoom;
    const cam = this.camCenter();
    return {
      x: (sx - this.cw / 2) / scale + cam.x,
      y: (sy - this.ch / 2) / scale + cam.y,
    };
  }

  private camCenter(): Vec {
    const w = this.world;
    if (!w) return { x: 0, y: 0 };
    const scale = this.viewScale * this.zoom;
    const halfW = this.cw / (2 * scale);
    const halfH = this.ch / (2 * scale);
    const W = w.stage.world.w;
    const H = w.stage.world.h;
    let x = w.cam.pos.x;
    let y = w.cam.pos.y;
    x = W > halfW * 2 ? clamp(x, halfW, W - halfW) : W / 2;
    y = H > halfH * 2 ? clamp(y, halfH, H - halfH) : H / 2;
    return { x, y };
  }

  /* ---------------------------------------------------------------- */

  private render() {
    const ctx = this.ctx;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    if (!this.world || this.phase === "menu") {
      this.renderMenu();
      return;
    }
    const w = this.world;
    const p = w.stage.palette;

    if (!this.bgGradient) {
      const g = ctx.createLinearGradient(0, 0, 0, this.ch);
      g.addColorStop(0, p.bgA);
      g.addColorStop(1, p.bgB);
      this.bgGradient = g;
    }
    ctx.fillStyle = this.bgGradient;
    ctx.fillRect(0, 0, this.cw, this.ch);

    const scale = this.viewScale * this.zoom;
    const cam = this.camCenter();
    const shake = w.shakeAmt;
    const sx = Math.cos(w.cam.shakeAngle) * shake;
    const sy = Math.sin(w.cam.shakeAngle) * shake;

    ctx.save();
    ctx.translate(this.cw / 2 + sx, this.ch / 2 + sy);
    ctx.scale(scale, scale);
    ctx.translate(-cam.x, -cam.y);
    const view = {
      x: cam.x - this.cw / (2 * scale) - 60,
      y: cam.y - this.ch / (2 * scale) - 60,
      w: this.cw / scale + 120,
      h: this.ch / scale + 120,
    };
    drawScene(ctx, w, view, this.time);
    ctx.restore();

    drawOverlays(ctx, w, this.cw, this.ch, cam);

    // Vignette
    const vg = ctx.createRadialGradient(
      this.cw / 2,
      this.ch / 2,
      Math.min(this.cw, this.ch) * 0.32,
      this.cw / 2,
      this.ch / 2,
      Math.max(this.cw, this.ch) * 0.78,
    );
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.55)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, this.cw, this.ch);
  }

  private renderMenu() {
    const ctx = this.ctx;
    const t = this.time;
    const g = ctx.createLinearGradient(0, 0, 0, this.ch);
    g.addColorStop(0, "#02141c");
    g.addColorStop(0.55, "#06303a");
    g.addColorStop(1, "#02121a");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, this.cw, this.ch);

    const cx = this.cw / 2;
    const cy = this.ch * 0.52;

    // Drifting organelles
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const d of this.menuDecor) {
      const a = d.a + t * d.s;
      const x = cx + Math.cos(a) * d.d * 1.7;
      const y = cy + Math.sin(a) * d.d;
      const rad = ctx.createRadialGradient(x, y, 0, x, y, d.r);
      rad.addColorStop(0, "rgba(18,214,192,0.16)");
      rad.addColorStop(1, "rgba(18,214,192,0)");
      ctx.fillStyle = rad;
      ctx.beginPath();
      ctx.arc(x, y, d.r, 0, TAU);
      ctx.fill();
    }
    ctx.restore();

    // Floating DNA strands
    for (const o of this.menuOrbs) {
      o.pos.x += o.vel.x * 0.016;
      o.pos.y += o.vel.y * 0.016;
      if (o.pos.y < -20) o.pos.y = this.ch + 20;
      if (o.pos.x < -20) o.pos.x = this.cw + 20;
      if (o.pos.x > this.cw + 20) o.pos.x = -20;
      drawPickup(
        ctx,
        {
          kind: "dna",
          pos: o.pos,
          vel: { x: 0, y: 0 },
          r: 9,
          t: 0,
          alive: true,
          value: 1,
          seed: o.seed,
        },
        MENU_PALETTE,
        t,
      );
    }

    // The specimen
    const traits = buildTraits(this.levels, this.permanentUpgrades);
    const fake = {
      pos: { x: cx, y: cy },
      vel: { x: 0, y: 0 },
      angle: -Math.PI / 2 + Math.sin(t * 0.5) * 0.2,
      spin: t * 0.5,
      r: traits.radius * 1.9,
      hp: 1,
      invuln: 0,
      hitFlash: 0,
      hurt: 0,
      dashTime: 0,
      dashCd: 0,
      acidGrace: 0,
      dashDir: { x: 0, y: 0 },
      evolveFlash: 0,
      morph: 0,
      trail: [] as { x: number; y: number; a: number }[],
      pulse: t * 2,
      shield: traits.shieldMax,
      shieldFlash: 0,
    };
    drawVirus(ctx, fake, traits, t, 1);
  }

  /* ---------------------------------------------------------------- */

  private emit(force: boolean) {
    const w = this.world;
    this.hudTimer = force ? 0 : 0.05;
    const h: HudSnapshot = {
      phase: this.phase,
      hp: w ? w.virus.hp : 0,
      maxHp: w ? w.traits.maxHp : 100,
      dna: w ? w.dna : 0,
      dnaNeeded: w ? w.dnaNeeded : 1,
      collected: w ? w.collected : 0,
      quota: w ? w.stage.quota : 0,
      score: w ? w.score : 0,
      combo: w ? w.combo : 1,
      stageIndex: w ? w.stageIndex : 0,
      stageCount: STAGES.length,
      stageName: w ? w.stage.name : "",
      stageSubtitle: w ? w.stage.subtitle : "",
      time: w ? ((this.phase === "dead" || this.phase === "won") && this.result ? this.result.time : w.time) : 0,
      kills: w ? ((this.phase === "dead" || this.phase === "won") && this.result ? this.result.kills : w.kills) : 0,
      shield: w ? w.virus.shield : 0,
      shieldMax: w ? w.traits.shieldMax : 0,
      dashReady: w ? 1 - clamp(w.virus.dashCd / w.traits.dashCd, 0, 1) : 1,
      hint: w && w.hintT > 0 ? w.hint : "",
      choices: this.choices.map((id) => MUTATION_BY_ID[id]),
      levels: w ? w.levels : {},
      dnaTotal: w ? ((this.phase === "dead" || this.phase === "won") && this.result ? this.result.dna : w.dnaTotal) : 0,
      evolutions: w ? ((this.phase === "dead" || this.phase === "won") && this.result ? this.result.evolutions : w.evolutionCount) : 0,
      locked: w ? !w.target.unlocked : true,
      bossHp: w ? w.bossHp() : -1,
      touch: this.input.touchMode,
      muted: !audio.enabled,
    };
    this.cb.onHud(h);
  }

  get lastScores() {
    return this.scores;
  }
}
