/** UI state for a mutation's three progression tiers.
 * Filled bars mean already acquired ranks. The outlined tier is only a preview
 * of what choosing the card will grant; later tiers remain locked.
 */
export type MutationTierStatus = "owned" | "preview" | "locked";

export function getMutationTierStatus(currentLevel: number, tier: number): MutationTierStatus {
  const safeLevel = Number.isFinite(currentLevel)
    ? Math.max(0, Math.min(3, Math.floor(currentLevel)))
    : 0;
  const safeTier = Number.isFinite(tier) ? Math.floor(tier) : 0;

  if (safeTier < 1 || safeTier > 3) return "locked";
  if (safeTier <= safeLevel) return "owned";
  if (safeLevel < 3 && safeTier === safeLevel + 1) return "preview";
  return "locked";
}
