import type { MutationDef, Palette, Rect, StageDef, Traits } from "./types";

export const BASE_TRAITS: Traits = {
  maxHp: 100,
  speed: 252,
  accel: 1650,
  drag: 5.4,
  radius: 22,
  spikes: 9,
  spikeLen: 9,
  bodyHue: 112,
  tail: 0,
  cilia: 0,
  tendrils: 0,
  plates: 0,
  innerOrbs: 0,
  aura: 64,
  regen: 0,
  thorns: 0,
  digest: 0,
  digestRadius: 0,
  dashPower: 440,
  dashTime: 0.2,
  dashCd: 1.45,
  dashInvuln: 0.14,
  shock: 0,
  shockDamage: 0,
  shieldMax: 0,
  dnaValue: 1,
  glow: 0.55,
  eye: 0,
};

export type PermanentTraitBonuses = Partial<Record<"vitality" | "mobility" | "harvest", number>>;

/** Пересчитывает характеристики из временных мутаций и постоянной эволюции. */
export function buildTraits(
  levels: Record<string, number>,
  permanent: PermanentTraitBonuses = {},
): Traits {
  const t: Traits = { ...BASE_TRAITS };
  const levelOf = (id: string) => {
    const max = MUTATION_BY_ID[id]?.max ?? 0;
    const raw = Number(levels[id] ?? 0);
    return Number.isFinite(raw) ? Math.max(0, Math.min(max, Math.floor(raw))) : 0;
  };

  // Always apply mutations in canonical order; the user's selection order must
  // never affect the outcome of a build.
  for (const def of MUTATIONS) {
    const lv = levelOf(def.id);
    if (lv > 0) def.apply(t, lv);
  }

  // Compose traits affected by more than one mutation from the complete level
  // map. These formulas deliberately avoid incremental += updates so rebuilding
  // a run after a sector transition produces exactly the same result.
  const flagellum = levelOf("flagellum");
  const cilia = levelOf("cilia");
  const phase = levelOf("phase");
  const plating = levelOf("plating");
  const magnet = levelOf("magnet");
  const net = levelOf("net");
  const taxis = levelOf("taxis");

  t.speed = BASE_TRAITS.speed * (1 + cilia * 0.18) + flagellum * 16;
  t.dashTime = BASE_TRAITS.dashTime + flagellum * 0.02 + phase * 0.03;
  t.aura = BASE_TRAITS.aura + magnet * 86 + net * 26 + taxis * 14;
  t.glow = BASE_TRAITS.glow + phase * 0.18 + plating * 0.05 + magnet * 0.1;

  const permanentLevel = (id: keyof PermanentTraitBonuses) => {
    const raw = Number(permanent[id] ?? 0);
    return Number.isFinite(raw) ? Math.max(0, Math.min(3, Math.floor(raw))) : 0;
  };
  // Meta-progression is applied only after the complete temporary mutation
  // formula so the two systems stay independent and deterministic.
  t.maxHp += permanentLevel("vitality") * 8;
  t.speed *= 1 + permanentLevel("mobility") * 0.04;
  t.dnaValue *= 1 + permanentLevel("harvest") * 0.05;

  return t;
}

export const MENU_PALETTE: Palette = {
  bgA: "#02141c",
  bgB: "#06303a",
  blob: "#12d6c0",
  wall: "#0e6b74",
  wallEdge: "#7ffff0",
  wallGlow: "#1de3c8",
  accent: "#6dffd9",
  danger: "#ff5f7e",
  dna: "#c8ff4d",
  fog: "#052b34",
};

export const KIND_LABEL: Record<MutationDef["kind"], string> = {
  move: "ДВИЖЕНИЕ",
  defense: "ЗАЩИТА",
  collect: "СБОР ДНК",
  attack: "АТАКА",
};

export const MUTATIONS: MutationDef[] = [
  {
    id: "flagellum",
    name: "Жгутик",
    kind: "move",
    glyph: "tail",
    max: 3,
    tint: "#7dff9c",
    tagline: "Отрасти гибкий жгутик для резких ускорений.",
    levels: [
      "Усиливает рывок и сокращает восстановление после него.",
      "Жгутик становится длиннее: рывок мощнее, перезарядка короче.",
      "Двойной жгутик: стремительное ускорение и почти мгновенное восстановление.",
    ],
    apply: (t, lv) => {
      t.tail = lv;
      t.dashPower = 440 + lv * 120;
      t.dashCd = 1.45 - lv * 0.19;
      t.dashTime = 0.2 + lv * 0.02;
      // Final speed is composed in buildTraits so this stacks with cilia regardless of selection order.
    },
  },
  {
    id: "cilia",
    name: "Ресничный покров",
    kind: "move",
    glyph: "cilia",
    max: 3,
    tint: "#9dff5e",
    tagline: "Покрой оболочку движущимися ресничками.",
    levels: [
      "+18% к максимальной скорости и более точное управление.",
      "+36% к максимальной скорости и резкие, точные повороты.",
      "+54% к максимальной скорости. Вирус почти не скользит.",
    ],
    apply: (t, lv) => {
      t.cilia = lv;
      t.speed = 252 * (1 + lv * 0.18);
      t.accel = 1650 + lv * 900;
      t.drag = 5.4 + lv * 1.6;
    },
  },
  {
    id: "phase",
    name: "Фазовая мембрана",
    kind: "move",
    glyph: "phase",
    max: 3,
    tint: "#5ef0ff",
    tagline: "Меняй фазу оболочки, чтобы проскальзывать сквозь материю.",
    levels: [
      "Во время рывка ты на мгновение становишься неуязвимым.",
      "Неуязвимость длится дольше; появляется двойная голубая мембрана.",
      "Во время рывка проходи сквозь пули, шипы и преследователей.",
    ],
    apply: (t, lv) => {
      t.dashInvuln = 0.16 + lv * 0.16;
      t.bodyHue = 112 + lv * 14;
      // Combined glow and dash duration are normalized in buildTraits.
    },
  },
  {
    id: "plating",
    name: "Укреплённая оболочка",
    kind: "defense",
    glyph: "plate",
    max: 3,
    tint: "#ffd45e",
    tagline: "Укрепи оболочку плотными защитными пластинами.",
    levels: [
      "+40 к максимальному здоровью; тело немного увеличивается.",
      "+95 к максимальному здоровью; тело становится крупнее.",
      "+165 к максимальному здоровью. Ты превращаешься в живую крепость.",
    ],
    apply: (t, lv) => {
      t.plates = lv;
      t.maxHp = 100 + [0, 40, 95, 165][lv];
      t.radius = 22 + lv * 2;
      // Combined glow is normalized in buildTraits.
    },
  },
  {
    id: "regen",
    name: "Регенерация цитоплазмы",
    kind: "defense",
    glyph: "orb",
    max: 3,
    tint: "#59ffb0",
    tagline: "Восстанавливай повреждённую белковую оболочку.",
    levels: [
      "Восстанавливает 1,4 единицы здоровья в секунду.",
      "Восстанавливает 3 единицы здоровья в секунду.",
      "Восстанавливает 5,5 единицы здоровья в секунду — раны затягиваются быстро.",
    ],
    apply: (t, lv) => {
      t.innerOrbs = lv;
      t.regen = lv === 1 ? 1.4 : lv === 2 ? 3 : 5.5;
    },
  },
  {
    id: "barbs",
    name: "Ядовитые шипы",
    kind: "attack",
    glyph: "spike",
    max: 3,
    tint: "#ff6b6b",
    tagline: "Преврати шипы в гарпуны, пропитанные токсином.",
    levels: [
      "Шипы становятся длиннее. Нападающие получают 14 единиц урона.",
      "Шипов становится больше. Нападающие получают 26 единиц урона.",
      "Корона из красных гарпунов. Нападающие получают 45 единиц урона.",
    ],
    apply: (t, lv) => {
      t.spikeLen = 9 + lv * 8;
      t.spikes = 9 + lv * 2;
      t.thorns = lv === 1 ? 14 : lv === 2 ? 26 : 45;
    },
  },
  {
    id: "magnet",
    name: "Генетический магнит",
    kind: "collect",
    glyph: "aura",
    max: 3,
    tint: "#c98bff",
    tagline: "Притягивай ближайшие нити ДНК к своему ядру.",
    levels: [
      "Притягивает ДНК с большого расстояния.",
      "Нити ДНК со значительной части арены тянутся к тебе.",
      "Создаёт огромное фиолетовое поле, которое собирает всё поблизости.",
    ],
    apply: (t, lv) => {
      t.aura = 64 + lv * 86;
      // Combined glow and pickup radius are normalized in buildTraits.
    },
  },
  {
    id: "net",
    name: "Ловчие нити",
    kind: "collect",
    glyph: "net",
    max: 3,
    tint: "#8affe0",
    tagline: "Выпускай липкие нити, собирающие генетический материал.",
    levels: [
      "Нити за тобой автоматически собирают ДНК.",
      "Нити становятся длиннее и захватывают больше ДНК.",
      "Вокруг тебя тянется огромная сеть для сбора генетического материала.",
    ],
    apply: (t, lv) => {
      t.tendrils = lv;
      // Combined pickup radius is normalized in buildTraits.
    },
  },
  {
    id: "enzymes",
    name: "Литические ферменты",
    kind: "attack",
    glyph: "drop",
    max: 3,
    tint: "#b4ff3d",
    tagline: "Вырабатывай ферменты, растворяющие другие организмы.",
    levels: [
      "Касайся мелких организмов, чтобы расщеплять их и получать ДНК.",
      "Ферменты становятся сильнее и способны расщеплять организмы среднего размера.",
      "Растворяй почти всё, чего коснёшься.",
    ],
    apply: (t, lv) => {
      t.digest = lv === 1 ? 34 : lv === 2 ? 62 : 108;
      // Match the tier descriptions: small organisms first, medium organisms
      // at tier 2, and nearly every organism at tier 3.
      t.digestRadius = lv === 1 ? 20 : lv === 2 ? 36 : 100;
    },
  },
  {
    id: "fission",
    name: "Деление надвое",
    kind: "defense",
    glyph: "shield",
    max: 3,
    tint: "#6ea8ff",
    tagline: "Создавай споры-приманки, принимающие удар на себя.",
    levels: [
      "Одна спора вращается вокруг тебя и поглощает один удар.",
      "Две споры вращаются вокруг тебя и защищают от ударов.",
      "Три споры вращаются вокруг тебя и принимают удары на себя.",
    ],
    apply: (t, lv) => {
      t.shieldMax = lv;
    },
  },
  {
    id: "taxis",
    name: "Химическое чутьё",
    kind: "collect",
    glyph: "eye",
    max: 3,
    tint: "#ffe066",
    tagline: "Чувствуй химические сигналы и извлекай больше пользы из каждой нити ДНК.",
    levels: [
      "Каждая нить ДНК приносит на 35% больше очков.",
      "Каждая нить ДНК приносит на 80% больше очков.",
      "Каждая нить ДНК приносит на 140% больше очков. Появляется дополнительный глаз.",
    ],
    apply: (t, lv) => {
      // Score multiplier, applied when DNA is collected (not to the DNA quota itself).
      t.dnaValue = lv === 1 ? 1.35 : lv === 2 ? 1.8 : 2.4;
      t.eye = lv;
      // Combined pickup radius is normalized in buildTraits.
    },
  },
  {
    id: "volt",
    name: "Электрический разряд",
    kind: "attack",
    glyph: "bolt",
    max: 3,
    tint: "#7fe7ff",
    tagline: "Высвобождай электрический заряд из мембраны во время рывка.",
    levels: [
      "Во время рывка поражает ближайшие организмы током, нанося 26 единиц урона.",
      "Радиус разряда увеличивается, урон — 48 единиц.",
      "Мощная электрическая буря радиусом 265 единиц наносит 80 единиц урона.",
    ],
    apply: (t, lv) => {
      t.shock = lv === 1 ? 140 : lv === 2 ? 200 : 265;
      t.shockDamage = lv === 1 ? 26 : lv === 2 ? 48 : 80;
    },
  },
];

export const MUTATION_BY_ID: Record<string, MutationDef> = Object.fromEntries(
  MUTATIONS.map((m) => [m.id, m]),
);

/* ------------------------------------------------------------------ */
/* Расположение зон                                                    */
/* ------------------------------------------------------------------ */

const P1 = {
  bgA: "#04222c",
  bgB: "#0a4a52",
  blob: "#12d6c0",
  wall: "#0e6b74",
  wallEdge: "#7ffff0",
  wallGlow: "#1de3c8",
  accent: "#6dffd9",
  danger: "#ff5f7e",
  dna: "#c8ff4d",
  fog: "#052b34",
};

const P2 = {
  bgA: "#24082a",
  bgB: "#5c1440",
  blob: "#ff4fa3",
  wall: "#7a1f5c",
  wallEdge: "#ffb3e6",
  wallGlow: "#ff5fb0",
  accent: "#ff9ad5",
  danger: "#ffd23d",
  dna: "#ffe14d",
  fog: "#2c0a2e",
};

const P3 = {
  bgA: "#060f34",
  bgB: "#123a72",
  blob: "#4f8cff",
  wall: "#173a7a",
  wallEdge: "#9fd0ff",
  wallGlow: "#4fa8ff",
  accent: "#7fc4ff",
  danger: "#ff4f4f",
  dna: "#9dff5e",
  fog: "#08133a",
};

const P4 = {
  bgA: "#150529",
  bgB: "#3d0a4a",
  blob: "#ff7a2f",
  wall: "#4a1550",
  wallEdge: "#ffc78f",
  wallGlow: "#ff8a3d",
  accent: "#ffb45e",
  danger: "#ff3b6b",
  dna: "#ffd84d",
  fog: "#1a0630",
};

const P5 = {
  bgA: "#031d18",
  bgB: "#0d4a35",
  blob: "#36e58d",
  wall: "#17694f",
  wallEdge: "#9dffd0",
  wallGlow: "#40f0a0",
  accent: "#84ffc2",
  danger: "#ff6e8e",
  dna: "#d7ff63",
  fog: "#052b25",
};

const P6 = {
  bgA: "#090b2b",
  bgB: "#1b2c65",
  blob: "#5ba5ff",
  wall: "#293f95",
  wallEdge: "#92c9ff",
  wallGlow: "#6c8dff",
  accent: "#93e4ff",
  danger: "#ff658c",
  dna: "#b6ff62",
  fog: "#0b1744",
};

const P7 = {
  bgA: "#260912",
  bgB: "#681d2b",
  blob: "#ff5269",
  wall: "#8d263f",
  wallEdge: "#ffb0a9",
  wallGlow: "#ff5269",
  accent: "#ff9c8a",
  danger: "#ffd45e",
  dna: "#ffe56b",
  fog: "#350e20",
};

const P8 = {
  bgA: "#090e13",
  bgB: "#233b32",
  blob: "#c8ff4d",
  wall: "#315d49",
  wallEdge: "#f0ffb0",
  wallGlow: "#a5ff6a",
  accent: "#d2ff85",
  danger: "#ff456d",
  dna: "#fff078",
  fog: "#0b211a",
};

/** Разбросанные прямоугольные преграды в открытых зонах. */
function scatterWalls(
  seed: number,
  count: number,
  w: number,
  h: number,
  avoid: Rect,
  minSize = 90,
  maxSize = 210,
): Rect[] {
  // Псевдослучайная последовательность: расположение зон всегда одинаковое.
  let s = seed;
  const rnd = () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;
  };
  const out: Rect[] = [];
  let guard = 0;
  while (out.length < count && guard < count * 40) {
    guard++;
    const rw = minSize + rnd() * (maxSize - minSize);
    const rh = minSize + rnd() * (maxSize - minSize);
    const x = 180 + rnd() * (w - 360 - rw);
    const y = 180 + rnd() * (h - 360 - rh);
    const r = { x, y, w: rw, h: rh };
    const pad = 130;
    if (
      x < avoid.x + avoid.w + pad &&
      x + rw > avoid.x - pad &&
      y < avoid.y + avoid.h + pad &&
      y + rh > avoid.y - pad
    ) {
      continue;
    }
    if (out.some((o) => Math.hypot(o.x - x, o.y - y) < 260)) continue;
    out.push(r);
  }
  return out;
}

function pillarGrid(
  w: number,
  h: number,
  step: number,
  size: number,
  skip: (x: number, y: number) => boolean,
): Rect[] {
  const out: Rect[] = [];
  for (let x = step; x < w - step * 0.5; x += step) {
    for (let y = step; y < h - step * 0.5; y += step) {
      if (skip(x, y)) continue;
      if (((x / step) * 7 + (y / step) * 13) % 5 === 0) continue;
      out.push({ x: x - size / 2, y: y - size / 2, w: size, h: size });
    }
  }
  return out;
}

export const STAGES: StageDef[] = [
  {
    id: 1,
    name: "ПЛАЗМЕННЫЕ МЕЛИ",
    subtitle: "Зона 01 · тёплая питательная среда",
    brief:
      "Осмотрись, собирай свободные нити ДНК и найди единственную клетку хозяина. Её мембрана откроется, когда ты соберёшь достаточно ДНК.",
    world: { w: 2500, h: 1750 },
    quota: 14,
    firstEvolve: 8,
    walls: scatterWalls(9271, 13, 2500, 1750, { x: 120, y: 800, w: 320, h: 320 }),
    acids: [],
    currents: [],
    spawns: { mite: 17, chaser: 3 }, // 20 starting enemies
    respawn: { mite: 1, chaser: 1 },
    respawnEvery: 7.0,
    pickupCount: 54,
    boss: false,
    palette: P1,
    hints: [
      "Движение: WASD, стрелки, мышь или касание экрана.",
      "Собирай светящиеся нити ДНК.",
      "РЫВОК (пробел, Shift или кнопка на экране) уничтожает мелкие организмы.",
      "Заполни шкалу эволюции, чтобы выбрать мутацию.",
      "ДНК собрано достаточно — найди клетку хозяина и зарази её.",
    ],
  },
  {
    id: 2,
    name: "КИСЛОТНЫЕ КАНАЛЫ",
    subtitle: "Зона 02 · лабиринт едких капилляров",
    brief:
      "Узкие каналы, тупики и лужи едкой кислоты. Макрофаги выслеживают тебя по химическим следам. Шипованные мины неподвижны, но смертельно опасны.",
    world: { w: 2900, h: 1950 },
    quota: 25,
    firstEvolve: 12,
    walls: [
      { x: 700, y: 170, w: 64, h: 620 },
      { x: 1380, y: 420, w: 64, h: 700 },
      { x: 2060, y: 170, w: 64, h: 620 },
      { x: 190, y: 900, w: 880, h: 64 },
      { x: 1520, y: 1210, w: 1120, h: 64 },
      { x: 300, y: 1520, w: 620, h: 64 },
      { x: 980, y: 190, w: 150, h: 130 },
      { x: 1720, y: 330, w: 150, h: 150 },
      { x: 620, y: 1250, w: 170, h: 130 },
      { x: 2480, y: 880, w: 130, h: 170 },
      { x: 1060, y: 1580, w: 130, h: 130 },
    ],
    acids: [
      { x: 1120, y: 620, r: 190 },
      { x: 1780, y: 1020, r: 210 },
      { x: 2560, y: 640, r: 175 },
      { x: 720, y: 1760, r: 150 },
      { x: 2280, y: 1560, r: 165 },
      { x: 380, y: 480, r: 150 },
    ],
    currents: [],
    spawns: { mite: 13, chaser: 9, spiker: 8 }, // 30 starting enemies
    respawn: { mite: 1, chaser: 1, spiker: 1 },
    respawnEvery: 6.5,
    pickupCount: 62,
    boss: false,
    palette: P2,
    hints: [
      "Лужи кислоты обжигают — пересекай их рывком.",
      "Шипованные мины взрываются при контакте. Держись подальше.",
      "Макрофаги преследуют тебя по прямой — резко меняй направление.",
      "ДНК собрано достаточно — доберись до клетки хозяина.",
    ],
  },
  {
    id: 3,
    name: "ШТОРМ АНТИТЕЛ",
    subtitle: "Зона 03 · открытая сыворотка с течениями",
    brief:
      "Широкий поток сыворотки с сильными течениями. Охотники-антитела стреляют самонаводящимися сгустками с расстояния. Разрушенные споры разделяются надвое.",
    world: { w: 3100, h: 2100 },
    quota: 36,
    firstEvolve: 14,
    walls: scatterWalls(4413, 17, 3100, 2100, { x: 130, y: 950, w: 300, h: 300 }, 110, 240),
    acids: [
      { x: 1500, y: 600, r: 200 },
      { x: 2300, y: 1500, r: 230 },
    ],
    currents: [
      {
        rect: { x: 0, y: 420, w: 3100, h: 240 },
        dir: { x: 1, y: 0 },
        strength: 190,
      },
      {
        rect: { x: 0, y: 1060, w: 3100, h: 260 },
        dir: { x: -1, y: 0 },
        strength: 210,
      },
      {
        rect: { x: 0, y: 1660, w: 3100, h: 240 },
        dir: { x: 1, y: 0 },
        strength: 165,
      },
    ],
    spawns: { mite: 17, hunter: 8, spore: 8, chaser: 7 }, // 40 starting enemies
    respawn: { mite: 1, hunter: 1, spore: 1, chaser: 1 },
    respawnEvery: 6.0,
    pickupCount: 70,
    boss: false,
    palette: P3,
    hints: [
      "Синие течения толкают тебя — используй их, чтобы двигаться быстрее.",
      "Охотники стреляют сгустками. Не стой на месте, двигайся зигзагами.",
      "При разрушении споры разделяются на две части.",
      "ДНК собрано достаточно — доберись до клетки хозяина.",
    ],
  },
  {
    id: 4,
    name: "ЯДРО КЛЕТКИ",
    subtitle: "Зона 04 · последняя камера",
    brief:
      "Сердце клетки хозяина. Страж охраняет ядро среди скоплений органелл. Собери необходимое количество ДНК, чтобы разрушить его щит, а затем прорвись к ядру.",
    world: { w: 2700, h: 2700 },
    quota: 47,
    firstEvolve: 16,
    walls: pillarGrid(2700, 2700, 270, 96, (x, y) => {
      const cx = 1350;
      const cy = 1350;
      if (Math.hypot(x - cx, y - cy) < 520) return true;
      if (Math.hypot(x - 260, y - 260) < 330) return true;
      return false;
    }),
    acids: [
      { x: 700, y: 2100, r: 200 },
      { x: 2100, y: 700, r: 200 },
      { x: 2200, y: 2200, r: 170 },
      { x: 600, y: 600, r: 170 },
    ],
    currents: [
      {
        rect: { x: 0, y: 1300, w: 760, h: 200 },
        dir: { x: 0, y: -1 },
        strength: 170,
      },
      {
        rect: { x: 1940, y: 1200, w: 760, h: 200 },
        dir: { x: 0, y: 1 },
        strength: 170,
      },
    ],
    spawns: { mite: 17, hunter: 9, chaser: 7, spiker: 8, spore: 8, sentinel: 1 }, // 50 including the guardian
    respawn: { mite: 1, hunter: 1, chaser: 1, spiker: 1, spore: 1 },
    respawnEvery: 5.5,
    pickupCount: 80,
    boss: true,
    palette: P4,
    hints: [
      "Щит Стража разрушается, когда ты соберёшь нужное количество ДНК.",
      "Уклоняйся от его осколков рывком, а затем прорывайся к ядру.",
      "Страж — лишь первый из защитных барьеров организма.",
      "ДНК собрано достаточно — путь к ядру открыт.",
    ],
  },
  {
    id: 5,
    name: "ЛИМФАТИЧЕСКИЙ КРИПТ",
    subtitle: "Зона 05 · густая сеть живых каналов",
    brief:
      "Лимфатическая сеть сужается в лабиринт. Токсичные карманы перекрывают короткие пути, а быстрые охотники пытаются окружить тебя. Используй повороты и рывок, чтобы прорваться глубже.",
    world: { w: 3200, h: 2200 },
    quota: 58,
    firstEvolve: 18,
    walls: scatterWalls(5105, 25, 3200, 2200, { x: 120, y: 930, w: 420, h: 360 }, 100, 220),
    acids: [
      { x: 720, y: 480, r: 145 },
      { x: 1270, y: 1050, r: 190 },
      { x: 1880, y: 520, r: 165 },
      { x: 2410, y: 1380, r: 205 },
      { x: 2950, y: 700, r: 145 },
      { x: 830, y: 1810, r: 155 },
    ],
    currents: [
      { rect: { x: 500, y: 1470, w: 2200, h: 170 }, dir: { x: 1, y: 0 }, strength: 155 },
    ],
    spawns: { mite: 20, chaser: 13, spiker: 10, spore: 9, hunter: 8 }, // 60 starting enemies
    respawn: { mite: 2, chaser: 1, spiker: 1, spore: 1, hunter: 1 },
    respawnEvery: 5.0,
    pickupCount: 90,
    boss: false,
    palette: P5,
    hints: [
      "Коридоры узкие — не позволяй преследователям загнать себя в угол.",
      "Лужи токсина разбивают короткие маршруты. Планируй рывок заранее.",
      "Сильные охотники теперь появляются вместе с обычными организмами.",
      "Собери квоту ДНК и найди мембрану хозяина.",
    ],
  },
  {
    id: 6,
    name: "БИОЭЛЕКТРИЧЕСКАЯ БЕЗДНА",
    subtitle: "Зона 06 · разряды в глубине сыворотки",
    brief:
      "Электрические течения меняют направление движения, а дальнобойные антитела держат дистанцию. Здесь впервые появляются симбионты: они лечат раненых противников зелёными энергетическими связями. Сначала находи целителя, затем разбирай остальную группу.",
    world: { w: 3400, h: 2350 },
    quota: 69,
    firstEvolve: 20,
    walls: pillarGrid(3400, 2350, 285, 82, (x, y) => {
      if (Math.hypot(x - 410, y - 1175) < 360) return true;
      if (Math.hypot(x - 2990, y - 470) < 360) return true;
      if (x > 1000 && x < 2200 && y > 980 && y < 1380) return true;
      return false;
    }),
    acids: [
      { x: 900, y: 680, r: 170 },
      { x: 1580, y: 1780, r: 205 },
      { x: 2240, y: 620, r: 185 },
      { x: 2860, y: 1720, r: 200 },
    ],
    currents: [
      { rect: { x: 0, y: 450, w: 3400, h: 190 }, dir: { x: -1, y: 0 }, strength: 230 },
      { rect: { x: 0, y: 1160, w: 3400, h: 210 }, dir: { x: 1, y: 0 }, strength: 255 },
      { rect: { x: 700, y: 1850, w: 2400, h: 180 }, dir: { x: 0, y: -1 }, strength: 190 },
    ],
    // Late campaign: every enemy family increases beyond zone 5 so the
    // final three zones clearly escalate in both initial population and pressure.
    spawns: { mite: 21, chaser: 14, hunter: 14, spore: 10, spiker: 11, symbiote: 2 }, // 72 starting enemies; first support unit
    respawn: { mite: 2, chaser: 2, hunter: 1, spore: 1, spiker: 1, symbiote: 1 },
    respawnEvery: 4.5,
    pickupCount: 100,
    boss: false,
    palette: P6,
    hints: [
      "Течения заметно сильнее прежних — корректируй направление движения.",
      "Симбионты лечат раненых врагов. Ищи зелёную связь и уничтожай целителя первым.",
      "Притягивание ДНК и точные рывки помогают удерживать темп.",
      "Квота выполнена — направляйся к клетке хозяина.",
    ],
  },
  {
    id: 7,
    name: "ГЕНЕТИЧЕСКИЙ КОЛЛАПС",
    subtitle: "Зона 07 · нестабильная ткань хозяина",
    brief:
      "Матрица организма разрушается: кислотные области, скрещивающиеся течения и плотные колонии врагов делают арену опасной со всех сторон. Фантомы растворяются в сыворотке, а затем показывают фиолетовый телеграф и пронзают арену стремительным рывком. Следи за искажением пространства.",
    world: { w: 3300, h: 2500 },
    quota: 80,
    firstEvolve: 22,
    walls: scatterWalls(7707, 30, 3300, 2500, { x: 120, y: 1050, w: 440, h: 400 }, 100, 230),
    acids: [
      { x: 620, y: 620, r: 180 },
      { x: 1220, y: 1480, r: 210 },
      { x: 1880, y: 640, r: 205 },
      { x: 2540, y: 1500, r: 220 },
      { x: 2900, y: 410, r: 150 },
      { x: 650, y: 2140, r: 165 },
      { x: 2140, y: 2180, r: 165 },
    ],
    currents: [
      { rect: { x: 450, y: 950, w: 2450, h: 170 }, dir: { x: 0, y: 1 }, strength: 205 },
      { rect: { x: 400, y: 1740, w: 2550, h: 180 }, dir: { x: -1, y: 0 }, strength: 195 },
    ],
    spawns: { mite: 22, chaser: 15, hunter: 15, spore: 16, spiker: 12, symbiote: 2, phantom: 2 }, // 84 starting enemies; first ambushers
    respawn: { mite: 2, chaser: 2, hunter: 1, spore: 2, spiker: 2, symbiote: 1, phantom: 1 },
    respawnEvery: 4.0,
    pickupCount: 110,
    boss: false,
    palette: P7,
    hints: [
      "Фантомы маскируются, но перед рывком накапливают фиолетовый свет. Уклоняйся поперёк их линии атаки.",
      "Симбионты продолжают лечить колонии — не оставляй их без внимания.",
      "Уничтожай опасные организмы, чтобы создавать безопасные окна для сбора ДНК.",
      "Подготовься: впереди последняя камера и финальный Страж.",
    ],
  },
  {
    id: 8,
    name: "ЭПИЦЕНТР ПАНДЕМИИ",
    subtitle: "Зона 08 · финальное ядро иммунной системы",
    brief:
      "Последняя камера организма. Инкубаторы выпускают маленьких паразитов из пульсирующих яйцевых камер; уничтожай гнездо до вылупления. Симбионты и фантомы усиливают охрану финального Стража. Собери огромный запас ДНК, прорви защиту и заверши заражение.",
    world: { w: 3600, h: 2800 },
    quota: 91,
    firstEvolve: 24,
    walls: pillarGrid(3600, 2800, 300, 88, (x, y) => {
      if (Math.hypot(x - 432, y - 1400) < 430) return true;
      if (Math.hypot(x - 3168, y - 560) < 470) return true;
      if (Math.hypot(x - 2850, y - 2180) < 360) return true;
      if (Math.abs(x - 1800) < 180 || Math.abs(y - 1400) < 150) return true;
      return ((x / 300 + y / 300) % 4) === 0;
    }),
    acids: [
      { x: 850, y: 520, r: 180 },
      { x: 1440, y: 720, r: 210 },
      { x: 2180, y: 520, r: 195 },
      { x: 2780, y: 1100, r: 220 },
      { x: 920, y: 2050, r: 190 },
      { x: 1860, y: 2180, r: 220 },
      { x: 2850, y: 2250, r: 175 },
    ],
    currents: [
      { rect: { x: 0, y: 940, w: 3600, h: 190 }, dir: { x: 1, y: 0 }, strength: 230 },
      { rect: { x: 0, y: 1660, w: 3600, h: 200 }, dir: { x: -1, y: 0 }, strength: 255 },
      { rect: { x: 1180, y: 0, w: 220, h: 2800 }, dir: { x: 0, y: 1 }, strength: 145 },
    ],
    spawns: { mite: 23, chaser: 18, hunter: 17, spore: 17, spiker: 14, symbiote: 2, phantom: 2, incubator: 1, sentinel: 1 }, // 95 including the final Sentinel, nest and new specialist families
    respawn: { mite: 3, chaser: 2, hunter: 2, spore: 2, spiker: 2, symbiote: 1, phantom: 1 },
    respawnEvery: 3.5,
    pickupCount: 120,
    boss: true,
    palette: P8,
    hints: [
      "Финальный Страж уязвим только после выполнения квоты ДНК.",
      "Красные яйцевые камеры Инкубатора пульсируют перед вылуплением. Уничтожай гнездо, пока оно заряжает следующую кладку.",
      "Уходи от радиальных залпов Стража по диагонали и используй рывок вовремя.",
      "Все системы ослаблены. Доберись до ядра и заверши пандемию.",
    ],
  },
];

export function nextEvolveCost(evolutionCount: number, stage: StageDef): number {
  return Math.round(stage.firstEvolve + evolutionCount * 7);
}
