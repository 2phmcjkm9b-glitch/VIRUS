import type { Enemy, Palette, Particle, Pickup, Traits, Virus } from "./types";
import type { World } from "./world";
import { TAU, clamp, easeOut, roundRectPath } from "./math";

export interface View {
  x: number;
  y: number;
  w: number;
  h: number;
}

/* ------------------------------------------------------------------ */
/* Cached sprites                                                      */
/* ------------------------------------------------------------------ */

const glowCache = new Map<string, HTMLCanvasElement>();

export function getGlow(color: string): HTMLCanvasElement {
  const hit = glowCache.get(color);
  if (hit) return hit;
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 64;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, color);
  grad.addColorStop(0.35, withAlpha(color, 0.55));
  grad.addColorStop(1, withAlpha(color, 0));
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  glowCache.set(color, c);
  return c;
}

function withAlpha(color: string, a: number): string {
  if (color.startsWith("hsl")) {
    const inner = color.slice(color.indexOf("(") + 1, color.lastIndexOf(")"));
    return `hsl(${inner} / ${a})`;
  }
  if (color.startsWith("#")) {
    const hex = color.slice(1);
    const full =
      hex.length === 3
        ? hex
            .split("")
            .map((ch) => ch + ch)
            .join("")
        : hex.slice(0, 6);
    const n = parseInt(full, 16);
    const r = (n >> 16) & 255;
    const g = (n >> 8) & 255;
    const b = n & 255;
    return `rgba(${r},${g},${b},${a})`;
  }
  return color;
}

/**
 * Continuous, world-anchored fluid backdrop. Unlike a repeated canvas tile,
 * every cloud and membrane belongs to a unique position in the stage world;
 * there are no texture edges to reveal as square seams while the camera moves.
 */
interface FluidCloud {
  x: number;
  y: number;
  rx: number;
  ry: number;
  rotation: number;
  tint: string;
  alpha: number;
  phase: number;
}
interface FluidMembrane {
  x: number;
  y: number;
  rx: number;
  ry: number;
  rotation: number;
  lobes: number;
  phase: number;
  alpha: number;
}
interface FluidField {
  clouds: FluidCloud[];
  membranes: FluidMembrane[];
}
const fluidFieldCache = new Map<number, FluidField>();

/** Deterministic random generator: all visual details are stable per zone. */
function makeRng(seed: number) {
  let state = seed | 0;
  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function getFluidField(w: World): FluidField {
  const hit = fluidFieldCache.get(w.stage.id);
  if (hit) return hit;

  const rng = makeRng(29011 + w.stage.id * 9349);
  const world = w.stage.world;
  const p = w.stage.palette;
  const tints = [p.blob, p.accent, p.wallGlow, p.dna, p.danger, p.fog];
  const field: FluidField = {
    // Oversized, overlapping volumes form a continuous nebula instead of a
    // regular tile grid. Their soft edges always fade to transparent.
    clouds: Array.from({ length: 38 }, (_, i) => ({
      x: rng() * world.w,
      y: rng() * world.h,
      rx: 170 + rng() * 450,
      ry: 130 + rng() * 340,
      rotation: rng() * TAU,
      tint: tints[i % tints.length],
      alpha: 0.034 + rng() * 0.058,
      phase: rng() * TAU,
    })),
    membranes: Array.from({ length: 20 }, () => ({
      x: rng() * world.w,
      y: rng() * world.h,
      rx: 78 + rng() * 210,
      ry: 42 + rng() * 142,
      rotation: rng() * TAU,
      lobes: 5 + Math.floor(rng() * 5),
      phase: rng() * TAU,
      alpha: 0.032 + rng() * 0.045,
    })),
  };
  fluidFieldCache.set(w.stage.id, field);
  return field;
}

interface AtmosphereCloud {
  x: number; y: number; r: number; tint: string; alpha: number; phase: number;
}
interface AtmosphereMote {
  x: number; y: number; r: number; alpha: number; phase: number; speed: number; tint: string;
}
interface AtmosphereFiber {
  x: number; y: number; cx1: number; cy1: number; cx2: number; cy2: number; x2: number; y2: number; alpha: number;
}
interface AtmosphereField {
  clouds: AtmosphereCloud[];
  motes: AtmosphereMote[];
  fibers: AtmosphereFiber[];
}
const atmosphereCache = new Map<number, AtmosphereField>();

function getAtmosphere(w: World): AtmosphereField {
  const hit = atmosphereCache.get(w.stage.id);
  if (hit) return hit;
  const rng = makeRng(17041 + w.stage.id * 7919);
  const world = w.stage.world;
  const p = w.stage.palette;
  const tints = [p.blob, p.accent, p.dna, p.wallGlow, p.danger];
  const field: AtmosphereField = {
    clouds: Array.from({ length: 15 }, (_, i) => ({
      x: rng() * world.w,
      y: rng() * world.h,
      r: 230 + rng() * 360,
      tint: tints[i % tints.length],
      alpha: 0.035 + rng() * 0.055,
      phase: rng() * TAU,
    })),
    motes: Array.from({ length: 320 }, () => ({
      x: rng() * world.w,
      y: rng() * world.h,
      r: 0.8 + rng() * 2.3,
      alpha: 0.1 + rng() * 0.35,
      phase: rng() * TAU,
      speed: 0.25 + rng() * 1.1,
      tint: tints[Math.floor(rng() * tints.length)],
    })),
    fibers: Array.from({ length: 48 }, () => {
      const x = rng() * world.w;
      const y = rng() * world.h;
      const x2 = x + (rng() - 0.5) * 560;
      const y2 = y + (rng() - 0.5) * 440;
      return {
        x, y, x2, y2,
        cx1: x + (rng() - 0.5) * 360,
        cy1: y + (rng() - 0.5) * 280,
        cx2: x2 + (rng() - 0.5) * 360,
        cy2: y2 + (rng() - 0.5) * 280,
        alpha: 0.025 + rng() * 0.035,
      };
    }),
  };
  atmosphereCache.set(w.stage.id, field);
  return field;
}

function drawAtmosphere(ctx: CanvasRenderingContext2D, w: World, view: View, time: number) {
  const p = w.stage.palette;
  const field = getAtmosphere(w);
  ctx.save();
  ctx.globalCompositeOperation = "screen";

  for (const cloud of field.clouds) {
    if (cloud.x + cloud.r < view.x || cloud.y + cloud.r < view.y ||
        cloud.x - cloud.r > view.x + view.w || cloud.y - cloud.r > view.y + view.h) continue;
    const pulse = 0.85 + Math.sin(time * 0.22 + cloud.phase) * 0.15;
    const radius = cloud.r * pulse;
    const g = ctx.createRadialGradient(cloud.x, cloud.y, radius * 0.03, cloud.x, cloud.y, radius);
    g.addColorStop(0, withAlpha(cloud.tint, cloud.alpha));
    g.addColorStop(0.42, withAlpha(cloud.tint, cloud.alpha * 0.42));
    g.addColorStop(1, withAlpha(cloud.tint, 0));
    ctx.fillStyle = g;
    ctx.fillRect(cloud.x - radius, cloud.y - radius, radius * 2, radius * 2);
  }

  ctx.globalCompositeOperation = "lighter";
  ctx.lineCap = "round";
  for (const fiber of field.fibers) {
    const minX = Math.min(fiber.x, fiber.x2, fiber.cx1, fiber.cx2);
    const maxX = Math.max(fiber.x, fiber.x2, fiber.cx1, fiber.cx2);
    const minY = Math.min(fiber.y, fiber.y2, fiber.cy1, fiber.cy2);
    const maxY = Math.max(fiber.y, fiber.y2, fiber.cy1, fiber.cy2);
    if (maxX < view.x || minX > view.x + view.w || maxY < view.y || minY > view.y + view.h) continue;
    ctx.strokeStyle = withAlpha(p.wallGlow, fiber.alpha);
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(fiber.x, fiber.y);
    ctx.bezierCurveTo(fiber.cx1, fiber.cy1, fiber.cx2, fiber.cy2, fiber.x2, fiber.y2);
    ctx.stroke();
  }

  for (const mote of field.motes) {
    const driftX = Math.sin(time * mote.speed + mote.phase) * 4;
    const driftY = Math.cos(time * mote.speed * 0.7 + mote.phase) * 6;
    const x = mote.x + driftX;
    const y = mote.y + driftY;
    if (x < view.x || y < view.y || x > view.x + view.w || y > view.y + view.h) continue;
    const twinkle = 0.68 + Math.sin(time * 1.7 + mote.phase) * 0.32;
    ctx.globalAlpha = mote.alpha * twinkle;
    ctx.fillStyle = mote.tint;
    ctx.beginPath();
    ctx.arc(x, y, mote.r, 0, TAU);
    ctx.fill();
    if (mote.r > 2.4) {
      ctx.globalAlpha = 0.1 * twinkle;
      ctx.beginPath();
      ctx.arc(x, y, mote.r * 3.6, 0, TAU);
      ctx.fill();
    }
  }
  ctx.restore();
}

function glow(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  color: string,
  alpha = 1,
) {
  const before = ctx.globalAlpha;
  ctx.globalAlpha = alpha;
  ctx.drawImage(getGlow(color), x - r, y - r, r * 2, r * 2);
  ctx.globalAlpha = before;
}

/* ------------------------------------------------------------------ */
/* The player virus                                                    */
/* ------------------------------------------------------------------ */

export function drawVirus(
  ctx: CanvasRenderingContext2D,
  v: Virus,
  t: Traits,
  time: number,
  scaleUp = 1,
) {
  const r = v.r * scaleUp * (1 + Math.sin(v.pulse * 1.4) * 0.035 + v.morph * 0.25);
  const hue = t.bodyHue;
  const light = (l: number, s = 85) => `hsl(${hue} ${s}% ${l}%)`;

  // Bioluminescent aura and fine orbital membranes give the player a clear,
  // premium-looking silhouette without changing hitboxes or game balance.
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  glow(ctx, v.pos.x, v.pos.y, r * (2.55 + t.glow * 0.35), light(57, 90), 0.22 + t.glow * 0.23);
  ctx.globalAlpha = 0.22 + t.glow * 0.09;
  ctx.strokeStyle = light(82, 90);
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.ellipse(v.pos.x, v.pos.y, r * 1.58, r * 1.31, Math.sin(time * 0.35) * 0.12, 0, TAU);
  ctx.stroke();
  ctx.globalAlpha *= 0.55;
  ctx.beginPath();
  ctx.ellipse(v.pos.x, v.pos.y, r * 1.78, r * 1.46, -Math.sin(time * 0.27) * 0.15, time * 0.12, time * 0.12 + Math.PI * 1.3);
  ctx.stroke();
  ctx.restore();

  // ---- Trail -----------------------------------------------------
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let i = v.trail.length - 1; i > 0; i--) {
    const p = v.trail[i];
    const k = 1 - i / v.trail.length;
    const a = p.a * k * 0.5;
    if (a < 0.02) continue;
    ctx.globalAlpha = a;
    ctx.fillStyle = light(60);
    ctx.beginPath();
    ctx.arc(p.x, p.y, r * (0.35 + k * 0.5), 0, TAU);
    ctx.fill();
  }
  ctx.restore();

  // ---- Harvest tendrils ------------------------------------------
  if (t.tendrils > 0) {
    ctx.save();
    ctx.strokeStyle = withAlpha("#8affe0", 0.4);
    ctx.lineWidth = 2;
    const n = 3 + t.tendrils;
    for (let i = 0; i < n; i++) {
      const back = v.angle + Math.PI;
      const spread = (i / (n - 1) - 0.5) * 1.7;
      const seg = 4 + t.tendrils;
      ctx.beginPath();
      for (let s = 0; s <= seg; s++) {
        const f = s / seg;
        const d = r * (1.1 + f * (2.4 + t.tendrils * 1.1));
        const wig = Math.sin(time * 5 + i * 1.7 + f * 5) * (6 + f * 14);
        const a = back + spread * f + (wig / 40) * f;
        const x = v.pos.x + Math.cos(a) * d;
        const y = v.pos.y + Math.sin(a) * d;
        if (s === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  // ---- Flagellum -------------------------------------------------
  if (t.tail > 0) {
    ctx.save();
    ctx.lineCap = "round";
    const tails = t.tail >= 3 ? 2 : 1;
    for (let ti = 0; ti < tails; ti++) {
      const off = ti === 0 ? 0 : 0.34;
      const segs = 16;
      const L = r * (2.6 + t.tail * 0.85);
      ctx.strokeStyle = light(62);
      ctx.lineWidth = 5 - ti * 1.6;
      ctx.beginPath();
      for (let s = 0; s <= segs; s++) {
        const f = s / segs;
        const d = r * 0.9 + f * L;
        const wave =
          Math.sin(v.pulse * 3.4 - f * 6 + ti * 2) * (4 + f * (10 + t.tail * 4));
        const a = v.angle + Math.PI + off;
        const nx = Math.cos(a + Math.PI / 2) * wave;
        const ny = Math.sin(a + Math.PI / 2) * wave;
        const x = v.pos.x + Math.cos(a) * d + nx;
        const y = v.pos.y + Math.sin(a) * d + ny;
        if (s === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  // ---- Magnet aura -----------------------------------------------
  if (t.aura > 80) {
    ctx.save();
    ctx.translate(v.pos.x, v.pos.y);
    ctx.rotate(time * 0.4);
    ctx.strokeStyle = withAlpha("#c98bff", 0.22);
    ctx.lineWidth = 2;
    ctx.setLineDash([12, 16]);
    ctx.beginPath();
    ctx.arc(0, 0, t.aura, 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }

  ctx.save();
  ctx.translate(v.pos.x, v.pos.y);

  // ---- Cilia -----------------------------------------------------
  if (t.cilia > 0) {
    ctx.save();
    ctx.rotate(v.spin * 1.4);
    ctx.strokeStyle = withAlpha(light(70), 0.75);
    ctx.lineWidth = 1.6;
    const n = 14 + t.cilia * 8;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      const beat = Math.sin(time * 16 + i * 0.9) * 0.35;
      const l = r + 5 + t.cilia * 2.5 + beat * 6;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      ctx.lineTo(Math.cos(a + beat * 0.3) * l, Math.sin(a + beat * 0.3) * l);
      ctx.stroke();
    }
    ctx.restore();
  }

  // ---- Spikes ----------------------------------------------------
  ctx.save();
  ctx.rotate(v.spin);
  const spikeCount = t.spikes;
  for (let i = 0; i < spikeCount; i++) {
    const a = (i / spikeCount) * TAU;
    const wob = Math.sin(v.pulse * 2 + i * 1.3) * 0.16;
    const l = t.spikeLen * (1 + wob);
    const tipR = r + l;
    const halfW = 0.09 + t.spikeLen * 0.005;
    const grad = ctx.createLinearGradient(
      Math.cos(a) * r,
      Math.sin(a) * r,
      Math.cos(a) * tipR,
      Math.sin(a) * tipR,
    );
    grad.addColorStop(0, light(52));
    grad.addColorStop(1, t.thorns > 0 ? "#ff6b6b" : light(72));
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(
      Math.cos(a - halfW) * (r - 2),
      Math.sin(a - halfW) * (r - 2),
    );
    ctx.lineTo(Math.cos(a) * tipR, Math.sin(a) * tipR);
    ctx.lineTo(
      Math.cos(a + halfW) * (r - 2),
      Math.sin(a + halfW) * (r - 2),
    );
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  // ---- Body ------------------------------------------------------
  const bodyGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.1, 0, 0, r);
  bodyGrad.addColorStop(0, light(78));
  bodyGrad.addColorStop(0.55, light(56));
  bodyGrad.addColorStop(1, light(30, 70));
  ctx.fillStyle = bodyGrad;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, TAU);
  ctx.fill();

  // Inner membrane ring
  ctx.strokeStyle = withAlpha(light(85), 0.5);
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.74, 0, TAU);
  ctx.stroke();

  // ---- Chitin plates --------------------------------------------
  if (t.plates > 0) {
    ctx.save();
    ctx.rotate(-v.spin * 0.7);
    const n = 3 + t.plates;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      ctx.save();
      ctx.rotate(a);
      ctx.fillStyle = withAlpha("#ffd45e", 0.34);
      ctx.strokeStyle = withAlpha("#ffe9a8", 0.75);
      ctx.lineWidth = 1.4;
      const pw = (TAU * r) / (n * 3.1);
      roundRectPath(ctx, r * 0.5, -pw / 2, r * 0.44, pw, 3);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
  }

  // ---- Regen orbs ------------------------------------------------
  if (t.innerOrbs > 0) {
    const n = 2 + t.innerOrbs;
    for (let i = 0; i < n; i++) {
      const a = time * 1.3 + (i / n) * TAU;
      const d = r * 0.45;
      const pr = r * (0.13 + 0.03 * Math.sin(time * 4 + i));
      ctx.fillStyle = withAlpha("#59ffb0", 0.85);
      ctx.beginPath();
      ctx.arc(Math.cos(a) * d, Math.sin(a) * d, pr, 0, TAU);
      ctx.fill();
    }
  }

  // ---- Nucleoid core --------------------------------------------
  ctx.save();
  ctx.rotate(time * 0.9);
  const core = ctx.createRadialGradient(0, 0, 0, 0, 0, r * 0.42);
  core.addColorStop(0, "rgba(255,255,255,0.95)");
  core.addColorStop(0.5, light(88, 90));
  core.addColorStop(1, withAlpha(light(60), 0));
  ctx.fillStyle = core;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.42, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = withAlpha("#0b2a12", 0.5);
  ctx.lineWidth = 2;
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.3, 0, TAU);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();

  // ---- Taxis eye -------------------------------------------------
  if (t.eye > 0) {
    const a = v.angle;
    ctx.save();
    ctx.translate(Math.cos(a) * r * 0.34, Math.sin(a) * r * 0.34);
    ctx.fillStyle = "#0d1b0f";
    ctx.beginPath();
    ctx.ellipse(0, 0, r * 0.24, r * 0.17, a, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "#ffe066";
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.11 * t.eye * 0.5 + r * 0.05, 0, TAU);
    ctx.fill();
    ctx.restore();
  }

  // Wet membrane specular streak and translucent vesicles add dimensionality.
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.32)";
  ctx.lineWidth = Math.max(1.1, r * 0.035);
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.ellipse(-r * 0.18, -r * 0.26, r * 0.31, r * 0.17, -0.72, Math.PI * 1.05, Math.PI * 1.85);
  ctx.stroke();
  ctx.strokeStyle = withAlpha(light(90), 0.2);
  ctx.lineWidth = 1;
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * TAU + v.spin * 0.4;
    const d = r * (0.58 + (i % 3) * 0.07);
    const rr = r * (0.035 + (i % 2) * 0.018);
    ctx.beginPath();
    ctx.arc(Math.cos(a) * d, Math.sin(a) * d, rr, 0, TAU);
    ctx.stroke();
  }
  ctx.restore();

  ctx.restore();

  // ---- Shield spores --------------------------------------------
  if (v.shield > 0) {
    for (let i = 0; i < v.shield; i++) {
      const a = time * 1.6 + (i / Math.max(1, v.shield)) * TAU;
      const d = r + 14;
      const x = v.pos.x + Math.cos(a) * d;
      const y = v.pos.y + Math.sin(a) * d;
      ctx.fillStyle = "#6ea8ff";
      ctx.beginPath();
      ctx.arc(x, y, 6 + v.shieldFlash * 4, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = withAlpha("#cfe4ff", 0.8);
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }

  // ---- Overlays --------------------------------------------------
  if (v.invuln > 0) {
    const blink = 0.35 + Math.abs(Math.sin(time * 18)) * 0.45;
    ctx.strokeStyle = withAlpha("#ffffff", blink);
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(v.pos.x, v.pos.y, r + 7, 0, TAU);
    ctx.stroke();
  }
  if (v.hurt > 0) {
    ctx.fillStyle = withAlpha("#ff2d55", v.hurt * 0.4);
    ctx.beginPath();
    ctx.arc(v.pos.x, v.pos.y, r, 0, TAU);
    ctx.fill();
  }
  if (v.evolveFlash > 0) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, v.pos.x, v.pos.y, r * 4.5, "#ffffff", v.evolveFlash * 0.55);
    ctx.restore();
  }

  // Enzyme droplets on the rim
  if (t.digest > 0) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const n = Math.min(7, 2 + Math.floor(t.digest / 40));
    for (let i = 0; i < n; i++) {
      const a = time * 0.8 + (i / n) * TAU;
      const d = r + 6;
      glow(
        ctx,
        v.pos.x + Math.cos(a) * d,
        v.pos.y + Math.sin(a) * d,
        7,
        "#b4ff3d",
        0.85,
      );
    }
    ctx.restore();
  }
}

export type MutationPreviewMode =
  | "tails" | "cilia" | "phase" | "armor" | "regen" | "barbs"
  | "magnet" | "net" | "enzymes" | "satellites" | "eyes" | "electric";

/**
 * Every mutation has its own silhouette language as well as a distinct tint.
 * These preview-only signatures make the choices readable even when their
 * underlying gameplay traits share the same basic viral body.
 */
export const MUTATION_PREVIEW_STYLES: Record<string, { mode: MutationPreviewMode; tint: string; hue: number }> = {
  flagellum: { mode: "tails", tint: "#7dff9c", hue: 137 },
  cilia: { mode: "cilia", tint: "#9dff5e", hue: 96 },
  phase: { mode: "phase", tint: "#5ef0ff", hue: 188 },
  plating: { mode: "armor", tint: "#ffd45e", hue: 43 },
  regen: { mode: "regen", tint: "#59ffb0", hue: 151 },
  barbs: { mode: "barbs", tint: "#ff6b6b", hue: 2 },
  magnet: { mode: "magnet", tint: "#c98bff", hue: 273 },
  net: { mode: "net", tint: "#8affe0", hue: 164 },
  enzymes: { mode: "enzymes", tint: "#b4ff3d", hue: 82 },
  fission: { mode: "satellites", tint: "#6ea8ff", hue: 216 },
  taxis: { mode: "eyes", tint: "#ffe066", hue: 48 },
  volt: { mode: "electric", tint: "#7fe7ff", hue: 191 },
};

function strokePolyline(
  ctx: CanvasRenderingContext2D,
  points: { x: number; y: number }[],
  color: string,
  width: number,
  alpha = 1,
) {
  if (points.length < 2) return;
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
  ctx.stroke();
  ctx.restore();
}

function drawMutationSignature(
  ctx: CanvasRenderingContext2D,
  mode: MutationPreviewMode,
  tint: string,
  time: number,
  cx: number,
  cy: number,
  r: number,
  level: number,
) {
  const ring = r * 2.15;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.globalCompositeOperation = "lighter";
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  switch (mode) {
    case "tails": {
      // Two fluid flagella and their motion wake trail backwards from the core.
      for (let tail = 0; tail < (level >= 3 ? 2 : 1); tail++) {
        const offset = tail ? 0.48 : -0.48;
        ctx.strokeStyle = tint;
        ctx.globalAlpha = 0.88 - tail * 0.18;
        ctx.lineWidth = Math.max(1.8, r * (0.12 - tail * 0.025));
        ctx.beginPath();
        for (let i = 0; i <= 18; i++) {
          const f = i / 18;
          const x = -r * 0.82 - f * r * (1.8 + level * 0.28);
          const y = Math.sin(f * 7.5 + time * 3.5 + tail * 1.6) * r * (0.22 + f * 0.52) + offset * r;
          if (!i) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      for (let i = 0; i < 4; i++) {
        const f = 0.35 + i * 0.16;
        glow(ctx, -r * (1.5 + f), Math.sin(time * 3 + i) * r * 0.45, r * 0.16, tint, 0.35);
      }
      break;
    }
    case "cilia": {
      // Distinct short, dense bristles with luminous bead tips.
      const count = 18 + level * 7;
      for (let i = 0; i < count; i++) {
        const a = i / count * TAU + time * 0.16;
        const wave = Math.sin(time * 5.5 + i * 1.31) * r * 0.09;
        const inner = r * 1.04;
        const outer = r * (1.35 + level * 0.08) + wave;
        const x1 = Math.cos(a) * inner, y1 = Math.sin(a) * inner;
        const x2 = Math.cos(a + wave / Math.max(1, r)) * outer;
        const y2 = Math.sin(a + wave / Math.max(1, r)) * outer;
        ctx.strokeStyle = tint;
        ctx.globalAlpha = 0.5 + 0.35 * ((Math.sin(time * 4 + i) + 1) / 2);
        ctx.lineWidth = i % 3 === 0 ? 1.35 : 0.8;
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
        if (i % 2 === 0) { ctx.fillStyle = tint; ctx.beginPath(); ctx.arc(x2, y2, 1.15, 0, TAU); ctx.fill(); }
      }
      break;
    }
    case "phase": {
      // Offset ghost membranes communicate the dash-phase / afterimage effect.
      ctx.lineWidth = 1.65;
      for (let i = 0; i < 3; i++) {
        const ox = Math.sin(time * 1.2 + i) * r * 0.32;
        const oy = Math.cos(time * 0.9 + i) * r * 0.18;
        ctx.globalAlpha = 0.25 + i * 0.12;
        ctx.setLineDash(i === 1 ? [4, 5] : [8, 5]);
        ctx.beginPath();
        ctx.ellipse(ox, oy, r * (1.5 + i * 0.2), r * (1.25 + i * 0.16), time * (i % 2 ? -0.14 : 0.14), time * 0.3 + i, time * 0.3 + i + Math.PI * 1.72);
        ctx.strokeStyle = tint; ctx.stroke();
      }
      ctx.setLineDash([]);
      break;
    }
    case "armor": {
      // Floating chitin plates form a gold exoskeleton instead of a plain halo.
      const count = 5 + level * 2;
      for (let i = 0; i < count; i++) {
        const a = i / count * TAU + time * 0.08;
        const distance = r * (0.82 + (i % 2) * 0.12);
        ctx.save(); ctx.translate(Math.cos(a) * distance, Math.sin(a) * distance); ctx.rotate(a + Math.PI / 2);
        ctx.fillStyle = "rgba(255,212,94,0.22)"; ctx.strokeStyle = tint; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(-r * 0.25, -r * 0.25); ctx.lineTo(r * 0.18, -r * 0.34); ctx.lineTo(r * 0.34, 0); ctx.lineTo(r * 0.12, r * 0.34); ctx.lineTo(-r * 0.26, r * 0.23); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
      }
      ctx.strokeStyle = tint; ctx.globalAlpha = 0.26; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(0, 0, r * 1.62, 0, TAU); ctx.stroke();
      break;
    }
    case "regen": {
      // Healing vesicles, a broken membrane ring and small plus-sign signals.
      ctx.strokeStyle = tint; ctx.globalAlpha = 0.32; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(0, 0, ring, time, time + Math.PI * 1.72); ctx.stroke();
      const count = 4 + level * 2;
      for (let i = 0; i < count; i++) {
        const a = time * 0.55 + i / count * TAU;
        const x = Math.cos(a) * ring, y = Math.sin(a) * ring;
        glow(ctx, x, y, r * 0.28, tint, 0.52);
        ctx.strokeStyle = tint; ctx.globalAlpha = 0.95; ctx.lineWidth = 1.8;
        ctx.beginPath(); ctx.moveTo(x - 3.3, y); ctx.lineTo(x + 3.3, y); ctx.moveTo(x, y - 3.3); ctx.lineTo(x, y + 3.3); ctx.stroke();
      }
      break;
    }
    case "barbs": {
      // Long crimson harpoons with visible side hooks.
      const count = 8 + level * 2;
      for (let i = 0; i < count; i++) {
        const a = i / count * TAU + time * 0.04;
        const inner = r * 1.14, tip = r * (2.05 + level * 0.18);
        const x1 = Math.cos(a) * inner, y1 = Math.sin(a) * inner;
        const xt = Math.cos(a) * tip, yt = Math.sin(a) * tip;
        strokePolyline(ctx, [{ x: x1, y: y1 }, { x: xt, y: yt }], tint, 1.8, 0.95);
        const hx = Math.cos(a) * (tip - r * 0.37), hy = Math.sin(a) * (tip - r * 0.37);
        const side = a + (i % 2 ? 0.72 : -0.72);
        strokePolyline(ctx, [{ x: hx, y: hy }, { x: hx + Math.cos(side) * r * 0.36, y: hy + Math.sin(side) * r * 0.36 }], tint, 1.35, 0.9);
      }
      break;
    }
    case "magnet": {
      // Violet magnetic field and inward-pulling orbiting DNA rhombi.
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = tint; ctx.globalAlpha = 0.25 - i * 0.045; ctx.lineWidth = 1.3;
        ctx.setLineDash(i === 1 ? [2, 4] : [7, 5]);
        ctx.beginPath(); ctx.ellipse(0, 0, r * (1.55 + i * 0.48), r * (1.35 + i * 0.42), time * (i % 2 ? -0.12 : 0.16), 0, TAU); ctx.stroke();
      }
      ctx.setLineDash([]);
      for (let i = 0; i < 5; i++) {
        const a = time * 0.48 + i / 5 * TAU;
        const x = Math.cos(a) * r * 2.6, y = Math.sin(a) * r * 2.25;
        ctx.globalAlpha = 0.55; ctx.strokeStyle = tint; ctx.lineWidth = 1.3;
        ctx.beginPath(); ctx.moveTo(x - 3, y); ctx.lineTo(x, y - 4); ctx.lineTo(x + 3, y); ctx.lineTo(x, y + 4); ctx.closePath(); ctx.stroke();
        strokePolyline(ctx, [{ x: x * 0.82, y: y * 0.82 }, { x: x * 0.36, y: y * 0.36 }], tint, 0.8, 0.3);
      }
      break;
    }
    case "net": {
      // A hexagonal web of sticky tendrils around the specimen.
      const nodes: { x: number; y: number }[] = [];
      const count = 8;
      for (let i = 0; i < count; i++) {
        const a = i / count * TAU + time * 0.07;
        const bend = Math.sin(time * 1.7 + i) * r * 0.18;
        nodes.push({ x: Math.cos(a) * r * 2.5 + Math.cos(a + Math.PI / 2) * bend, y: Math.sin(a) * r * 2.3 + Math.sin(a + Math.PI / 2) * bend });
        strokePolyline(ctx, [{ x: Math.cos(a) * r * 0.9, y: Math.sin(a) * r * 0.9 }, nodes[i]], tint, 1.2, 0.55);
        glow(ctx, nodes[i].x, nodes[i].y, 2.8, tint, 0.58);
      }
      ctx.strokeStyle = tint; ctx.lineWidth = 1.1; ctx.globalAlpha = 0.36;
      for (let i = 0; i < count; i++) { ctx.beginPath(); ctx.moveTo(nodes[i].x, nodes[i].y); ctx.lineTo(nodes[(i + 2) % count].x, nodes[(i + 2) % count].y); ctx.stroke(); }
      break;
    }
    case "enzymes": {
      // Asymmetric catalytic droplets and fizzing microbubbles, lime-green.
      for (let i = 0; i < 9; i++) {
        const a = i / 9 * TAU + Math.sin(time * 0.8 + i) * 0.12;
        const rr = r * (1.55 + (i % 3) * 0.26);
        const x = Math.cos(a) * rr, y = Math.sin(a) * rr;
        ctx.save(); ctx.translate(x, y); ctx.rotate(a + Math.PI / 3);
        ctx.fillStyle = `${tint}50`; ctx.strokeStyle = tint; ctx.lineWidth = 1.1; ctx.globalAlpha = 0.82;
        ctx.beginPath(); ctx.moveTo(0, -r * 0.27); ctx.quadraticCurveTo(r * 0.22, -r * 0.02, 0, r * 0.23); ctx.quadraticCurveTo(-r * 0.19, r * 0.05, 0, -r * 0.27); ctx.fill(); ctx.stroke(); ctx.restore();
        glow(ctx, x + Math.sin(time + i) * 2, y, r * 0.12, tint, 0.42);
      }
      break;
    }
    case "satellites": {
      // Defensive spore satellites each get a ring and a tiny shield glyph.
      const count = Math.min(3, Math.max(1, level));
      for (let i = 0; i < count; i++) {
        const a = time * 0.8 + i / count * TAU;
        const x = Math.cos(a) * r * 2.25, y = Math.sin(a) * r * 2.05;
        glow(ctx, x, y, r * 0.4, tint, 0.45);
        ctx.fillStyle = "rgba(30,95,180,0.42)"; ctx.strokeStyle = tint; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(x, y, r * 0.34, 0, TAU); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(x, y - r * 0.18); ctx.lineTo(x + r * 0.17, y - r * 0.08); ctx.lineTo(x + r * 0.13, y + r * 0.15); ctx.lineTo(x, y + r * 0.25); ctx.lineTo(x - r * 0.13, y + r * 0.15); ctx.lineTo(x - r * 0.17, y - r * 0.08); ctx.closePath(); ctx.stroke();
      }
      break;
    }
    case "eyes": {
      // Multiple sensory eyes, not just a hue change on the base organism.
      const eyes = level >= 3 ? 3 : level === 2 ? 2 : 1;
      const positions = [{ x: r * 0.58, y: -r * 0.15 }, { x: -r * 0.25, y: -r * 0.53 }, { x: -r * 0.15, y: r * 0.52 }];
      for (let i = 0; i < eyes; i++) {
        const pos = positions[i];
        ctx.fillStyle = "rgba(20,18,8,0.9)"; ctx.strokeStyle = tint; ctx.lineWidth = 1.25;
        ctx.beginPath(); ctx.ellipse(pos.x, pos.y, r * 0.21, r * 0.15, time * 0.15 + i * 0.8, 0, TAU); ctx.fill(); ctx.stroke();
        glow(ctx, pos.x, pos.y, r * 0.19, tint, 0.45);
        ctx.fillStyle = "#fff3ad"; ctx.beginPath(); ctx.arc(pos.x + Math.cos(time * 0.7 + i) * 1.2, pos.y, r * 0.075, 0, TAU); ctx.fill();
      }
      break;
    }
    case "electric": {
      // Angular cyan arcs with forked lightning branches.
      ctx.strokeStyle = tint; ctx.globalAlpha = 0.45; ctx.lineWidth = 1.4; ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.arc(0, 0, r * 1.65, time, time + Math.PI * 1.55); ctx.stroke(); ctx.setLineDash([]);
      const count = 5;
      for (let i = 0; i < count; i++) {
        const a = i / count * TAU + time * 0.22;
        const points: { x: number; y: number }[] = [];
        for (let j = 0; j <= 4; j++) {
          const f = j / 4;
          const d = r * (1.05 + f * 1.78);
          const side = j === 0 || j === 4 ? 0 : (j % 2 ? 0.18 : -0.16) * r;
          points.push({ x: Math.cos(a) * d + Math.cos(a + Math.PI / 2) * side, y: Math.sin(a) * d + Math.sin(a + Math.PI / 2) * side });
        }
        glow(ctx, points[2].x, points[2].y, r * 0.2, tint, 0.45);
        strokePolyline(ctx, points, tint, 1.8, 0.95);
        if (i % 2 === 0) {
          const end = points[2];
          strokePolyline(ctx, [end, { x: end.x + Math.cos(a + 0.82) * r * 0.4, y: end.y + Math.sin(a + 0.82) * r * 0.4 }], tint, 1.1, 0.7);
        }
      }
      break;
    }
  }
  ctx.restore();
}

/** Standalone, unclipped specimen preview with a mutation-specific silhouette. */
export function drawVirusPreview(
  ctx: CanvasRenderingContext2D,
  traits: Traits,
  time: number,
  w: number,
  h: number,
  scaleUp = 1,
  mutationId?: string,
  mutationLevel = 1,
) {
  const style = mutationId ? MUTATION_PREVIEW_STYLES[mutationId] : undefined;
  // Gameplay aura distances may exceed the thumbnail by several times. Keep
  // the generic body inside the transparent canvas; the magnet draws its own
  // correctly scaled, mutation-specific field in drawMutationSignature.
  const previewTraits: Traits = {
    ...traits,
    aura: Math.min(traits.aura, 62),
    bodyHue: style?.hue ?? traits.bodyHue,
  };
  const fake: Virus = {
    pos: { x: w / 2, y: h / 2 },
    vel: { x: 0, y: 0 },
    angle: -Math.PI / 2,
    spin: time * 0.5,
    r: previewTraits.radius,
    hp: previewTraits.maxHp,
    invuln: 0,
    hitFlash: 0,
    hurt: 0,
    dashTime: 0,
    dashCd: 0,
    acidGrace: 0,
    dashDir: { x: 0, y: 0 },
    evolveFlash: 0,
    morph: 0,
    trail: [],
    pulse: time * 2,
    shield: previewTraits.shieldMax,
    shieldFlash: 0,
  };
  ctx.clearRect(0, 0, w, h);
  // The cloned traits carry no gameplay consequences; only this isolated canvas sees them.
  drawVirus(ctx, fake, previewTraits, time, scaleUp);
  if (style) {
    const r = Math.min(22, previewTraits.radius * scaleUp);
    drawMutationSignature(ctx, style.mode, style.tint, time, w / 2, h / 2, r, Math.max(1, Math.min(3, Math.floor(mutationLevel))));
  }
}

/* ------------------------------------------------------------------ */
/* Enemies                                                             */
/* ------------------------------------------------------------------ */

export function drawEnemy(
  ctx: CanvasRenderingContext2D,
  e: Enemy,
  time: number,
) {
  const flash = e.hitFlash;
  ctx.save();
  ctx.translate(e.pos.x, e.pos.y);

  // Special attacks are deliberately readable before they become dangerous.
  if (e.kind === "symbiote" && e.specialState === "telegraph" && e.specialTarget) {
    const dx = e.specialTarget.x - e.pos.x;
    const dy = e.specialTarget.y - e.pos.y;
    const pulse = 0.58 + Math.sin(time * 13) * 0.18;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const link = ctx.createLinearGradient(0, 0, dx, dy);
    link.addColorStop(0, "rgba(74,255,184,0.82)");
    link.addColorStop(0.55, "rgba(96,255,208,0.35)");
    link.addColorStop(1, "rgba(74,255,184,0.05)");
    ctx.strokeStyle = link;
    ctx.lineWidth = 5 + pulse * 2;
    ctx.shadowColor = "#5effbd";
    ctx.shadowBlur = 18;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(dx * 0.28, dy * 0.28 - 26, dx * 0.72, dy * 0.72 + 26, dx, dy);
    ctx.stroke();
    for (let i = 1; i <= 3; i++) {
      const f = ((time * 0.7 + i * 0.25) % 1);
      const x = dx * f;
      const y = dy * f + Math.sin(time * 8 + i) * 9;
      ctx.fillStyle = "rgba(190,255,225,0.9)";
      ctx.beginPath();
      ctx.arc(x, y, 3 + pulse * 2, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }
  if (e.kind === "phantom" && e.specialState === "telegraph" && e.specialTarget) {
    const dx = e.specialTarget.x - e.pos.x;
    const dy = e.specialTarget.y - e.pos.y;
    const pulse = 0.55 + Math.sin(time * 25) * 0.3;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.strokeStyle = `rgba(190,158,255,${pulse})`;
    ctx.lineWidth = 2.5;
    ctx.setLineDash([9, 9]);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(dx, dy);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = `rgba(209,184,255,${pulse})`;
    ctx.beginPath();
    ctx.arc(dx, dy, 22 + Math.sin(time * 14) * 4, 0, TAU);
    ctx.stroke();
    ctx.restore();
  }
  if (e.kind === "incubator" && e.specialState === "telegraph") {
    const progress = clamp(1 - e.specialTimer / 1.35, 0, 1);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.strokeStyle = `rgba(255,125,101,${0.35 + progress * 0.5})`;
    ctx.lineWidth = 3 + progress * 3;
    ctx.beginPath();
    ctx.arc(0, 0, e.r * (1.25 + progress * 0.55), -Math.PI / 2, -Math.PI / 2 + TAU * progress);
    ctx.stroke();
    ctx.restore();
  }

  const enemyTint: Record<Enemy["kind"], string> = {
    mite: "#ff9d5c",
    spore: "#b879ff",
    chaser: "#ff62c2",
    spiker: "#ff7a2f",
    hunter: "#7ccfff",
    symbiote: "#62ffc1",
    phantom: "#a98cff",
    incubator: "#ff765e",
    sentinel: "#ff9e43",
  };
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  glow(ctx, 0, 0, e.r * (e.kind === "sentinel" ? 3.4 : e.kind === "incubator" ? 3.1 : 2.45), enemyTint[e.kind], e.kind === "sentinel" || e.kind === "incubator" ? 0.42 : 0.28);
  ctx.restore();
  // The phantom's body fades, but its refraction rings remain visible as a fair cue.
  if (e.kind === "phantom") {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.22 + e.stealth * 0.42;
    ctx.strokeStyle = "#b99bff";
    ctx.lineWidth = 2;
    for (let i = 0; i < 3; i++) {
      const radius = e.r * (1.18 + i * 0.2) + Math.sin(time * 4 + i) * 3;
      ctx.beginPath();
      ctx.ellipse(0, 0, radius, radius * (0.56 + i * 0.04), e.angle + i * 0.4, time * 0.7 + i, time * 0.7 + i + Math.PI * 1.35);
      ctx.stroke();
    }
    ctx.restore();
  }

  ctx.save();
  if (e.kind === "phantom") ctx.globalAlpha = clamp(1 - e.stealth * 0.82, 0.2, 1);
  switch (e.kind) {
    case "mite": {
      const wob = Math.sin(e.t * 6 + e.seed) * 0.12;
      ctx.save();
      ctx.rotate(e.angle);
      ctx.strokeStyle = "rgba(255,175,120,0.55)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 4; i++) {
        const a = -0.6 + i * 0.4;
        const l = e.r * (1.5 + Math.sin(time * 12 + i) * 0.3);
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * e.r, Math.sin(a) * e.r);
        ctx.lineTo(Math.cos(a) * l, Math.sin(a) * l);
        ctx.stroke();
      }
      ctx.restore();
      const g = ctx.createRadialGradient(-e.r * 0.3, -e.r * 0.3, 1, 0, 0, e.r);
      g.addColorStop(0, "#ffd2a8");
      g.addColorStop(0.6, "#ff9f5e");
      g.addColorStop(1, "#c85a2e");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.ellipse(0, 0, e.r * (1 + wob), e.r * (1 - wob), e.angle, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(60,20,10,0.7)";
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 0.32, 0, TAU);
      ctx.fill();
      break;
    }
    case "spore": {
      ctx.save();
      ctx.rotate(e.angle * 0.4);
      ctx.strokeStyle = "rgba(200,150,255,0.5)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * e.r * 0.8, Math.sin(a) * e.r * 0.8);
        ctx.lineTo(Math.cos(a) * e.r * 1.35, Math.sin(a) * e.r * 1.35);
        ctx.stroke();
      }
      ctx.restore();
      const g = ctx.createRadialGradient(0, 0, 1, 0, 0, e.r);
      g.addColorStop(0, "#f0dcff");
      g.addColorStop(0.55, "#b07bff");
      g.addColorStop(1, "#5c2b9c");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.arc(0, 0, e.r, 0, TAU);
      ctx.fill();
      break;
    }
    case "chaser": {
      // Macrophage: lobed blob reaching toward its target
      const lobes = 9;
      ctx.beginPath();
      for (let i = 0; i <= lobes; i++) {
        const a = (i / lobes) * TAU;
        const reach = 1 + 0.22 * Math.cos(a - e.angle);
        const rr = e.r * reach * (1 + 0.08 * Math.sin(e.t * 5 + i * 2));
        const x = Math.cos(a) * rr;
        const y = Math.sin(a) * rr;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      const g = ctx.createRadialGradient(0, 0, e.r * 0.2, 0, 0, e.r * 1.2);
      g.addColorStop(0, "rgba(255,190,235,0.95)");
      g.addColorStop(0.5, "rgba(255,110,200,0.75)");
      g.addColorStop(1, "rgba(150,30,110,0.45)");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.fill();
      ctx.strokeStyle = "rgba(255,200,240,0.8)";
      ctx.lineWidth = 2;
      ctx.stroke();
      // Nucleus + granules
      ctx.fillStyle = "rgba(90,15,70,0.75)";
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 0.42, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      for (let i = 0; i < 5; i++) {
        const a = e.t * 1.2 + i * 1.3;
        ctx.beginPath();
        ctx.arc(Math.cos(a) * e.r * 0.6, Math.sin(a) * e.r * 0.6, 3, 0, TAU);
        ctx.fill();
      }
      break;
    }
    case "spiker": {
      ctx.save();
      ctx.rotate(e.angle);
      ctx.strokeStyle = "#ff7a2f";
      ctx.lineWidth = 4;
      ctx.lineCap = "round";
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * e.r * 0.7, Math.sin(a) * e.r * 0.7);
        ctx.lineTo(Math.cos(a) * e.r * 1.85, Math.sin(a) * e.r * 1.85);
        ctx.stroke();
      }
      ctx.restore();
      const pulse = 0.5 + Math.abs(Math.sin(e.t * 3)) * 0.5;
      const g = ctx.createRadialGradient(0, 0, 1, 0, 0, e.r);
      g.addColorStop(0, `rgba(255,220,120,${0.6 + pulse * 0.4})`);
      g.addColorStop(0.6, "#8c2f10");
      g.addColorStop(1, "#3a1206");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.arc(0, 0, e.r, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = `rgba(255,90,40,${0.4 + pulse * 0.6})`;
      ctx.lineWidth = 3;
      ctx.stroke();
      break;
    }
    case "hunter": {
      // Y-shaped antibody
      ctx.save();
      ctx.rotate(e.angle);
      ctx.lineCap = "round";
      ctx.strokeStyle = flash > 0 ? "#ffffff" : "#dff0ff";
      ctx.lineWidth = e.r * 0.42;
      ctx.beginPath();
      ctx.moveTo(-e.r * 0.9, 0);
      ctx.lineTo(e.r * 0.3, 0);
      ctx.stroke();
      ctx.lineWidth = e.r * 0.34;
      ctx.beginPath();
      ctx.moveTo(e.r * 0.2, 0);
      ctx.lineTo(e.r * 1.0, -e.r * 0.85);
      ctx.moveTo(e.r * 0.2, 0);
      ctx.lineTo(e.r * 1.0, e.r * 0.85);
      ctx.stroke();
      ctx.fillStyle = "#8fc6ff";
      ctx.beginPath();
      ctx.arc(-e.r * 0.9, 0, e.r * 0.34, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#ff5f7e";
      ctx.beginPath();
      ctx.arc(e.r * 1.0, -e.r * 0.85, e.r * 0.24, 0, TAU);
      ctx.arc(e.r * 1.0, e.r * 0.85, e.r * 0.24, 0, TAU);
      ctx.fill();
      ctx.restore();
      // Telegraph the shot
      if (e.cool < 0.45) {
        ctx.strokeStyle = `rgba(255,210,60,${0.25 + Math.sin(time * 30) * 0.2})`;
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 10]);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(Math.cos(e.angle) * 300, Math.sin(e.angle) * 300);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      break;
    }
    case "symbiote": {
      // A six-lobed floating healer with branching cilia and a bright emerald nucleus.
      const pulse = 0.5 + Math.sin(time * 3.2 + e.seed) * 0.5;
      ctx.save();
      ctx.rotate(e.t * 0.22);
      ctx.lineCap = "round";
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * TAU;
        const wave = Math.sin(time * 3.4 + i * 1.7 + e.seed) * 5;
        const x1 = Math.cos(a) * e.r * 0.66;
        const y1 = Math.sin(a) * e.r * 0.66;
        const x2 = Math.cos(a) * (e.r * 1.38 + wave);
        const y2 = Math.sin(a) * (e.r * 1.38 + wave);
        ctx.strokeStyle = "rgba(115,255,197,0.72)";
        ctx.lineWidth = 3.2;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.quadraticCurveTo(Math.cos(a + 0.22) * e.r * 1.1, Math.sin(a + 0.22) * e.r * 1.1, x2, y2);
        ctx.stroke();
        ctx.fillStyle = "rgba(198,255,224,0.92)";
        ctx.beginPath();
        ctx.arc(x2, y2, 3.5 + pulse * 2, 0, TAU);
        ctx.fill();
      }
      ctx.restore();
      const g = ctx.createRadialGradient(-e.r * 0.28, -e.r * 0.32, 2, 0, 0, e.r * 1.05);
      g.addColorStop(0, "#e2fff0");
      g.addColorStop(0.24, "#88ffd0");
      g.addColorStop(0.62, "#25bd91");
      g.addColorStop(1, "#075b57");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      for (let i = 0; i <= 72; i++) {
        const a = (i / 72) * TAU;
        const lobe = 1 + 0.12 * Math.cos(a * 7 + e.t * 1.8) + 0.035 * Math.sin(a * 14 - e.t * 2.2);
        const x = Math.cos(a) * e.r * lobe;
        const y = Math.sin(a) * e.r * lobe;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "rgba(204,255,230,0.8)";
      ctx.lineWidth = 2.2;
      ctx.stroke();
      ctx.fillStyle = "rgba(4,70,62,0.72)";
      ctx.beginPath();
      ctx.ellipse(0, 0, e.r * 0.43, e.r * 0.34, Math.sin(time) * 0.18, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(235,255,245,0.88)";
      for (let i = 0; i < 4; i++) {
        const a = time * 0.9 + i * TAU / 4;
        ctx.beginPath();
        ctx.arc(Math.cos(a) * e.r * 0.67, Math.sin(a) * e.r * 0.67, 3 + pulse * 1.5, 0, TAU);
        ctx.fill();
      }
      if (e.specialState === "telegraph") {
        ctx.strokeStyle = `rgba(136,255,205,${0.65 + pulse * 0.3})`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, e.r * (1.45 + pulse * 0.1), 0, TAU);
        ctx.stroke();
      }
      break;
    }
    case "phantom": {
      // Refractive diamond organism: deliberately angular, unlike the rounder base enemies.
      const pulse = 0.5 + Math.sin(time * 4.8 + e.seed) * 0.5;
      ctx.save();
      ctx.rotate(e.angle + Math.sin(time * 0.7 + e.seed) * 0.08);
      const outer = e.r * (1.12 + pulse * 0.05);
      const g = ctx.createLinearGradient(-outer, -outer, outer, outer);
      g.addColorStop(0, "rgba(238,226,255,0.95)");
      g.addColorStop(0.28, "rgba(173,140,255,0.9)");
      g.addColorStop(0.68, "rgba(90,64,180,0.78)");
      g.addColorStop(1, "rgba(30,24,83,0.88)");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.moveTo(0, -outer * 1.38);
      ctx.bezierCurveTo(outer * 0.56, -outer * 0.8, outer * 1.12, -outer * 0.28, outer * 0.82, outer * 0.48);
      ctx.lineTo(0, outer * 1.24);
      ctx.lineTo(-outer * 0.82, outer * 0.48);
      ctx.bezierCurveTo(-outer * 1.12, -outer * 0.28, -outer * 0.56, -outer * 0.8, 0, -outer * 1.38);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "rgba(224,211,255,0.94)";
      ctx.lineWidth = 2.4;
      ctx.stroke();
      ctx.strokeStyle = "rgba(233,222,255,0.7)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(0, -outer * 1.05);
      ctx.lineTo(0, outer * 0.9);
      ctx.moveTo(-outer * 0.64, -outer * 0.16);
      ctx.lineTo(outer * 0.64, -outer * 0.16);
      ctx.stroke();
      const core = ctx.createRadialGradient(-4, -5, 1, 0, 0, outer * 0.47);
      core.addColorStop(0, "#fffaff");
      core.addColorStop(0.32, "#d8c2ff");
      core.addColorStop(1, "#6c4cce");
      ctx.fillStyle = core;
      ctx.beginPath();
      ctx.arc(0, 0, outer * 0.39, 0, TAU);
      ctx.fill();
      ctx.restore();
      // A thin, broken afterimage makes the cloaking readable without exposing the body.
      ctx.strokeStyle = `rgba(206,187,255,${0.28 + pulse * 0.28})`;
      ctx.lineWidth = 2;
      for (let i = 0; i < 4; i++) {
        const a = time * 0.65 + i * TAU / 4;
        ctx.beginPath();
        ctx.arc(0, 0, e.r * 1.52, a, a + 0.62);
        ctx.stroke();
      }
      if (e.specialState === "active") {
        ctx.strokeStyle = `rgba(224,207,255,${0.72 + pulse * 0.2})`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, e.r * 1.72, 0, TAU);
        ctx.stroke();
      }
      break;
    }
    case "incubator": {
      // Stationary brood cyst with six translucent egg chambers around a protected core.
      const pulse = 0.5 + Math.sin(time * 2.6 + e.seed) * 0.5;
      ctx.save();
      ctx.rotate(e.angle);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        const x = Math.cos(a) * e.r * 0.83;
        const y = Math.sin(a) * e.r * 0.83;
        const eggPulse = 0.9 + Math.sin(time * 3 + i * 1.8 + e.seed) * 0.08;
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(a);
        const egg = ctx.createRadialGradient(-3, -4, 1, 0, 0, e.r * 0.34);
        egg.addColorStop(0, "#ffe6c8");
        egg.addColorStop(0.42, "#ff9d78");
        egg.addColorStop(1, "#812e3a");
        ctx.fillStyle = flash > 0 ? "#ffffff" : egg;
        ctx.beginPath();
        ctx.ellipse(0, 0, e.r * 0.28 * eggPulse, e.r * 0.37 * eggPulse, 0, 0, TAU);
        ctx.fill();
        ctx.strokeStyle = "rgba(255,226,194,0.82)";
        ctx.lineWidth = 1.7;
        ctx.stroke();
        ctx.fillStyle = "rgba(255,226,198,0.72)";
        ctx.beginPath();
        ctx.arc(0, 2, e.r * 0.09, 0, TAU);
        ctx.fill();
        ctx.restore();
      }
      const shell = ctx.createRadialGradient(-e.r * 0.28, -e.r * 0.3, 2, 0, 0, e.r * 0.95);
      shell.addColorStop(0, "#fff0d7");
      shell.addColorStop(0.24, "#ffae83");
      shell.addColorStop(0.62, "#d84f4f");
      shell.addColorStop(1, "#531d37");
      ctx.fillStyle = flash > 0 ? "#ffffff" : shell;
      ctx.beginPath();
      ctx.ellipse(0, 0, e.r * 0.7, e.r * 0.64, 0, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,216,190,0.92)";
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.fillStyle = "rgba(91,20,44,0.72)";
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 0.3, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#ffd7c0";
      for (let i = 0; i < 3; i++) {
        const a = time * 0.8 + i * TAU / 3;
        ctx.beginPath();
        ctx.arc(Math.cos(a) * e.r * 0.18, Math.sin(a) * e.r * 0.18, 3.8, 0, TAU);
        ctx.fill();
      }
      ctx.restore();
      // The red hatch-progress ring is separate from the egg artwork.
      if (e.specialState === "telegraph") {
        ctx.strokeStyle = `rgba(255,135,105,${0.55 + pulse * 0.35})`;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, e.r * 1.5, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(1 - e.specialTimer / 1.35, 0, 1));
        ctx.stroke();
      }
      break;
    }
    case "sentinel": {
      const pulse = 0.5 + Math.sin(time * 2) * 0.5;
      ctx.save();
      ctx.rotate(e.angle);
      // Outer ring
      ctx.strokeStyle = "#ff9a3d";
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.arc(0, 0, e.r, 0, TAU);
      ctx.stroke();
      // Spokes
      ctx.strokeStyle = "rgba(255,180,90,0.85)";
      ctx.lineWidth = 5;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * e.r * 0.4, Math.sin(a) * e.r * 0.4);
        ctx.lineTo(Math.cos(a) * e.r, Math.sin(a) * e.r);
        ctx.stroke();
      }
      // Core
      const g = ctx.createRadialGradient(0, 0, 2, 0, 0, e.r * 0.7);
      g.addColorStop(0, "#fff2cc");
      g.addColorStop(0.5, "#ff8a3d");
      g.addColorStop(1, "#7a1f0a");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 0.55 * (1 + pulse * 0.05), 0, TAU);
      ctx.fill();
      ctx.restore();
      // Orbit pods
      for (let i = 0; i < 4; i++) {
        const a = -e.angle * 1.6 + (i / 4) * TAU;
        const d = e.r * 1.4;
        ctx.fillStyle = "#ffd45e";
        ctx.beginPath();
        ctx.arc(Math.cos(a) * d, Math.sin(a) * d, 9, 0, TAU);
        ctx.fill();
      }
      if (e.shielded) {
        ctx.strokeStyle = `rgba(255,212,94,${0.4 + pulse * 0.35})`;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, e.r * 1.75, 0, TAU);
        ctx.stroke();
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * TAU + time * 0.7;
          ctx.fillStyle = "rgba(255,212,94,0.75)";
          ctx.beginPath();
          ctx.arc(
            Math.cos(a) * e.r * 1.75,
            Math.sin(a) * e.r * 1.75,
            4,
            0,
            TAU,
          );
          ctx.fill();
        }
      }
      break;
    }
  }
  ctx.restore();
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/* Pickups, bullets, particles                                         */
/* ------------------------------------------------------------------ */

export function drawPickup(
  ctx: CanvasRenderingContext2D,
  p: Pickup,
  pal: Palette,
  time: number,
) {
  const bob = Math.sin(time * 3 + p.seed) * 3;
  ctx.save();
  ctx.translate(p.pos.x, p.pos.y + bob);
  if (p.kind === "dna") {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, 0, 0, 20, pal.dna, 0.7);
    ctx.restore();
    ctx.strokeStyle = pal.dna;
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    const spin = time * 2 + p.seed;
    for (let s = -1; s <= 1; s += 2) {
      ctx.beginPath();
      for (let i = 0; i <= 8; i++) {
        const f = i / 8;
        const y = (f - 0.5) * 18;
        const x = Math.sin(f * Math.PI * 2 + spin) * 5 * s;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 3; i++) {
      const f = 0.2 + i * 0.3;
      const y = (f - 0.5) * 18;
      const x = Math.sin(f * Math.PI * 2 + spin) * 5;
      ctx.beginPath();
      ctx.moveTo(-x, y);
      ctx.lineTo(x, y);
      ctx.stroke();
    }
    // Bright paired base-pairs make the collectible readable at a glance.
    for (let i = 0; i < 4; i++) {
      const f = (i + 0.5) / 4;
      const y = (f - 0.5) * 18;
      const x = Math.sin(f * Math.PI * 2 + spin) * 5;
      ctx.fillStyle = i % 2 === 0 ? "rgba(255,255,255,0.92)" : pal.dna;
      ctx.beginPath();
      ctx.arc(x, y, 1.45, 0, TAU);
      ctx.arc(-x, y, 1.45, 0, TAU);
      ctx.fill();
    }
  } else if (p.kind === "plasmid") {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, 0, 0, 34, "#ffe066", 0.85);
    ctx.restore();
    ctx.rotate(time * 1.4 + p.seed);
    ctx.strokeStyle = "#ffe066";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, 0, p.r, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 8]);
    ctx.beginPath();
    ctx.arc(0, 0, p.r * 0.55, 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
  } else if (p.kind === "heal") {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, 0, 0, 26, "#7dff9c", 0.7);
    ctx.restore();
    ctx.fillStyle = "#7dff9c";
    roundRectPath(ctx, -10, -4, 20, 8, 3);
    ctx.fill();
    roundRectPath(ctx, -4, -10, 8, 20, 3);
    ctx.fill();
  } else {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, 0, 0, 26, "#6ea8ff", 0.7);
    ctx.restore();
    ctx.rotate(time * 0.9);
    ctx.strokeStyle = "#6ea8ff";
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU;
      const x = Math.cos(a) * 11;
      const y = Math.sin(a) * 11;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  }
  ctx.restore();
}

export function drawBullet(
  ctx: CanvasRenderingContext2D,
  b: { pos: { x: number; y: number }; vel: { x: number; y: number }; r: number; color: string; t: number; life: number; maxLife: number; kind: string },
) {
  const a = Math.atan2(b.vel.y, b.vel.x);
  ctx.save();
  ctx.translate(b.pos.x, b.pos.y);
  ctx.rotate(a);
  ctx.globalCompositeOperation = "lighter";
  glow(ctx, 0, 0, b.r * 4, b.color, 0.8);
  ctx.globalCompositeOperation = "source-over";
  if (b.kind === "shard") {
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.moveTo(b.r * 1.6, 0);
    ctx.lineTo(-b.r, b.r * 0.8);
    ctx.lineTo(-b.r, -b.r * 0.8);
    ctx.closePath();
    ctx.fill();
  } else if (b.kind === "wave") {
    const pulse = 1 + Math.sin(b.t * 20) * 0.15;
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.arc(0, 0, b.r * pulse, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.beginPath();
    ctx.arc(0, 0, b.r * 0.45, 0, TAU);
    ctx.fill();
  } else {
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.ellipse(0, 0, b.r * 2, b.r * 0.8, 0, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.beginPath();
    ctx.ellipse(0, 0, b.r * 0.9, b.r * 0.4, 0, 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}

export function drawParticle(
  ctx: CanvasRenderingContext2D,
  p: Particle,
) {
  const k = clamp(p.life / p.maxLife, 0, 1);
  ctx.save();
  if (p.kind === "ring") {
    ctx.globalAlpha = k * 0.8;
    ctx.strokeStyle = p.color;
    ctx.lineWidth = 2 + k * 5;
    ctx.beginPath();
    ctx.arc(p.pos.x, p.pos.y, p.r, 0, TAU);
    ctx.stroke();
  } else if (p.kind === "blob") {
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = k * 0.75;
    glow(ctx, p.pos.x, p.pos.y, p.r * 2.4, p.color, 1);
  } else if (p.kind === "shard") {
    ctx.globalAlpha = k;
    ctx.translate(p.pos.x, p.pos.y);
    ctx.rotate(p.angle);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.moveTo(p.r, 0);
    ctx.lineTo(-p.r * 0.7, p.r * 0.6);
    ctx.lineTo(-p.r * 0.7, -p.r * 0.6);
    ctx.closePath();
    ctx.fill();
  } else if (p.kind === "dna") {
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = k;
    glow(ctx, p.pos.x, p.pos.y, p.r * 3, p.color, 1);
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.pos.x, p.pos.y, p.r * 0.4, 0, TAU);
    ctx.fill();
  } else {
    ctx.globalAlpha = k;
    ctx.globalCompositeOperation = "lighter";
    ctx.strokeStyle = p.color;
    ctx.lineWidth = Math.max(1, p.r * 0.5);
    ctx.beginPath();
    ctx.moveTo(p.pos.x, p.pos.y);
    ctx.lineTo(p.pos.x - p.vel.x * 0.03, p.pos.y - p.vel.y * 0.03);
    ctx.stroke();
  }
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/* Arena                                                               */
/* ------------------------------------------------------------------ */

export function drawTargetCell(ctx: CanvasRenderingContext2D, w: World, time: number) {
  const t = w.target;
  const p = w.stage.palette;
  const r = t.r;
  ctx.save();
  ctx.translate(t.pos.x, t.pos.y);

  // Outer halo
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const halo = t.unlocked ? p.dna : "#ff6b81";
  glow(ctx, 0, 0, r * (t.unlocked ? 3.8 : 2.9), halo, 0.62 + Math.sin(time * 2) * 0.14);
  ctx.restore();

  // Two rotating membrane guides, like a living cell seen through a scanner.
  ctx.save();
  ctx.rotate(time * (t.unlocked ? 0.12 : -0.09));
  ctx.globalAlpha = t.unlocked ? 0.38 : 0.23;
  ctx.strokeStyle = t.unlocked ? p.dna : "#ff8fa3";
  ctx.lineWidth = 1.6;
  ctx.setLineDash([r * 0.09, r * 0.08]);
  ctx.beginPath();
  ctx.arc(0, 0, r * 1.14, 0.1, TAU * 0.94);
  ctx.stroke();
  ctx.setLineDash([4, 12]);
  ctx.globalAlpha *= 0.65;
  ctx.beginPath();
  ctx.arc(0, 0, r * 1.27, -0.8, 2.8);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();

  // Membrane (wobbling)
  const lobes = 14;
  ctx.beginPath();
  for (let i = 0; i <= lobes; i++) {
    const a = (i / lobes) * TAU;
    const rr = r * (1 + 0.055 * Math.sin(a * 3 + time * 1.6));
    const x = Math.cos(a) * rr;
    const y = Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  const g = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
  if (t.unlocked) {
    g.addColorStop(0, "rgba(255,255,230,0.95)");
    g.addColorStop(0.5, "rgba(180,255,120,0.7)");
    g.addColorStop(1, "rgba(40,120,60,0.35)");
  } else {
    g.addColorStop(0, "rgba(255,225,225,0.9)");
    g.addColorStop(0.5, "rgba(255,120,150,0.6)");
    g.addColorStop(1, "rgba(120,30,60,0.3)");
  }
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = t.unlocked ? p.dna : "#ff8fa3";
  ctx.lineWidth = 3;
  ctx.stroke();

  // Nucleus
  const ng = ctx.createRadialGradient(0, 0, 2, 0, 0, r * 0.44);
  ng.addColorStop(0, "rgba(255,255,255,0.95)");
  ng.addColorStop(0.6, t.unlocked ? "rgba(150,255,120,0.8)" : "rgba(255,160,180,0.75)");
  ng.addColorStop(1, "rgba(30,20,60,0.2)");
  ctx.fillStyle = ng;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.44 * (1 + t.infected * 0.5), 0, TAU);
  ctx.fill();

  // Fine chromatin threads around the nucleus, barely visible through the membrane.
  ctx.save();
  ctx.rotate(-time * 0.18);
  ctx.strokeStyle = t.unlocked ? "rgba(220,255,180,0.23)" : "rgba(255,190,205,0.2)";
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * TAU;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * r * 0.22, Math.sin(a) * r * 0.22);
    ctx.bezierCurveTo(Math.cos(a + 0.5) * r * 0.48, Math.sin(a + 0.5) * r * 0.48,
      Math.cos(a - 0.25) * r * 0.72, Math.sin(a - 0.25) * r * 0.72,
      Math.cos(a + 0.1) * r * 0.83, Math.sin(a + 0.1) * r * 0.83);
    ctx.stroke();
  }
  ctx.restore();

  // Chromatin specks
  ctx.fillStyle = t.unlocked ? "rgba(60,120,40,0.5)" : "rgba(90,30,60,0.5)";
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * TAU + time * 0.3;
    const d = r * (0.6 + 0.2 * Math.sin(time + i));
    ctx.beginPath();
    ctx.arc(Math.cos(a) * d, Math.sin(a) * d, 4.5, 0, TAU);
    ctx.fill();
  }

  if (!t.unlocked) {
    // Lock ring showing required DNA
    const frac = clamp(w.collected / w.stage.quota, 0, 1);
    ctx.strokeStyle = "rgba(255,255,255,0.25)";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(0, 0, r + 26, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = p.dna;
    ctx.beginPath();
    ctx.arc(0, 0, r + 26, -Math.PI / 2, -Math.PI / 2 + frac * TAU);
    ctx.stroke();
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + time * 0.5;
      ctx.fillStyle = "rgba(255,120,140,0.8)";
      ctx.save();
      ctx.rotate(a);
      roundRectPath(ctx, r + 18, -3, 12, 6, 2);
      ctx.fill();
      ctx.restore();
    }
  } else {
    // Pulsing invitation rings
    for (let i = 0; i < 3; i++) {
      const f = (time * 0.55 + i / 3) % 1;
      ctx.globalAlpha = (1 - f) * 0.5;
      ctx.strokeStyle = p.dna;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, r + f * 70, 0, TAU);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
  ctx.restore();
}

function drawWalls(
  ctx: CanvasRenderingContext2D,
  w: World,
  view: View,
  time: number,
) {
  const p = w.stage.palette;
  for (const r of w.wallRects()) {
    if (
      r.x + r.w < view.x ||
      r.y + r.h < view.y ||
      r.x > view.x + view.w ||
      r.y > view.y + view.h
    )
      continue;
    const g = ctx.createLinearGradient(r.x, r.y, r.x, r.y + r.h);
    g.addColorStop(0, withAlpha(p.wall, 0.95));
    g.addColorStop(1, withAlpha(p.wallGlow, 0.55));
    ctx.fillStyle = g;
    roundRectPath(ctx, r.x, r.y, r.w, r.h, Math.min(28, Math.min(r.w, r.h) * 0.4));
    ctx.fill();
    ctx.strokeStyle = withAlpha(p.wallEdge, 0.5 + Math.sin(time * 2) * 0.08);
    ctx.lineWidth = 2;
    ctx.stroke();
    // Glassy bevel: a cool highlight on the upper edge and a darker lower lip.
    ctx.save();
    roundRectPath(ctx, r.x + 3, r.y + 3, Math.max(1, r.w - 6), Math.max(1, r.h - 6), Math.min(24, Math.min(r.w, r.h) * 0.35));
    ctx.clip();
    const sheen = ctx.createLinearGradient(r.x, r.y, r.x, r.y + Math.max(1, r.h));
    sheen.addColorStop(0, "rgba(255,255,255,0.11)");
    sheen.addColorStop(0.22, "rgba(255,255,255,0.025)");
    sheen.addColorStop(0.72, "rgba(0,0,0,0)");
    sheen.addColorStop(1, "rgba(0,0,0,0.22)");
    ctx.fillStyle = sheen;
    ctx.fillRect(r.x + 2, r.y + 2, r.w - 4, r.h - 4);
    ctx.strokeStyle = withAlpha(p.wallEdge, 0.13);
    ctx.lineWidth = 1;
    for (let y = r.y + 15; y < r.y + r.h; y += 42) {
      ctx.beginPath();
      ctx.moveTo(r.x + 10, y);
      ctx.lineTo(r.x + Math.min(r.w - 10, 80), y);
      ctx.stroke();
    }
    ctx.restore();
    // Inner texture dots
    ctx.fillStyle = withAlpha(p.wallEdge, 0.14);
    const step = 34;
    for (let x = r.x + 16; x < r.x + r.w - 8; x += step) {
      for (let y = r.y + 16; y < r.y + r.h - 8; y += step) {
        ctx.beginPath();
        ctx.arc(x + ((y / step) % 2) * 10, y, 2.6, 0, TAU);
        ctx.fill();
      }
    }
  }
}

function drawAcids(
  ctx: CanvasRenderingContext2D,
  w: World,
  view: View,
  time: number,
) {
  for (const a of w.stage.acids) {
    if (
      a.x + a.r < view.x ||
      a.y + a.r < view.y ||
      a.x - a.r > view.x + view.w ||
      a.y - a.r > view.y + view.h
    )
      continue;
    ctx.save();
    const g = ctx.createRadialGradient(a.x, a.y, a.r * 0.2, a.x, a.y, a.r);
    g.addColorStop(0, "rgba(214,255,61,0.42)");
    g.addColorStop(0.7, "rgba(150,220,40,0.26)");
    g.addColorStop(1, "rgba(90,180,20,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(a.x, a.y, a.r, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = "rgba(214,255,61,0.55)";
    ctx.lineWidth = 2;
    ctx.setLineDash([10, 12]);
    ctx.beginPath();
    ctx.arc(a.x, a.y, a.r * (0.96 + Math.sin(time * 1.5) * 0.02), 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
    // Layered, shifting surface ripples and specular glints.
    for (let i = 0; i < 3; i++) {
      const rr = a.r * (0.28 + i * 0.2);
      ctx.globalAlpha = 0.18 + Math.sin(time * 1.8 + i * 1.7) * 0.07;
      ctx.strokeStyle = i === 0 ? "rgba(245,255,195,0.95)" : "rgba(170,255,75,0.65)";
      ctx.lineWidth = i === 0 ? 2 : 1.3;
      ctx.beginPath();
      ctx.ellipse(a.x + Math.sin(time * 0.35 + i) * a.r * 0.12,
        a.y + Math.cos(time * 0.28 + i) * a.r * 0.1,
        rr, rr * (0.62 + Math.sin(time + i) * 0.05), time * 0.08 + i, 0.4, Math.PI * 1.65);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    // Bubbles
    ctx.fillStyle = "rgba(230,255,150,0.5)";
    for (let i = 0; i < 9; i++) {
      const ang = (i / 9) * TAU + time * 0.25;
      const rr = a.r * (0.3 + 0.5 * ((i * 37) % 10) / 10);
      const s = 3 + ((i * 13) % 5);
      const rise = ((time * 30 + i * 20) % 60) / 60;
      ctx.beginPath();
      ctx.arc(
        a.x + Math.cos(ang) * rr,
        a.y + Math.sin(ang) * rr - rise * 24,
        s * (1 - rise * 0.6),
        0,
        TAU,
      );
      ctx.fill();
    }
    ctx.restore();
  }
}

function drawCurrents(
  ctx: CanvasRenderingContext2D,
  w: World,
  view: View,
  time: number,
) {
  for (const c of w.stage.currents) {
    const r = c.rect;
    if (
      r.x + r.w < view.x ||
      r.y + r.h < view.y ||
      r.x > view.x + view.w ||
      r.y > view.y + view.h
    ) continue;

    const horizontal = Math.abs(c.dir.x) >= Math.abs(c.dir.y);
    const extent = horizontal ? r.w : r.h;
    const transverse = horizontal ? r.h : r.w;
    const movement = time * (0.28 + c.strength * 0.0014);

    // Currents affect gameplay in rectangular trigger volumes, but the artwork
    // should not expose those invisible physics rectangles as hard-edged tiles.
    // These broad, curved strokes fade along their travel axis and sit inside
    // the lane, leaving the background visible through the whole current.
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    const flowGradient = horizontal
      ? ctx.createLinearGradient(r.x, r.y, r.x + r.w, r.y)
      : ctx.createLinearGradient(r.x, r.y, r.x, r.y + r.h);
    flowGradient.addColorStop(0, "rgba(80,170,255,0)");
    flowGradient.addColorStop(0.1, "rgba(80,170,255,0.006)");
    flowGradient.addColorStop(0.24, "rgba(90,185,255,0.025)");
    flowGradient.addColorStop(0.5, "rgba(110,205,255,0.045)");
    flowGradient.addColorStop(0.76, "rgba(90,185,255,0.025)");
    flowGradient.addColorStop(0.9, "rgba(80,170,255,0.006)");
    flowGradient.addColorStop(1, "rgba(80,170,255,0)");

    const laneCount = Math.max(3, Math.min(7, Math.floor(transverse / 31)));
    for (let lane = 0; lane < laneCount; lane++) {
      const ratio = (lane + 1) / (laneCount + 1);
      const cross = (horizontal ? r.y : r.x) + transverse * ratio;
      const amp = Math.min(16, transverse * 0.075);
      const phase = movement + lane * 1.71;
      ctx.strokeStyle = flowGradient;
      ctx.globalAlpha = 1;
      ctx.lineWidth = 9 + (lane % 3) * 4;
      ctx.beginPath();
      if (horizontal) {
        ctx.moveTo(r.x - 38, cross + Math.sin(phase) * amp);
        ctx.bezierCurveTo(
          r.x + extent * 0.28, cross + Math.sin(phase + 1.2) * amp,
          r.x + extent * 0.68, cross + Math.cos(phase + 0.6) * amp,
          r.x + extent + 38, cross + Math.sin(phase + 2.1) * amp,
        );
      } else {
        ctx.moveTo(cross + Math.sin(phase) * amp, r.y - 38);
        ctx.bezierCurveTo(
          cross + Math.sin(phase + 1.2) * amp, r.y + extent * 0.28,
          cross + Math.cos(phase + 0.6) * amp, r.y + extent * 0.68,
          cross + Math.sin(phase + 2.1) * amp, r.y + extent + 38,
        );
      }
      ctx.stroke();

      // A finer strand layered over the haze makes direction readable without
      // restoring the old rectangular fill or creating a sharp boundary.
      ctx.strokeStyle = horizontal
        ? ctx.createLinearGradient(r.x, cross, r.x + r.w, cross)
        : ctx.createLinearGradient(cross, r.y, cross, r.y + r.h);
      const fine = ctx.strokeStyle as CanvasGradient;
      fine.addColorStop(0, "rgba(150,220,255,0)");
      fine.addColorStop(0.16, "rgba(150,220,255,0.07)");
      fine.addColorStop(0.5, "rgba(170,235,255,0.16)");
      fine.addColorStop(0.84, "rgba(150,220,255,0.07)");
      fine.addColorStop(1, "rgba(150,220,255,0)");
      ctx.lineWidth = 1.1 + (lane % 2) * 0.45;
      ctx.beginPath();
      if (horizontal) {
        ctx.moveTo(r.x - 24, cross + Math.sin(phase) * amp * 0.7);
        ctx.bezierCurveTo(
          r.x + extent * 0.3, cross + Math.sin(phase + 0.8) * amp * 0.8,
          r.x + extent * 0.7, cross + Math.cos(phase + 0.5) * amp * 0.8,
          r.x + extent + 24, cross + Math.sin(phase + 1.9) * amp * 0.7,
        );
      } else {
        ctx.moveTo(cross + Math.sin(phase) * amp * 0.7, r.y - 24);
        ctx.bezierCurveTo(
          cross + Math.sin(phase + 0.8) * amp * 0.8, r.y + extent * 0.3,
          cross + Math.cos(phase + 0.5) * amp * 0.8, r.y + extent * 0.7,
          cross + Math.sin(phase + 1.9) * amp * 0.7, r.y + extent + 24,
        );
      }
      ctx.stroke();
    }
    ctx.restore();

    // Small directional arrows float inside the flow and fade near the physics
    // bounds. They never touch the rectangle's borders, so no hard clipped ends
    // can expose the underlying current volume.
    ctx.save();
    ctx.strokeStyle = "rgba(150,220,255,0.33)";
    ctx.lineWidth = 2.1;
    ctx.lineCap = "round";
    const spacing = 110;
    const margin = Math.min(58, transverse * 0.28);
    const offset = (time * c.strength) % spacing;
    const startX = r.x + (horizontal ? 44 : margin);
    const endX = r.x + r.w - (horizontal ? 44 : margin);
    const startY = r.y + (horizontal ? margin : 44);
    const endY = r.y + r.h - (horizontal ? margin : 44);
    for (let bx = startX + offset * c.dir.x; bx < endX; bx += spacing) {
      for (let by = startY + (c.dir.y !== 0 ? offset * c.dir.y : 0); by < endY; by += spacing) {
        const edgeX = Math.min(bx - r.x, r.x + r.w - bx);
        const edgeY = Math.min(by - r.y, r.y + r.h - by);
        const fade = clamp(Math.min(edgeX, edgeY) / Math.max(28, margin), 0, 1);
        if (fade < 0.08) continue;
        ctx.globalAlpha = fade * 0.78;
        const len = 32;
        const a = Math.atan2(c.dir.y, c.dir.x);
        ctx.beginPath();
        ctx.moveTo(bx - Math.cos(a) * len * 0.5, by - Math.sin(a) * len * 0.5);
        ctx.lineTo(bx + Math.cos(a) * len * 0.5, by + Math.sin(a) * len * 0.5);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(bx + Math.cos(a) * len * 0.5, by + Math.sin(a) * len * 0.5);
        ctx.lineTo(bx + Math.cos(a - 0.6) * len * 0.22, by + Math.sin(a - 0.6) * len * 0.22);
        ctx.moveTo(bx + Math.cos(a) * len * 0.5, by + Math.sin(a) * len * 0.5);
        ctx.lineTo(bx + Math.cos(a + 0.6) * len * 0.22, by + Math.sin(a + 0.6) * len * 0.22);
        ctx.stroke();
      }
    }
    ctx.restore();
  }
}

function drawDecor(ctx: CanvasRenderingContext2D, w: World, view: View, time: number) {
  const p = w.stage.palette;
  for (const d of w.decor) {
    if (
      d.pos.x + d.r < view.x ||
      d.pos.y + d.r < view.y ||
      d.pos.x - d.r > view.x + view.w ||
      d.pos.y - d.r > view.y + view.h
    )
      continue;
    const wobble = Math.sin(time * 0.6 + d.hue * 6) * 0.08;
    ctx.save();
    ctx.translate(d.pos.x, d.pos.y);
    ctx.rotate(time * d.spin * 0.1 + d.hue * TAU);
    ctx.globalAlpha = d.a;
    const g = ctx.createRadialGradient(0, 0, d.r * 0.1, 0, 0, d.r);
    g.addColorStop(0, withAlpha(p.blob, 0.6));
    g.addColorStop(1, withAlpha(p.blob, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    if (d.kind === 0) ctx.arc(0, 0, d.r * (1 + wobble), 0, TAU);
    else if (d.kind === 1) {
      ctx.ellipse(0, 0, d.r * 0.6, d.r, 0, 0, TAU);
    } else {
      ctx.moveTo(0, -d.r);
      ctx.quadraticCurveTo(d.r, 0, 0, d.r);
      ctx.quadraticCurveTo(-d.r, 0, 0, -d.r);
    }
    ctx.fill();
    if (d.kind === 1) {
      ctx.strokeStyle = withAlpha(p.blob, 0.35);
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(0, 0, d.r * 0.35, d.r * 0.85, 0, 0, TAU);
      ctx.stroke();
    }
    ctx.restore();
  }
}

/**
 * Continuous microscopic sea. All large color volumes are placed in world
 * coordinates and rendered directly; no repeating bitmap means no square
 * tile borders can appear when the viewport crosses a texture edge.
 */
function drawFluid(ctx: CanvasRenderingContext2D, w: World, view: View) {
  const p = w.stage.palette;
  const world = w.stage.world;
  const field = getFluidField(w);
  ctx.save();

  const base = ctx.createLinearGradient(0, 0, 0, world.h);
  base.addColorStop(0, p.bgA);
  base.addColorStop(0.46, p.fog);
  base.addColorStop(1, p.bgB);
  ctx.fillStyle = base;
  ctx.fillRect(view.x - 90, view.y - 90, view.w + 180, view.h + 180);

  ctx.globalCompositeOperation = "screen";
  for (const cloud of field.clouds) {
    if (cloud.x + cloud.rx < view.x || cloud.y + cloud.ry < view.y ||
        cloud.x - cloud.rx > view.x + view.w || cloud.y - cloud.ry > view.y + view.h) continue;
    const pulse = 0.94 + Math.sin(cloud.phase + w.time * 0.12) * 0.06;
    ctx.save();
    ctx.translate(cloud.x, cloud.y);
    ctx.rotate(cloud.rotation + Math.sin(w.time * 0.025 + cloud.phase) * 0.025);
    ctx.scale(cloud.rx, cloud.ry);
    const gradient = ctx.createRadialGradient(0, 0, 0.015, 0, 0, 1);
    gradient.addColorStop(0, withAlpha(cloud.tint, cloud.alpha * pulse));
    gradient.addColorStop(0.38, withAlpha(cloud.tint, cloud.alpha * 0.64 * pulse));
    gradient.addColorStop(0.72, withAlpha(cloud.tint, cloud.alpha * 0.18));
    gradient.addColorStop(1, withAlpha(cloud.tint, 0));
    ctx.fillStyle = gradient;
    ctx.fillRect(-1, -1, 2, 2);
    ctx.restore();
  }

  // Irregular membrane contours are individually placed and never tiled. The
  // staggered radial offsets avoid rows/columns and keep the world organic.
  ctx.globalCompositeOperation = "screen";
  for (const membrane of field.membranes) {
    if (membrane.x + membrane.rx < view.x || membrane.y + membrane.ry < view.y ||
        membrane.x - membrane.rx > view.x + view.w || membrane.y - membrane.ry > view.y + view.h) continue;
    ctx.save();
    ctx.translate(membrane.x, membrane.y);
    ctx.rotate(membrane.rotation);
    ctx.scale(membrane.rx, membrane.ry);
    const points: { x: number; y: number }[] = [];
    const count = membrane.lobes * 4;
    for (let i = 0; i < count; i++) {
      const a = i / count * TAU;
      const distortion = 1 + Math.sin(a * membrane.lobes + membrane.phase) * 0.075 + Math.cos(a * 3 - membrane.phase * 0.7) * 0.045;
      points.push({ x: Math.cos(a) * distortion, y: Math.sin(a) * distortion });
    }
    ctx.beginPath();
    ctx.moveTo((points[0].x + points[1].x) * 0.5, (points[0].y + points[1].y) * 0.5);
    for (let i = 1; i <= points.length; i++) {
      const cur = points[i % points.length];
      const next = points[(i + 1) % points.length];
      ctx.quadraticCurveTo(cur.x, cur.y, (cur.x + next.x) * 0.5, (cur.y + next.y) * 0.5);
    }
    ctx.closePath();
    ctx.fillStyle = withAlpha(p.blob, membrane.alpha * 0.48);
    ctx.fill();
    ctx.strokeStyle = withAlpha(p.wallGlow, membrane.alpha * 2.05);
    ctx.lineWidth = 1 / Math.max(0.7, Math.min(membrane.rx, membrane.ry));
    ctx.stroke();
    ctx.strokeStyle = withAlpha(p.accent, membrane.alpha * 0.98);
    ctx.lineWidth = 0.65 / Math.max(0.7, Math.min(membrane.rx, membrane.ry));
    ctx.beginPath(); ctx.ellipse(0, 0, 0.76, 0.73, 0.08, 0.15, TAU * 0.91); ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
}

function drawBounds(ctx: CanvasRenderingContext2D, w: World, time: number) {
  const p = w.stage.palette;
  const W = w.stage.world.w;
  const H = w.stage.world.h;
  ctx.save();
  ctx.strokeStyle = withAlpha(p.wallEdge, 0.35);
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.rect(-7, -7, W + 14, H + 14);
  ctx.stroke();
  ctx.strokeStyle = withAlpha(p.wallGlow, 0.18);
  ctx.lineWidth = 40;
  ctx.stroke();
  // Marker ticks
  ctx.strokeStyle = withAlpha(p.wallEdge, 0.2);
  ctx.lineWidth = 3;
  for (let x = 0; x < W; x += 180) {
    const a = 0.12 + Math.sin(time * 1.5 + x * 0.01) * 0.08;
    ctx.globalAlpha = a;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 40, 0);
    ctx.moveTo(x, H);
    ctx.lineTo(x + 40, H);
    ctx.stroke();
  }
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/* Master scene draw                                                   */
/* ------------------------------------------------------------------ */

export function drawScene(
  ctx: CanvasRenderingContext2D,
  w: World,
  view: View,
  time: number,
) {
  const p = w.stage.palette;

  drawFluid(ctx, w, view);
  drawAtmosphere(ctx, w, view, time);
  drawDecor(ctx, w, view, time);
  drawCurrents(ctx, w, view, time);
  drawAcids(ctx, w, view, time);
  drawBounds(ctx, w, time);
  drawWalls(ctx, w, view, time);
  drawTargetCell(ctx, w, time);

  for (const e of w.enemies) {
    if (
      e.pos.x + e.r * 2 < view.x ||
      e.pos.y + e.r * 2 < view.y ||
      e.pos.x - e.r * 2 > view.x + view.w ||
      e.pos.y - e.r * 2 > view.y + view.h
    )
      continue;
    drawEnemy(ctx, e, time);
  }

  for (const pt of w.parts.list) drawParticle(ctx, pt);
  for (const pk of w.pickups) {
    if (
      pk.pos.x + 40 < view.x ||
      pk.pos.y + 40 < view.y ||
      pk.pos.x - 40 > view.x + view.w ||
      pk.pos.y - 40 > view.y + view.h
    )
      continue;
    drawPickup(ctx, pk, p, time);
  }
  for (const b of w.bullets) drawBullet(ctx, b);

  if (w.deathT <= 0) drawVirus(ctx, w.virus, w.traits, time, 1);

  // Floating score text
  for (const t of w.parts.texts) {
    const k = clamp(t.life / t.maxLife, 0, 1);
    ctx.save();
    ctx.globalAlpha = easeOut(k);
    ctx.font = `900 ${t.size}px ui-rounded, "Trebuchet MS", system-ui, sans-serif`;
    ctx.textAlign = "center";
    ctx.lineWidth = 4;
    ctx.strokeStyle = "rgba(0,0,0,0.65)";
    ctx.strokeText(t.text, t.pos.x, t.pos.y);
    ctx.fillStyle = t.color;
    ctx.fillText(t.text, t.pos.x, t.pos.y);
    ctx.restore();
  }
}

/** Screen-space overlays: vignette, damage flash, off-screen goal arrow. */
export function drawOverlays(
  ctx: CanvasRenderingContext2D,
  w: World,
  cw: number,
  ch: number,
  screenCenter: { x: number; y: number },
) {
  // Cinematic, low-contrast edge lighting makes the playfield feel enclosed in a living world.
  const p = w.stage.palette;
  const ambient = ctx.createLinearGradient(0, 0, cw, ch);
  ambient.addColorStop(0, withAlpha(p.accent, 0.035));
  ambient.addColorStop(0.42, "rgba(0,0,0,0)");
  ambient.addColorStop(1, withAlpha(p.blob, 0.035));
  ctx.fillStyle = ambient;
  ctx.fillRect(0, 0, cw, ch);

  // Critical-health warning glow around the viewport
  const hpFrac = w.virus.hp / w.traits.maxHp;
  if (hpFrac < 0.34 && w.deathT <= 0) {
    const intensity = (1 - hpFrac / 0.34) * (0.2 + Math.abs(Math.sin(performance.now() / 240)) * 0.34);
    const g = ctx.createRadialGradient(
      cw / 2,
      ch / 2,
      Math.min(cw, ch) * 0.22,
      cw / 2,
      ch / 2,
      Math.max(cw, ch) * 0.72,
    );
    g.addColorStop(0, "rgba(255,20,60,0)");
    g.addColorStop(1, `rgba(255,20,60,${intensity.toFixed(3)})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, cw, ch);
  }

  if (w.flash > 0.01) {
    ctx.save();
    ctx.globalAlpha = Math.min(0.8, w.flash);
    ctx.fillStyle = w.flashColor;
    ctx.fillRect(0, 0, cw, ch);
    ctx.restore();
  }
  // Off-screen indicator pointing at the goal
  const v = w.virus;
  const dx = w.target.pos.x - v.pos.x;
  const dy = w.target.pos.y - v.pos.y;
  const margin = 46;
  const onScreen =
    w.target.pos.x > screenCenter.x - cw / 2 + margin &&
    w.target.pos.x < screenCenter.x + cw / 2 - margin &&
    w.target.pos.y > screenCenter.y - ch / 2 + margin &&
    w.target.pos.y < screenCenter.y + ch / 2 - margin;
  if (!onScreen && (w.target.unlocked || w.collected > w.stage.quota * 0.5)) {
    const a = Math.atan2(dy, dx);
    const rad = Math.min(cw, ch) * 0.36;
    const x = cw / 2 + Math.cos(a) * rad;
    const y = ch / 2 + Math.sin(a) * rad;
    const pulse = 0.6 + Math.abs(Math.sin(performance.now() / 300)) * 0.4;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(a);
    ctx.globalAlpha = w.target.unlocked ? pulse : pulse * 0.45;
    ctx.fillStyle = w.target.unlocked ? w.stage.palette.dna : "#ffffff";
    ctx.beginPath();
    ctx.moveTo(20, 0);
    ctx.lineTo(-12, 13);
    ctx.lineTo(-6, 0);
    ctx.lineTo(-12, -13);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.globalAlpha = w.target.unlocked ? 0.9 : 0.5;
    ctx.fillStyle = w.target.unlocked ? w.stage.palette.dna : "#ffffff";
    ctx.font = '700 11px ui-monospace, monospace';
    ctx.textAlign = "center";
    const dist = Math.hypot(dx, dy);
    ctx.fillText(
      w.target.unlocked ? `HOST ${Math.round(dist)}m` : `HOST ${Math.round(dist)}m`,
      cw / 2 + Math.cos(a) * (rad + 26),
      ch / 2 + Math.sin(a) * (rad + 26) + 4,
    );
    ctx.restore();
  }
}
