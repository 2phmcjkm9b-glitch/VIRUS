/**
 * Tiny procedural sound engine — every effect is synthesised, no assets.
 */
type SfxName =
  | "pickup"
  | "plasmid"
  | "dash"
  | "hit"
  | "hurt"
  | "explode"
  | "evolve"
  | "infect"
  | "locked"
  | "click"
  | "lose"
  | "win"
  | "boss"
  | "heal"
  | "phase"
  | "hatch";

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  enabled = true;
  private lastAt: Record<string, number> = {};

  init() {
    if (this.ctx || typeof window === "undefined") return;
    const Ctor =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!Ctor) return;
    try {
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
      const len = Math.floor(this.ctx.sampleRate * 0.6);
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.noise = buf;
    } catch {
      this.ctx = null;
    }
  }

  resume() {
    this.init();
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setEnabled(v: boolean) {
    this.enabled = v;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(v ? 0.5 : 0, this.ctx.currentTime, 0.02);
    }
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType,
    vol: number,
    slideTo?: number,
    delay = 0,
  ) {
    if (!this.ctx || !this.master || !this.enabled) return;
    const t0 = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t0 + dur);
    gain.gain.setValueAtTime(0, t0);
    gain.gain.linearRampToValueAtTime(vol, t0 + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain);
    gain.connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  private noiseBurst(dur: number, vol: number, freq: number, q = 1, delay = 0) {
    if (!this.ctx || !this.master || !this.noise || !this.enabled) return;
    const t0 = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(freq, t0);
    filter.frequency.exponentialRampToValueAtTime(Math.max(60, freq * 0.25), t0 + dur);
    filter.Q.value = q;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(vol, t0);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.master);
    src.start(t0);
    src.stop(t0 + dur + 0.02);
  }

  play(name: SfxName, arg = 0) {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    // Throttle identical sounds to avoid audio spam mush.
    const now = this.ctx.currentTime;
    const min = name === "pickup" ? 0.03 : 0.05;
    if (this.lastAt[name] && now - this.lastAt[name] < min) return;
    this.lastAt[name] = now;

    switch (name) {
      case "pickup": {
        const scale = [523, 587, 659, 784, 880, 1046, 1174, 1318];
        const f = scale[Math.min(scale.length - 1, arg)];
        this.tone(f, 0.12, "triangle", 0.22, f * 1.5);
        this.tone(f * 2, 0.06, "sine", 0.09);
        break;
      }
      case "plasmid":
        this.tone(660, 0.1, "square", 0.14, 990);
        this.tone(990, 0.14, "triangle", 0.16, 1480, 0.07);
        break;
      case "dash":
        this.noiseBurst(0.22, 0.28, 1500, 0.8);
        this.tone(240, 0.18, "sawtooth", 0.1, 700);
        break;
      case "hit":
        this.noiseBurst(0.14, 0.3, 900, 1.4);
        this.tone(180, 0.12, "square", 0.12, 90);
        break;
      case "hurt":
        this.tone(200, 0.3, "sawtooth", 0.2, 70);
        this.noiseBurst(0.28, 0.22, 500, 0.7);
        break;
      case "explode":
        this.noiseBurst(0.42, 0.4, 700, 0.6);
        this.tone(120, 0.4, "sine", 0.22, 40);
        break;
      case "evolve":
        [523, 659, 784, 1046, 1318].forEach((f, i) =>
          this.tone(f, 0.5, "triangle", 0.16, f * 1.02, i * 0.075),
        );
        this.noiseBurst(0.7, 0.14, 2600, 0.5, 0.05);
        break;
      case "infect":
        [392, 523, 659, 784, 1046, 1318].forEach((f, i) =>
          this.tone(f, 0.42, "square", 0.11, f, i * 0.06),
        );
        this.noiseBurst(0.9, 0.2, 400, 0.4, 0.1);
        break;
      case "locked":
        this.tone(150, 0.16, "square", 0.1, 110);
        break;
      case "click":
        this.tone(760, 0.06, "square", 0.1, 560);
        break;
      case "boss":
        this.tone(70, 1.1, "sawtooth", 0.26, 42);
        this.noiseBurst(1.2, 0.2, 260, 0.5);
        break;
      case "heal":
        this.tone(520, 0.28, "sine", 0.12, 780);
        this.tone(780, 0.34, "triangle", 0.11, 1170, 0.08);
        this.tone(1040, 0.22, "sine", 0.08, 1320, 0.2);
        break;
      case "phase":
        this.noiseBurst(0.28, 0.16, 2100, 0.55);
        this.tone(420, 0.24, "sawtooth", 0.1, 86);
        this.tone(1150, 0.18, "sine", 0.08, 240, 0.07);
        break;
      case "hatch":
        this.tone(180, 0.3, "sine", 0.16, 92);
        this.tone(310, 0.22, "triangle", 0.1, 520, 0.08);
        this.noiseBurst(0.24, 0.12, 680, 0.8, 0.04);
        break;
      case "lose":
        [440, 349, 261, 174].forEach((f, i) =>
          this.tone(f, 0.55, "sawtooth", 0.16, f * 0.8, i * 0.16),
        );
        break;
      case "win":
        [523, 659, 784, 1046, 1318, 1568].forEach((f, i) =>
          this.tone(f, 0.6, "triangle", 0.15, f, i * 0.11),
        );
        break;
    }
  }
}

export const audio = new AudioEngine();
