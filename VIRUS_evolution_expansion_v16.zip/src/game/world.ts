import { MUTATION_BY_ID, nextEvolveCost, STAGES, buildTraits, type PermanentTraitBonuses } from "./data";
import { Particles } from "./particles";
import { audio } from "./audio";
import type {
  Bullet,
  Enemy,
  EnemyKind,
  Pickup,
  Rect,
  StageDef,
  Traits,
  Vec,
  Virus,
} from "./types";
import {
  TAU,
  chance,
  circleRect,
  clamp,
  dist,
  dist2,
  fromAngle,
  len,
  mulberry32,
  norm,
  rand,
  randInt,
  resolveCircleRect,
  scale,
  smooth,
  sub,
} from "./math";

export interface Decor {
  pos: Vec;
  r: number;
  a: number;
  hue: number;
  kind: number;
  spin: number;
}

const ENEMY_BASE: Record<
  EnemyKind,
  { r: number; hp: number; dmg: number; speed: number; genome: number; score: number }
> = {
  mite: { r: 15, hp: 14, dmg: 8, speed: 46, genome: 1, score: 25 },
  spore: { r: 20, hp: 18, dmg: 10, speed: 58, genome: 2, score: 35 },
  chaser: { r: 34, hp: 78, dmg: 18, speed: 132, genome: 3, score: 70 },
  spiker: { r: 24, hp: 34, dmg: 26, speed: 0, genome: 3, score: 60 },
  hunter: { r: 27, hp: 46, dmg: 12, speed: 118, genome: 4, score: 95 },
  // New late-campaign families are deliberately distinct in role and silhouette.
  symbiote: { r: 31, hp: 68, dmg: 7, speed: 88, genome: 5, score: 130 },
  phantom: { r: 25, hp: 58, dmg: 20, speed: 116, genome: 5, score: 150 },
  incubator: { r: 46, hp: 220, dmg: 12, speed: 24, genome: 7, score: 260 },
  sentinel: { r: 74, hp: 900, dmg: 24, speed: 96, genome: 10, score: 1200 },
};

export class World {
  stageIndex: number;
  stage: StageDef;
  traits: Traits;
  private permanentUpgrades: PermanentTraitBonuses;
  levels: Record<string, number> = {};
  virus: Virus;
  enemies: Enemy[] = [];
  pickups: Pickup[] = [];
  bullets: Bullet[] = [];
  parts = new Particles();
  decor: Decor[] = [];
  private enemySerial = 1;

  target: {
    pos: Vec;
    r: number;
    unlocked: boolean;
    t: number;
    hitT: number;
    infected: number;
  };

  cam: { pos: Vec; shake: number; shakeAngle: number; zoom: number } = {
    pos: { x: 0, y: 0 },
    shake: 0,
    shakeAngle: 0,
    zoom: 1,
  };

  time = 0;
  dna = 0;
  dnaNeeded: number;
  collected = 0;
  evolutionCount = 0;
  score: number;
  combo = 1;
  comboTimer = 0;
  kills = 0;
  dnaTotal = 0;
  bestCombo = 1;

  spawnTimer = 0;
  pickupTimer = 0;
  acidTick = 0;
  shakeAmt = 0;
  flash = 0;
  flashColor = "#ffffff";
  slowmo = 0;
  hitStop = 0;

  hint = "";
  hintT = 0;
  hintIdx = 0;
  tut = {
    moved: false,
    dna: 0,
    dashed: false,
    kill: false,
    evolved: false,
  };

  finished: null | "clear" | "dead" = null;
  infectT = 0;
  deathT = 0;
  pendingEvolve = false;
  evolvedThisStage = 0;

  constructor(
    stageIndex: number,
    levels: Record<string, number>,
    score: number,
    permanentUpgrades: PermanentTraitBonuses = {},
  ) {
    this.stageIndex = clamp(stageIndex, 0, STAGES.length - 1);
    this.stage = STAGES[this.stageIndex];
    this.levels = { ...levels };
    this.score = score;
    this.permanentUpgrades = { ...permanentUpgrades };
    this.traits = this.rebuildTraits();
    this.dnaNeeded = nextEvolveCost(0, this.stage);

    this.virus = {
      pos: { x: this.stage.world.w * 0.12, y: this.stage.world.h * 0.5 },
      vel: { x: 0, y: 0 },
      angle: 0,
      spin: 0,
      r: this.traits.radius,
      hp: this.traits.maxHp,
      invuln: 1.2,
      hitFlash: 0,
      hurt: 0,
      dashTime: 0,
      dashCd: 0,
      acidGrace: 0,
      dashDir: { x: 1, y: 0 },
      evolveFlash: 0,
      morph: 0,
      trail: [],
      pulse: 0,
      shield: this.traits.shieldMax,
      shieldFlash: 0,
    };
    this.nudgeOut(this.virus.pos, this.traits.radius + 44);
    this.cam.pos = { ...this.virus.pos };

    this.target = {
      pos: {
        x: this.stage.world.w * 0.88,
        y: this.stage.world.h * 0.2,
      },
      r: 84,
      unlocked: false,
      t: 0,
      hitT: 0,
      infected: 0,
    };
    this.nudgeOut(this.target.pos, this.target.r, 520);
    this.buildDecor();
    this.initialPopulate();
    this.spawnIntroJuice();
  }

  /* ---------------------------------------------------------------- */

  private rebuildTraits(): Traits {
    return buildTraits(this.levels, this.permanentUpgrades);
  }

  private isClearPosition(
    p: Vec,
    r: number,
    minDistFromPlayer = 0,
    avoidTarget = false,
    avoidAcid = true,
  ): boolean {
    const margin = Math.max(2, r + 6);
    if (
      p.x < margin ||
      p.y < margin ||
      p.x > this.stage.world.w - margin ||
      p.y > this.stage.world.h - margin
    ) return false;
    if (this.stage.walls.some((w) => circleRect(p, r + 10, w))) return false;
    if (avoidAcid && this.stage.acids.some((a) => dist2(p, a) < (r + a.r + 6) ** 2)) return false;
    if (minDistFromPlayer > 0 && dist2(p, this.virus.pos) < minDistFromPlayer ** 2) return false;
    if (
      avoidTarget &&
      this.target &&
      dist2(p, this.target.pos) < (r + this.target.r + 30) ** 2
    ) return false;
    return true;
  }

  /** Find a position that is inside the arena and outside solid/acid geometry. */
  private findClearPosition(
    r: number,
    preferred: Vec,
    minDistFromPlayer = 0,
    avoidTarget = false,
    avoidAcid = true,
  ): Vec {
    const bounded = {
      x: clamp(preferred.x, r + 8, this.stage.world.w - r - 8),
      y: clamp(preferred.y, r + 8, this.stage.world.h - r - 8),
    };
    if (this.isClearPosition(bounded, r, minDistFromPlayer, avoidTarget, avoidAcid)) return bounded;

    // Try random positions first for variety; every candidate is validated.
    for (let i = 0; i < 100; i++) {
      const candidate = {
        x: rand(this.stage.world.w - r - 20, r + 20),
        y: rand(this.stage.world.h - r - 20, r + 20),
      };
      if (this.isClearPosition(candidate, r, minDistFromPlayer, avoidTarget, avoidAcid)) return candidate;
    }

    // Deterministic grid fallback guarantees we do not silently leave entities
    // embedded in a wall or beyond world bounds after a failed random search.
    const step = Math.max(28, Math.ceil(r * 1.5));
    let best: Vec | null = null;
    let bestD = Number.POSITIVE_INFINITY;
    for (let x = r + 12; x <= this.stage.world.w - r - 12; x += step) {
      for (let y = r + 12; y <= this.stage.world.h - r - 12; y += step) {
        const candidate = { x, y };
        if (!this.isClearPosition(candidate, r, minDistFromPlayer, avoidTarget, avoidAcid)) continue;
        const d = dist2(candidate, preferred);
        if (d < bestD) {
          best = candidate;
          bestD = d;
        }
      }
    }
    if (best) return best;

    // Last-resort relaxation: preserve bounds and wall clearance even if a
    // particular map has no cell outside acid near all requested constraints.
    if (avoidAcid || minDistFromPlayer > 0 || avoidTarget) {
      return this.findClearPosition(r, preferred, 0, false, false);
    }
    return bounded;
  }

  private nudgeOut(p: Vec, r: number, minDistFromPlayer = 0) {
    const safe = this.findClearPosition(r, p, minDistFromPlayer, false, true);
    p.x = safe.x;
    p.y = safe.y;
  }

  private buildDecor() {
    const rng = mulberry32(1337 + this.stage.id * 977);
    const n = 26;
    for (let i = 0; i < n; i++) {
      this.decor.push({
        pos: {
          x: rng() * this.stage.world.w,
          y: rng() * this.stage.world.h,
        },
        r: 60 + rng() * 200,
        a: 0.05 + rng() * 0.11,
        hue: rng(),
        kind: Math.floor(rng() * 3),
        spin: (rng() - 0.5) * 0.5,
      });
    }
  }

  private initialPopulate() {
    for (const [kind, count] of Object.entries(this.stage.spawns)) {
      for (let i = 0; i < (count ?? 0); i++) {
        this.spawnEnemy(kind as EnemyKind);
      }
    }
    for (let i = 0; i < this.stage.pickupCount; i++) this.spawnPickup();
    // A welcoming cluster right in front of the player so the first ten
    // seconds are immediately rewarding.
    const start = fromAngle(rand(TAU), 1);
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * TAU;
      this.spawnPickup("dna", {
        x: this.virus.pos.x + Math.cos(a) * 150 + start.x * 120,
        y: this.virus.pos.y + Math.sin(a) * 150 + start.y * 120,
      });
    }
  }

  private spawnIntroJuice() {
    this.parts.ring(this.virus.pos, this.stage.palette.accent, 20, 0.6, 420);
    this.parts.burst(this.virus.pos, 22, this.stage.palette.accent, 260, 4, 0.7);
    if (this.stageIndex === 0) this.setHint(this.stage.hints[0], 7);
    else this.setHint(this.stage.hints[0], 5);
  }

  /* ---------------------------------------------------------------- */

  openPos(r: number, minDistFromPlayer = 0): Vec {
    for (let i = 0; i < 100; i++) {
      const p = {
        x: rand(this.stage.world.w - r - 24, r + 24),
        y: rand(this.stage.world.h - r - 24, r + 24),
      };
      if (this.isClearPosition(p, r, minDistFromPlayer, true, true)) return p;
    }
    return this.findClearPosition(r, this.target.pos, minDistFromPlayer, true, true);
  }

  spawnEnemy(kind: EnemyKind, at?: Vec, generation = 0, summonedBy: number | null = null) {
    const base = ENEMY_BASE[kind];
    const gen = Math.max(0, generation);
    // Split/reproduced enemies request a point near their parent; validate that
    // point just like a naturally spawned enemy so a wall edge or map boundary
    // can never embed the child in blocked geometry.
    const pos = at
      ? this.findClearPosition(base.r + 8, at, 0, true, true)
      : this.openPos(base.r + 8, kind === "sentinel" ? 0 : 620);
    const scale = 1 + this.stageIndex * 0.06;
    const e: Enemy = {
      uid: this.enemySerial++,
      kind,
      pos,
      vel: { x: 0, y: 0 },
      r: base.r * (gen === 0 ? 1 : gen === 1 ? 0.72 : 0.52),
      hp: base.hp * scale * (gen === 0 ? 1 : gen === 1 ? 0.6 : 0.36),
      maxHp: base.hp * scale * (gen === 0 ? 1 : gen === 1 ? 0.6 : 0.36),
      dmg: base.dmg * (gen === 0 ? 1 : 0.7),
      angle: rand(TAU),
      spin: rand(3, -3),
      t: rand(10),
      cool: rand(2),
      wander: fromAngle(rand(TAU), 1),
      hitFlash: 0,
      alive: true,
      genome: base.genome,
      score: base.score,
      seed: rand(1000),
      home: { ...pos },
      aggro: 0,
      shielded: kind === "sentinel" && this.collected < this.stage.quota,
      phase: gen,
      specialState: "idle",
      specialTimer: 0,
      specialCooldown: kind === "symbiote" ? rand(1.8, 0.8)
        : kind === "phantom" ? rand(3.2, 1.8)
        : kind === "incubator" ? rand(4.2, 3.2)
        : 0,
      specialTargetId: null,
      specialTarget: null,
      specialVector: { x: 0, y: 0 },
      stealth: kind === "phantom" ? 0.46 : 0,
      summonedBy,
      specialCount: 0,
    };
    this.enemies.push(e);
    return e;
  }

  /** Keep loot inside the arena, outside walls and acid, and away from the host. */
  private safePos(p: Vec, r: number): Vec {
    return this.findClearPosition(r, p, 0, true, true);
  }

  spawnPickup(kind: "dna" | "plasmid" | "heal" | "shield" = "dna", at?: Vec, value = 1) {
    const p: Pickup = {
      kind,
      pos: at ? this.safePos(at, 14) : this.openPos(16),
      vel: { x: rand(40, -40), y: rand(40, -40) },
      r: kind === "plasmid" ? 15 : kind === "heal" ? 14 : 9,
      t: rand(6),
      alive: true,
      value: kind === "plasmid" ? 5 : kind === "heal" ? 0 : value,
      seed: rand(100),
    };
    this.pickups.push(p);
    return p;
  }

  /* ---------------------------------------------------------------- */

  setHint(text: string, seconds = 4.5) {
    if (!text) return;
    this.hint = text;
    this.hintT = seconds;
  }

  private advanceHint(i: number) {
    if (i > this.hintIdx) {
      this.hintIdx = i;
      this.setHint(this.stage.hints[Math.min(i, this.stage.hints.length - 1)], 5.5);
    }
  }

  addScore(n: number) {
    this.score += Math.round(n);
  }

  shake(amount: number) {
    this.shakeAmt = Math.min(34, this.shakeAmt + amount);
  }

  doFlash(color: string, amount = 0.5) {
    this.flashColor = color;
    this.flash = Math.max(this.flash, amount);
  }

  /* ---------------------------------------------------------------- */

  update(dt: number, moveDir: Vec, moveMag: number, dashRequested: boolean) {
    this.parts.update(dt);

    // Death and infection are terminal transitions. Keep only their animation
    // alive; never continue combat, pickups, spawning, scoring or evolution.
    if (this.finished) return;
    if (this.deathT > 0) {
      this.deathT = Math.max(0, this.deathT - dt);
      if (this.deathT <= 0) this.finished = "dead";
      this.updateCamera(dt);
      this.parts.cull(this.virus.pos, 1500);
      return;
    }
    if (this.infectT > 0) {
      this.updateInfect(dt);
      this.updateCamera(dt);
      this.parts.cull(this.virus.pos, 1500);
      return;
    }

    // Count active gameplay only, excluding death/goal cinematics.
    this.time += dt;
    this.updateVirus(dt, moveDir, moveMag, dashRequested);
    // Damage could have started the death animation during updateVirus.
    if (this.deathT <= 0 && !this.finished) this.updateEnemies(dt);
    if (this.deathT <= 0 && !this.finished) this.updatePickups(dt);
    if (this.deathT <= 0 && !this.finished) this.updateBullets(dt);
    if (this.deathT <= 0 && !this.finished) this.updateSpawning(dt);
    if (this.deathT <= 0 && !this.finished) this.updateTarget(dt);
    this.updateCamera(dt);

    if (this.deathT > 0) {
      this.parts.cull(this.virus.pos, 1500);
      return;
    }

    // Timers
    this.hintT = Math.max(0, this.hintT - dt);
    this.comboTimer -= dt;
    if (this.comboTimer <= 0 && this.combo > 1) {
      this.combo = 1;
    }
    this.shakeAmt *= Math.exp(-6 * dt);
    this.flash = Math.max(0, this.flash - dt * 2.2);
    this.slowmo = Math.max(0, this.slowmo - dt);
    this.virus.morph = Math.max(0, this.virus.morph - dt * 1.4);
    this.virus.evolveFlash = Math.max(0, this.virus.evolveFlash - dt * 1.6);

    this.parts.cull(this.virus.pos, 1500);

    if (this.dna >= this.dnaNeeded && !this.pendingEvolve && !this.finished) {
      if (this.hasEvolvable()) {
        this.pendingEvolve = true;
      } else {
        // Fully mutated specimen: overflow DNA becomes score and repairs.
        const n = this.dna;
        this.addScore(n * 6);
        this.virus.hp = this.traits.maxHp;
        this.virus.shield = this.traits.shieldMax;
        this.dna = 0;
        this.parts.text(this.virus.pos, `PERFECT FORM +${n * 6}`, "#ffe066", 24, {
          x: 0,
          y: -40,
        });
        this.parts.ring(this.virus.pos, "#ffe066", 20, 0.6, 500);
        audio.play("plasmid");
      }
    }
    if (this.collected >= this.stage.quota && !this.target.unlocked) {
      this.target.unlocked = true;
      this.advanceHint(this.stage.boss ? 3 : this.stage.hints.length - 1);
      this.doFlash(this.stage.palette.accent, 0.55);
      this.shake(12);
      this.parts.ring(
        this.target.pos,
        this.stage.palette.dna,
        60,
        1.1,
        900,
      );
      this.parts.text(
        this.target.pos,
        "MEMBRANE OPEN",
        this.stage.palette.dna,
        26,
        { x: 0, y: -30 },
      );
      audio.play("plasmid");
    }
  }

  /* ---------------------------------------------------------------- */

  private updateVirus(dt: number, dir: Vec, mag: number, dashRequested: boolean) {
    const v = this.virus;
    const t = this.traits;
    if (this.infectT > 0 || this.deathT > 0) return;

    v.pulse += dt * (3 + len(v.vel) / 120);
    v.spin += dt * 0.55;
    v.invuln = Math.max(0, v.invuln - dt);
    v.acidGrace = Math.max(0, v.acidGrace - dt);
    v.hitFlash = Math.max(0, v.hitFlash - dt * 3);
    v.hurt = Math.max(0, v.hurt - dt * 2);
    v.dashCd = Math.max(0, v.dashCd - dt);
    v.shieldFlash = Math.max(0, v.shieldFlash - dt * 2.5);
    if (t.regen > 0 && v.hp < t.maxHp) {
      v.hp = Math.min(t.maxHp, v.hp + t.regen * dt);
    }

    // Dash
    if (dashRequested && v.dashCd <= 0) {
      const d =
        mag > 0.05
          ? { x: dir.x, y: dir.y }
          : { x: Math.cos(v.angle), y: Math.sin(v.angle) };
      v.dashDir = d;
      v.dashTime = t.dashTime;
      v.dashCd = t.dashCd;
      // The dash is advertised as a safe way to cross acid. Keep a short
      // acid-only grace period after the fast burst so normal speed can carry
      // the player beyond the far edge of the pool; this does not extend
      // invulnerability against enemies or bullets.
      v.acidGrace = Math.max(v.acidGrace, t.dashTime + 0.65);
      v.invuln = Math.max(v.invuln, t.dashInvuln);
      audio.play("dash");
      this.shake(6);
      this.parts.ring(v.pos, "#ffffff", t.radius * 0.7, 0.28, 340);
      this.parts.burst(v.pos, 10, this.stage.palette.accent, 240, 3, 0.4);
      if (t.shock > 0) this.shockwave(v.pos, t.shock, t.shockDamage);
      if (this.stageIndex === 0 && !this.tut.dashed) {
        this.tut.dashed = true;
      }
    }

    if (v.dashTime > 0) {
      v.dashTime -= dt;
      const speed = t.dashPower;
      v.vel.x = v.dashDir.x * speed;
      v.vel.y = v.dashDir.y * speed;
      // Dash trail
      if (this.parts.list.length < 300) {
        this.parts.spawn(
          { x: v.pos.x, y: v.pos.y },
          fromAngle(rand(TAU), 30),
          t.radius * 0.5,
          0.32,
          this.stage.palette.accent,
          "blob",
          3,
        );
      }
    } else {
      const accel = t.accel * mag;
      v.vel.x += dir.x * accel * dt;
      v.vel.y += dir.y * accel * dt;
      const dragF = Math.exp(-t.drag * dt);
      v.vel.x *= dragF;
      v.vel.y *= dragF;
      // Currents
      for (const c of this.stage.currents) {
        if (
          v.pos.x > c.rect.x &&
          v.pos.x < c.rect.x + c.rect.w &&
          v.pos.y > c.rect.y &&
          v.pos.y < c.rect.y + c.rect.h
        ) {
          v.vel.x += c.dir.x * c.strength * dt * 2.4;
          v.vel.y += c.dir.y * c.strength * dt * 2.4;
        }
      }
      const sp = len(v.vel);
      const max = t.speed;
      if (sp > max) {
        v.vel.x = (v.vel.x / sp) * max;
        v.vel.y = (v.vel.y / sp) * max;
      }
    }

    v.pos.x += v.vel.x * dt;
    v.pos.y += v.vel.y * dt;

    // Facing
    const sp = len(v.vel);
    if (sp > 12) {
      const want = Math.atan2(v.vel.y, v.vel.x);
      let diff = want - v.angle;
      while (diff > Math.PI) diff -= TAU;
      while (diff < -Math.PI) diff += TAU;
      v.angle += diff * Math.min(1, dt * 12);
    }

    // Bounds
    const R = v.r;
    if (v.pos.x < R) {
      v.pos.x = R;
      v.vel.x = Math.abs(v.vel.x) * 0.4;
    }
    if (v.pos.x > this.stage.world.w - R) {
      v.pos.x = this.stage.world.w - R;
      v.vel.x = -Math.abs(v.vel.x) * 0.4;
    }
    if (v.pos.y < R) {
      v.pos.y = R;
      v.vel.y = Math.abs(v.vel.y) * 0.4;
    }
    if (v.pos.y > this.stage.world.h - R) {
      v.pos.y = this.stage.world.h - R;
      v.vel.y = -Math.abs(v.vel.y) * 0.4;
    }

    // Walls
    for (const w of this.stage.walls) {
      const push = resolveCircleRect(v.pos, R, w);
      if (push) {
        v.pos.x += push.x;
        v.pos.y += push.y;
        const n = norm(push);
        const dotP = v.vel.x * n.x + v.vel.y * n.y;
        if (dotP < 0) {
          v.vel.x -= 1.5 * dotP * n.x;
          v.vel.y -= 1.5 * dotP * n.y;
        }
      }
    }

    // Trail
    v.trail.unshift({ x: v.pos.x, y: v.pos.y, a: 1 });
    if (v.trail.length > 18) v.trail.pop();
    for (const p of v.trail) p.a *= Math.exp(-4 * dt);

    // Acid damage
    let inAcid = false;
    for (const a of this.stage.acids) {
      if (dist2(v.pos, a) < a.r * a.r) {
        inAcid = true;
        break;
      }
    }
    if (inAcid && v.dashTime <= 0 && v.acidGrace <= 0) {
      this.acidTick += dt;
      if (this.acidTick > 0.35) {
        this.acidTick = 0;
        this.damagePlayer(6, v.pos, true);
      }
      if (chance(dt * 26)) {
        this.parts.spawn(
          { x: v.pos.x + rand(20, -20), y: v.pos.y + rand(20, -20) },
          { x: 0, y: -60 },
          rand(7, 3),
          0.6,
          "#d6ff3d",
          "blob",
          1.2,
        );
      }
    } else {
      // A dash and its acid-only grace period discard partial exposure time.
      this.acidTick = 0;
    }

    // Tutorial triggers
    if (this.stageIndex === 0) {
      if (!this.tut.moved && sp > 60) {
        this.tut.moved = true;
        this.advanceHint(1);
      }
      if (this.tut.dna >= 3) this.advanceHint(2);
      if (this.tut.kill) this.advanceHint(3);
    }
  }

  shockwave(pos: Vec, radius: number, dmg: number) {
    this.parts.ring(pos, "#9ff2ff", 20, 0.4, radius * 2.6);
    this.parts.burst(pos, 14, "#bff6ff", 300, 4, 0.45);
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const d = dist(e.pos, pos);
      if (d < radius + e.r) {
        const push = norm(sub(e.pos, pos));
        e.vel.x += push.x * 340;
        e.vel.y += push.y * 340;
        this.damageEnemy(e, dmg, pos);
      }
    }
  }

  damagePlayer(amount: number, from: Vec, ignoreShield = false) {
    const v = this.virus;
    if (v.invuln > 0 || this.deathT > 0 || this.infectT > 0) return;
    if (v.shield > 0 && !ignoreShield) {
      v.shield -= 1;
      v.shieldFlash = 1;
      v.invuln = 0.9;
      audio.play("hit");
      this.parts.ring(v.pos, "#7cc4ff", v.r + 12, 0.4, 260);
      this.parts.burst(v.pos, 14, "#9fd6ff", 260, 4, 0.5);
      this.shake(9);
      this.parts.text(v.pos, "SHIELD", "#8fd0ff", 18);
      this.knock(from, 260);
      return;
    }
    v.hp -= amount;
    v.invuln = 0.95;
    v.hitFlash = 1;
    v.hurt = 0.5;
    this.combo = Math.max(1, this.combo * 0.6);
    this.shake(16);
    this.doFlash("#ff2d55", 0.42);
    this.hitStop = 0.06;
    audio.play("hurt");
    this.parts.burst(v.pos, 18, "#ff5f7e", 300, 4.5, 0.6);
    this.parts.text(v.pos, `-${Math.round(amount)}`, "#ff6b81", 22);
    this.knock(from, 320);
    if (v.hp <= 0) this.killPlayer();
  }

  private knock(from: Vec, force: number) {
    const v = this.virus;
    const n = norm(sub(v.pos, from));
    v.vel.x += n.x * force;
    v.vel.y += n.y * force;
  }

  private killPlayer() {
    if (this.deathT > 0 || this.finished) return;
    const v = this.virus;
    v.hp = 0;
    this.pendingEvolve = false;
    this.deathT = 1.5;
    this.shake(30);
    this.doFlash("#ff2d55", 0.85);
    audio.play("lose");
    this.parts.burst(v.pos, 60, "#8dff6b", 420, 6, 1.1);
    this.parts.burst(v.pos, 30, "#ffffff", 520, 4, 0.8);
    this.parts.ring(v.pos, "#ffffff", 20, 0.8, 700);
    this.parts.shards(v.pos, 16, "#b6ff7a", 380);
  }

  damageEnemy(e: Enemy, amount: number, from: Vec) {
    if (!e.alive) return;
    if (e.shielded) {
      this.parts.ring(e.pos, "#ffd45e", e.r + 6, 0.25, 180);
      this.parts.burst(e.pos, 4, "#ffd45e", 180, 3, 0.3);
      return;
    }
    e.hp -= amount;
    e.hitFlash = 1;
    e.aggro = Math.max(e.aggro, 3.5);
    audio.play("hit");
    this.parts.burst(from, 6, "#ffffff", 200, 3, 0.35);
    if (e.hp <= 0) this.killEnemy(e);
  }

  killEnemy(e: Enemy) {
    if (!e.alive) return;
    e.alive = false;
    this.kills += 1;
    const gain = Math.round(e.score * this.combo);
    this.addScore(gain);
    this.parts.text(e.pos, `+${gain}`, "#ffe066", e.kind === "sentinel" ? 30 : 18);
    this.parts.burst(e.pos, e.kind === "sentinel" ? 60 : 16, "#ffd0d0", 300, 4, 0.6);
    this.parts.ring(e.pos, "#ffffff", e.r, 0.4, 420);
    this.parts.shards(e.pos, e.kind === "sentinel" ? 22 : 8, "#ff9f9f", 300);
    audio.play("explode");
    this.shake(e.kind === "sentinel" ? 26 : 8);
    if (e.kind === "sentinel") {
      this.doFlash("#ffd45e", 0.7);
      this.parts.text(e.pos, "SENTINEL DOWN", "#ffd45e", 34, { x: 0, y: -40 });
    } else if (e.kind === "symbiote") {
      this.parts.ring(e.pos, "#68ffc1", e.r * 1.2, 0.55, 360);
      this.parts.text(e.pos, "SYMBIONT DISRUPTED", "#8dffd0", 19, { x: 0, y: -24 });
    } else if (e.kind === "phantom") {
      this.doFlash("#a98cff", 0.18);
      this.parts.ring(e.pos, "#b59aff", e.r * 1.3, 0.48, 440);
      this.parts.text(e.pos, "PHASE BROKEN", "#c9b4ff", 19, { x: 0, y: -24 });
    } else if (e.kind === "incubator") {
      this.doFlash("#ff765e", 0.34);
      this.parts.burst(e.pos, 28, "#ff8168", 300, 4.5, 0.72);
      this.parts.ring(e.pos, "#ff9b70", e.r * 1.4, 0.72, 520);
      this.parts.text(e.pos, "NEST DESTROYED", "#ffb08a", 23, { x: 0, y: -28 });
    }
    // Genome drops
    const drops = Math.min(6, e.genome);
    if (e.kind === "sentinel") {
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU;
        this.spawnPickup(
          chance(0.35) ? "plasmid" : "dna",
          { x: e.pos.x + Math.cos(a) * 90, y: e.pos.y + Math.sin(a) * 90 },
        );
      }
    } else {
      for (let i = 0; i < drops; i++) {
        const a = rand(TAU);
        this.spawnPickup("dna", {
          x: e.pos.x + Math.cos(a) * rand(40, 12),
          y: e.pos.y + Math.sin(a) * rand(40, 12),
        });
      }
      if (chance(0.14)) this.spawnPickup("heal", { x: e.pos.x, y: e.pos.y });
      if (this.traits.shieldMax > 0 && chance(0.2))
        this.spawnPickup("shield", { x: e.pos.x + 20, y: e.pos.y });
    }
    // Incubator brood are deliberately non-splitting larvae; otherwise one
    // nest could bypass its four-larva cap through recursive spore fission.
    if (e.kind === "spore" && e.phase < 2 && e.summonedBy === null) {
      for (let i = 0; i < 2; i++) {
        const child = this.spawnEnemy("spore", {
          x: e.pos.x + rand(40, -40),
          y: e.pos.y + rand(40, -40),
        }, e.phase + 1);
        child.vel = fromAngle(rand(TAU), 200);
      }
    }
    if (this.stageIndex === 0 && !this.tut.kill) {
      this.tut.kill = true;
    }
  }

  /* ---------------------------------------------------------------- */

  /** Support unit: retreats behind damaged allies and channels a visible heal. */
  private updateSymbiote(e: Enemy, dt: number) {
    e.specialTarget = null;
    if (e.specialState === "telegraph") {
      const target = this.enemies.find((candidate) => candidate.uid === e.specialTargetId && candidate.alive);
      if (!target || target.kind === "sentinel" || target.hp >= target.maxHp - 0.5 || dist(e.pos, target.pos) > 520) {
        e.specialState = "idle";
        e.specialTimer = 0;
        e.specialTargetId = null;
        e.specialCooldown = 1.1;
      } else {
        e.specialTarget = { ...target.pos };
        e.specialTimer = Math.max(0, e.specialTimer - dt);
        const away = norm(sub(target.pos, this.virus.pos));
        const anchor = { x: target.pos.x + away.x * 105, y: target.pos.y + away.y * 105 };
        const toward = sub(anchor, e.pos);
        const d = len(toward);
        const desired = scale(norm(toward), Math.min(92, d * 1.2));
        e.vel.x = smooth(e.vel.x, desired.x, 2.5, dt);
        e.vel.y = smooth(e.vel.y, desired.y, 2.5, dt);
        if (e.specialTimer <= 0) {
          const healed = Math.min(target.maxHp - target.hp, Math.max(8, Math.round(target.maxHp * 0.16)));
          if (healed > 0) {
            target.hp = Math.min(target.maxHp, target.hp + healed);
            target.hitFlash = Math.max(target.hitFlash, 0.45);
            this.parts.ring(target.pos, "#72ffc2", target.r + 12, 0.62, 300);
            this.parts.burst(target.pos, 12, "#8dffd0", 150, 3.5, 0.58);
            this.parts.text(target.pos, `+${Math.round(healed)} HP`, "#8dffd0", 17, { x: 0, y: -target.r - 10 });
            this.parts.ring(e.pos, "#55eeb1", e.r * 0.85, 0.36, 210);
            audio.play("heal");
          }
          e.specialState = "idle";
          e.specialTimer = 0;
          e.specialCooldown = 5.8;
          e.specialTargetId = null;
          e.specialTarget = null;
        }
      }
      return;
    }

    e.specialCooldown = Math.max(0, e.specialCooldown - dt);
    const target = this.enemies
      .filter((candidate) => candidate.alive && candidate.uid !== e.uid &&
        candidate.kind !== "symbiote" && candidate.kind !== "sentinel" && candidate.kind !== "incubator" &&
        candidate.hp / candidate.maxHp < 0.84 && dist2(candidate.pos, e.pos) < 460 ** 2)
      .sort((a, b) => (a.hp / a.maxHp + dist(e.pos, a.pos) / 1800) - (b.hp / b.maxHp + dist(e.pos, b.pos) / 1800))[0];

    const away = target ? norm(sub(target.pos, this.virus.pos)) : norm(sub(e.pos, this.virus.pos));
    const retreat = len(away) > 0 ? away : fromAngle(e.seed);
    const anchor = target
      ? { x: target.pos.x + retreat.x * 110, y: target.pos.y + retreat.y * 110 }
      : { x: this.virus.pos.x + retreat.x * 330, y: this.virus.pos.y + retreat.y * 330 };
    const toward = sub(anchor, e.pos);
    const d = len(toward);
    const desired = scale(norm(toward), Math.min(108, d * 1.15));
    e.vel.x = smooth(e.vel.x, desired.x, 2.2, dt);
    e.vel.y = smooth(e.vel.y, desired.y, 2.2, dt);

    if (e.specialCooldown <= 0) {
      if (target) {
        e.specialState = "telegraph";
        e.specialTimer = 0.95;
        e.specialTargetId = target.uid;
        e.specialTarget = { ...target.pos };
        this.parts.ring(e.pos, "#66f5bd", e.r * 0.8, 0.42, 190);
      } else {
        e.specialCooldown = 0.65;
      }
    }
  }

  /** Ambusher: becomes translucent, telegraphs its line, then performs one committed dash. */
  private updatePhantom(e: Enemy, dt: number) {
    const toPlayer = sub(this.virus.pos, e.pos);
    const d = len(toPlayer);
    if (e.specialState === "active") {
      e.specialTimer = Math.max(0, e.specialTimer - dt);
      e.stealth = smooth(e.stealth, 0, 10, dt);
      e.vel.x = e.specialVector.x * 520;
      e.vel.y = e.specialVector.y * 520;
      if (e.specialTimer <= 0) {
        e.specialState = "idle";
        e.specialCooldown = 4.5;
        e.vel.x *= 0.28;
        e.vel.y *= 0.28;
      }
      return;
    }
    if (e.specialState === "telegraph") {
      e.specialTimer = Math.max(0, e.specialTimer - dt);
      e.stealth = smooth(e.stealth, 0, 9, dt);
      e.vel.x *= Math.exp(-5 * dt);
      e.vel.y *= Math.exp(-5 * dt);
      e.specialTarget = { ...this.virus.pos };
      if (e.specialTimer <= 0) {
        const aim = norm(toPlayer);
        if (len(aim) > 0) e.specialVector = aim;
        e.specialState = "active";
        e.specialTimer = 0.42;
        audio.play("phase");
        this.parts.ring(e.pos, "#b99aff", e.r * 1.15, 0.35, 420);
      }
      return;
    }

    e.specialCooldown = Math.max(0, e.specialCooldown - dt);
    const cloak = e.specialCooldown > 0.65 ? 0.62 * Math.min(1, (e.specialCooldown - 0.65) / 2.4) : 0.08;
    e.stealth = smooth(e.stealth, cloak, 2.8, dt);
    const n = norm(toPlayer);
    const tangent = Math.sin(e.t * 1.35 + e.seed) > 0 ? 1 : -1;
    const desired = {
      x: n.x * (d > 250 ? 96 : -22) - n.y * tangent * 68,
      y: n.y * (d > 250 ? 96 : -22) + n.x * tangent * 68,
    };
    e.vel.x = smooth(e.vel.x, desired.x, 2.2, dt);
    e.vel.y = smooth(e.vel.y, desired.y, 2.2, dt);
    if (e.specialCooldown <= 0 && d < 610) {
      e.specialState = "telegraph";
      e.specialTimer = 0.78;
      e.specialVector = n;
      e.specialTarget = { ...this.virus.pos };
      e.stealth = 0;
      this.parts.ring(e.pos, "#a98cff", e.r * 1.25, 0.52, 260);
    }
  }

  /** Nest enemy: remains in the rear and hatches up to four living larvae. */
  private updateIncubator(e: Enemy, dt: number) {
    const livingLarvae = this.enemies.filter((candidate) => candidate.alive && candidate.summonedBy === e.uid).length;
    const away = norm(sub(e.pos, this.virus.pos));
    const anchor = { x: e.home.x + away.x * 42, y: e.home.y + away.y * 42 };
    const toward = sub(anchor, e.pos);
    const desired = scale(norm(toward), Math.min(30, len(toward) * 0.55));
    e.vel.x = smooth(e.vel.x, desired.x, 1.25, dt);
    e.vel.y = smooth(e.vel.y, desired.y, 1.25, dt);

    if (e.specialState === "telegraph") {
      e.specialTimer = Math.max(0, e.specialTimer - dt);
      if (e.specialTimer <= 0) {
        const capacity = Math.max(0, 4 - livingLarvae);
        const hatchCount = Math.min(2, capacity);
        for (let i = 0; i < hatchCount; i++) {
          const angle = (e.specialCount + i) * 2.399963229728653 + e.seed;
          const distance = e.r + 54;
          const position = {
            x: e.pos.x + Math.cos(angle) * distance,
            y: e.pos.y + Math.sin(angle) * distance,
          };
          const kind: EnemyKind = e.specialCount % 2 === 0 ? "mite" : "spore";
          const child = this.spawnEnemy(kind, position, 1, e.uid);
          child.vel = fromAngle(angle, 155);
          e.specialCount++;
        }
        this.parts.ring(e.pos, "#ff806b", e.r * 1.35, 0.62, 500);
        this.parts.burst(e.pos, 18 + hatchCount * 5, "#ff9a76", 190, 4, 0.62);
        this.parts.text(e.pos, hatchCount > 0 ? `HATCH +${hatchCount}` : "NEST BLOCKED", "#ffae91", 19);
        if (hatchCount > 0) audio.play("hatch");
        e.specialState = "idle";
        e.specialTimer = 0;
        e.specialCooldown = hatchCount > 0 ? 8.8 : 2.2;
      }
      return;
    }

    e.specialCooldown = Math.max(0, e.specialCooldown - dt);
    if (e.specialCooldown <= 0) {
      if (livingLarvae < 4) {
        e.specialState = "telegraph";
        e.specialTimer = 1.35;
        this.parts.ring(e.pos, "#ff7f68", e.r * 0.95, 0.5, 290);
      } else {
        e.specialCooldown = 0.85;
      }
    }
  }

  private updateEnemies(dt: number) {
    const v = this.virus;
    const dying = this.deathT > 0;
    for (const e of this.enemies) {
      if (this.deathT > 0 || this.infectT > 0 || this.finished) break;
      if (!e.alive) continue;
      e.t += dt;
      e.hitFlash = Math.max(0, e.hitFlash - dt * 3);
      e.aggro = Math.max(0, e.aggro - dt);
      const toV = sub(v.pos, e.pos);
      const d = len(toV);

      switch (e.kind) {
        case "mite":
        case "spore": {
          e.wander = {
            x: e.wander.x + rand(3, -3) * dt,
            y: e.wander.y + rand(3, -3) * dt,
          };
          const wn = norm(e.wander);
          const sp = ENEMY_BASE[e.kind].speed;
          e.vel.x = smooth(e.vel.x, wn.x * sp, 3, dt);
          e.vel.y = smooth(e.vel.y, wn.y * sp, 3, dt);
          e.angle = Math.atan2(e.vel.y, e.vel.x);
          break;
        }
        case "chaser": {
          const range = 470;
          if (d < range || e.aggro > 0) {
            e.aggro = Math.max(e.aggro, 2.2);
            const n = norm(toV);
            const sp = ENEMY_BASE.chaser.speed * (1 + this.stageIndex * 0.08);
            e.vel.x = smooth(e.vel.x, n.x * sp, 2.2, dt);
            e.vel.y = smooth(e.vel.y, n.y * sp, 2.2, dt);
          } else {
            e.wander = norm({
              x: e.wander.x + rand(2, -2) * dt,
              y: e.wander.y + rand(2, -2) * dt,
            });
            e.vel.x = smooth(e.vel.x, e.wander.x * 40, 1.6, dt);
            e.vel.y = smooth(e.vel.y, e.wander.y * 40, 1.6, dt);
          }
          e.angle = Math.atan2(e.vel.y, e.vel.x);
          break;
        }
        case "hunter": {
          const want = 330;
          const n = norm(toV);
          const radial = d > want + 40 ? 1 : d < want - 40 ? -1 : 0;
          const tangential = Math.sin(e.t * 0.7 + e.seed) > 0 ? 1 : -1;
          const sp = ENEMY_BASE.hunter.speed;
          const desired = {
            x: n.x * radial * sp - n.y * tangential * sp * 0.7,
            y: n.y * radial * sp + n.x * tangential * sp * 0.7,
          };
          e.vel.x = smooth(e.vel.x, desired.x, 2.6, dt);
          e.vel.y = smooth(e.vel.y, desired.y, 2.6, dt);
          e.angle = Math.atan2(toV.y, toV.x);
          e.cool -= dt;
          if (e.cool <= 0 && d < 620 && !dying) {
            e.cool = 1.7 - this.stageIndex * 0.12;
            const shots = this.stageIndex >= 2 ? 3 : 2;
            for (let i = 0; i < shots; i++) {
              const spread = (i - (shots - 1) / 2) * 0.22;
              const a = Math.atan2(toV.y, toV.x) + spread;
              this.bullets.push({
                pos: { x: e.pos.x + Math.cos(a) * e.r, y: e.pos.y + Math.sin(a) * e.r },
                vel: fromAngle(a, 260),
                r: 7,
                life: 3.2,
                maxLife: 3.2,
                dmg: 10,
                color: "#ffd23d",
                t: 0,
                hostile: true,
                kind: "bolt",
              });
            }
            this.parts.burst(e.pos, 5, "#ffd23d", 160, 3, 0.3);
          }
          break;
        }
        case "spiker": {
          e.angle += dt * 1.6;
          e.vel.x *= Math.exp(-4 * dt);
          e.vel.y *= Math.exp(-4 * dt);
          break;
        }
        case "symbiote": {
          this.updateSymbiote(e, dt);
          e.angle = Math.atan2(e.vel.y, e.vel.x);
          break;
        }
        case "phantom": {
          this.updatePhantom(e, dt);
          e.angle = Math.atan2(e.specialVector.y, e.specialVector.x);
          break;
        }
        case "incubator": {
          this.updateIncubator(e, dt);
          e.angle += dt * 0.16;
          break;
        }
        case "sentinel": {
          // Its shield is tied to the host membrane state.
          e.shielded = !this.target.unlocked;
          e.angle += dt * 0.8;
          const orbit = 300;
          const ang = e.t * 0.32;
          const target = {
            x: this.target.pos.x + Math.cos(ang) * orbit,
            y: this.target.pos.y + Math.sin(ang) * orbit,
          };
          const dirTo = sub(target, e.pos);
          e.vel.x = smooth(e.vel.x, dirTo.x * 1.6, 2.4, dt);
          e.vel.y = smooth(e.vel.y, dirTo.y * 1.6, 2.4, dt);
          e.cool -= dt;
          if (e.cool <= 0 && !dying) {
            e.cool = e.shielded ? 2.6 : 2.1;
            const n = 14;
            const off = rand(TAU);
            for (let i = 0; i < n; i++) {
              const a = off + (i / n) * TAU;
              this.bullets.push({
                pos: { x: e.pos.x + Math.cos(a) * e.r, y: e.pos.y + Math.sin(a) * e.r },
                vel: fromAngle(a, 210),
                r: 8,
                life: 4,
                maxLife: 4,
                dmg: 12,
                color: "#ff7a2f",
                t: 0,
                hostile: true,
                kind: "wave",
              });
            }
            this.parts.ring(e.pos, "#ff7a2f", e.r, 0.4, 400);
            audio.play("boss");
          }
          break;
        }
      }

      e.pos.x += e.vel.x * dt;
      e.pos.y += e.vel.y * dt;

      // Soft world bounds
      const m = e.r;
      if (e.pos.x < m || e.pos.x > this.stage.world.w - m) {
        e.pos.x = clamp(e.pos.x, m, this.stage.world.w - m);
        e.vel.x *= -0.6;
        e.wander.x *= -1;
      }
      if (e.pos.y < m || e.pos.y > this.stage.world.h - m) {
        e.pos.y = clamp(e.pos.y, m, this.stage.world.h - m);
        e.vel.y *= -0.6;
        e.wander.y *= -1;
      }
      if (e.kind !== "sentinel") {
        for (const w of this.stage.walls) {
          const push = resolveCircleRect(e.pos, e.r, w);
          if (push) {
            e.pos.x += push.x;
            e.pos.y += push.y;
            const n = norm(push);
            const dp = e.vel.x * n.x + e.vel.y * n.y;
            if (dp < 0) {
              e.vel.x -= 1.4 * dp * n.x;
              e.vel.y -= 1.4 * dp * n.y;
            }
            e.wander.x += n.x * 0.6;
            e.wander.y += n.y * 0.6;
            e.wander = norm(e.wander);
          }
        }
      }

      // Contact with player
      if (!dying && this.infectT <= 0) {
        const rr = e.r + v.r;
        if (d < rr) {
          const dashing = v.dashTime > 0;
          if (e.kind === "spiker") {
            this.explodeSpiker(e);
            continue;
          }
          const enzymeDamage = e.r <= this.traits.digestRadius ? this.traits.digest : 0;
          const contactDmg = (dashing ? 26 : 0) + enzymeDamage + this.traits.thorns;
          if (contactDmg > 0) this.damageEnemy(e, contactDmg, v.pos);
          if (e.alive) {
            const contactDamage = e.kind === "phantom" && e.specialState === "active"
              ? Math.round(e.dmg * 1.35)
              : e.dmg;
            this.damagePlayer(contactDamage, e.pos);
            if (e.kind === "phantom" && e.specialState === "active") {
              e.specialState = "idle";
              e.specialTimer = 0;
              e.specialCooldown = 4.5;
              e.vel.x *= -0.42;
              e.vel.y *= -0.42;
            }
            if (this.deathT > 0 || this.finished) break;
            const n = norm(sub(e.pos, v.pos));
            e.vel.x += n.x * (dashing ? 460 : 220);
            e.vel.y += n.y * (dashing ? 460 : 220);
            if (dashing && e.kind !== "sentinel") {
              e.aggro = 0;
            }
          }
        }
      }
    }
    this.enemies = this.enemies.filter((e) => e.alive);
  }

  private explodeSpiker(e: Enemy) {
    e.alive = false;
    this.shake(20);
    this.doFlash("#ff8a3d", 0.4);
    audio.play("explode");
    this.parts.burst(e.pos, 26, "#ff7a2f", 420, 5, 0.7);
    this.parts.shards(e.pos, 12, "#ffd45e", 460);
    this.parts.ring(e.pos, "#ff7a2f", 20, 0.5, 700);
    this.damagePlayer(e.dmg, e.pos);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU;
      this.bullets.push({
        pos: { x: e.pos.x + Math.cos(a) * e.r, y: e.pos.y + Math.sin(a) * e.r },
        vel: fromAngle(a, 230),
        r: 6,
        life: 0.75,
        maxLife: 0.75,
        dmg: 8,
        color: "#ff7a2f",
        t: 0,
        hostile: true,
        kind: "shard",
      });
    }
    this.parts.text(e.pos, "MINE!", "#ff9f5e", 20);
  }

  private updatePickups(dt: number) {
    const v = this.virus;
    const aura = this.traits.aura;
    for (const p of this.pickups) {
      if (!p.alive) continue;
      p.t += dt;
      const to = sub(v.pos, p.pos);
      const d = len(to);
      if (d < aura + (p.kind === "dna" ? 60 : 0)) {
        const pull = clamp(1 - d / (aura + 60), 0, 1);
        const n = norm(to);
        p.vel.x += n.x * 900 * pull * dt;
        p.vel.y += n.y * 900 * pull * dt;
      }
      p.vel.x *= Math.exp(-1.4 * dt);
      p.vel.y *= Math.exp(-1.4 * dt);
      const previous = { x: p.pos.x, y: p.pos.y };
      p.pos.x += p.vel.x * dt;
      p.pos.y += p.vel.y * dt;
      if (this.stage.walls.some((w) => circleRect(p.pos, p.r + 1, w))) {
        p.pos.x = previous.x;
        p.pos.y = previous.y;
        p.vel.x *= -0.45;
        p.vel.y *= -0.45;
      }
      if (p.pos.x < p.r) {
        p.pos.x = p.r;
        p.vel.x = Math.abs(p.vel.x) * 0.5;
      }
      if (p.pos.x > this.stage.world.w - p.r) {
        p.pos.x = this.stage.world.w - p.r;
        p.vel.x = -Math.abs(p.vel.x) * 0.5;
      }
      if (p.pos.y < p.r) {
        p.pos.y = p.r;
        p.vel.y = Math.abs(p.vel.y) * 0.5;
      }
      if (p.pos.y > this.stage.world.h - p.r) {
        p.pos.y = this.stage.world.h - p.r;
        p.vel.y = -Math.abs(p.vel.y) * 0.5;
      }
      if (d < v.r + p.r + 4) this.collect(p);
    }
    this.pickups = this.pickups.filter((p) => p.alive);
  }

  private collect(p: Pickup) {
    p.alive = false;
    const v = this.virus;
    if (p.kind === "heal") {
      const heal = Math.min(25, this.traits.maxHp - v.hp);
      v.hp = Math.min(this.traits.maxHp, v.hp + 25);
      this.parts.text(p.pos, heal > 0 ? `+${Math.round(heal)}` : "FULL", "#7dff9c", 20);
      this.parts.burst(p.pos, 12, "#7dff9c", 200, 4, 0.5);
      audio.play("pickup", 4);
      return;
    }
    if (p.kind === "shield") {
      if (v.shield < this.traits.shieldMax) v.shield += 1;
      v.shieldFlash = 1;
      this.parts.text(p.pos, "SPOR E+", "#8fd0ff", 20);
      this.parts.burst(p.pos, 12, "#8fd0ff", 200, 4, 0.5);
      audio.play("pickup", 5);
      return;
    }
    const amount = Math.max(1, Math.round(p.value));
    this.dna += amount;
    this.collected += amount;
    this.dnaTotal += amount;
    this.tut.dna += 1;
    this.combo = Math.min(6, this.combo + 0.25);
    this.bestCombo = Math.max(this.bestCombo, this.combo);
    this.comboTimer = 2.6;
    const gain = Math.round(10 * this.combo * (p.kind === "plasmid" ? 5 : 1) * this.traits.dnaValue);
    this.addScore(gain);
    this.parts.text(
      p.pos,
      `+${gain}`,
      p.kind === "plasmid" ? "#ffe066" : this.stage.palette.dna,
      p.kind === "plasmid" ? 24 : 17,
    );
    if (p.kind === "plasmid") {
      this.parts.helix(p.pos, 12, "#ffe066");
      this.parts.ring(p.pos, "#ffe066", 10, 0.4, 320);
      this.shake(5);
      audio.play("plasmid");
    } else {
      this.parts.burst(p.pos, 6, this.stage.palette.dna, 170, 3, 0.4);
      audio.play("pickup", Math.min(7, Math.floor(this.combo * 1.2)));
    }
    if (this.traits.shieldMax > 0 && v.shield < this.traits.shieldMax && chance(0.05)) {
      v.shield += 1;
      v.shieldFlash = 0.8;
    }
  }

  private updateBullets(dt: number) {
    const v = this.virus;
    for (const b of this.bullets) {
      b.life -= dt;
      b.t += dt;
      b.pos.x += b.vel.x * dt;
      b.pos.y += b.vel.y * dt;
      if (b.life <= 0) continue;
      if (
        b.pos.x < 0 ||
        b.pos.y < 0 ||
        b.pos.x > this.stage.world.w ||
        b.pos.y > this.stage.world.h
      ) {
        b.life = 0;
        continue;
      }
      let hitWall = false;
      for (const w of this.stage.walls) {
        if (circleRect(b.pos, b.r, w)) {
          hitWall = true;
          break;
        }
      }
      if (hitWall) {
        b.life = 0;
        this.parts.burst(b.pos, 4, b.color, 130, 2.5, 0.3);
        continue;
      }
      if (b.hostile && this.infectT <= 0 && this.deathT <= 0) {
        if (dist2(b.pos, v.pos) < (b.r + v.r) * (b.r + v.r)) {
          b.life = 0;
          this.damagePlayer(b.dmg, b.pos);
        }
      }
    }
    this.bullets = this.bullets.filter((b) => b.life > 0);
  }

  private updateSpawning(dt: number) {
    // Keep the arena stocked with DNA
    const targetCount = this.stage.pickupCount;
    this.pickupTimer -= dt;
    if (this.pickupTimer <= 0 && this.pickups.length < targetCount) {
      this.pickupTimer = 0.9;
      const roll = Math.random();
      this.spawnPickup(
        roll < 0.06 ? "heal" : roll < 0.14 ? "plasmid" : "dna",
      );
    }
    // Trickle enemies back in
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      this.spawnTimer = this.stage.respawnEvery;
      for (const [k, n] of Object.entries(this.stage.respawn)) {
        const kind = k as EnemyKind;
        const alive = this.enemies.filter((e) => e.kind === kind).length;
        const cap = (this.stage.spawns[kind] ?? 0) + 2;
        for (let i = 0; i < (n ?? 0); i++) {
          if (alive + i < cap) this.spawnEnemy(kind);
        }
      }
    }
  }

  private updateTarget(dt: number) {
    const t = this.target;
    t.t += dt;
    t.hitT = Math.max(0, t.hitT - dt);
    if (this.finished || this.infectT > 0 || this.deathT > 0) return;
    const d = dist(this.virus.pos, t.pos);
    if (t.unlocked) {
      if (d < t.r + this.virus.r * 0.6) {
        this.startInfect();
      }
    } else if (d < t.r + this.virus.r + 26) {
      // Repelled by the closed membrane
      const n = norm(sub(this.virus.pos, t.pos));
      this.virus.vel.x += n.x * 700 * dt * 12;
      this.virus.vel.y += n.y * 700 * dt * 12;
      if (t.hitT <= 0) {
        t.hitT = 0.9;
        audio.play("locked");
        this.parts.text(t.pos, "LOCKED — NEED DNA", this.stage.palette.danger, 20, {
          x: 0,
          y: -40,
        });
        this.parts.ring(t.pos, this.stage.palette.danger, t.r, 0.4, 300);
        this.shake(6);
        const remaining = Math.max(0, this.stage.quota - this.collected);
        this.setHint(
          `Membrane sealed — ${remaining} more DNA to unlock the host cell`,
          3.5,
        );
      }
    }
  }

  private startInfect() {
    this.infectT = 1.7;
    this.virus.invuln = 99;
    this.shake(18);
    this.doFlash(this.stage.palette.dna, 0.6);
    audio.play("infect");
    this.parts.ring(this.target.pos, this.stage.palette.dna, 40, 1.2, 900);
    this.parts.burst(this.target.pos, 40, this.stage.palette.dna, 420, 6, 1);
    this.parts.text(this.target.pos, "INFECTION!", "#ffffff", 32, { x: 0, y: -50 });
  }

  private updateInfect(dt: number) {
    this.infectT -= dt;
    const v = this.virus;
    const k = clamp(1 - this.infectT / 1.7, 0, 1);
    const target = this.target.pos;
    v.pos.x = smooth(v.pos.x, target.x, 6, dt);
    v.pos.y = smooth(v.pos.y, target.y, 6, dt);
    v.angle += dt * 6;
    v.pulse += dt * 14;
    if (chance(dt * 40)) {
      this.parts.burst(v.pos, 8, this.stage.palette.dna, 260, 5, 0.6);
    }
    this.target.infected = k;
    if (this.infectT <= 0) {
      this.target.infected = 1;
      this.addScore(600 + Math.round(v.hp) * 3);
      this.finished = "clear";
      this.doFlash("#ffffff", 0.9);
      this.shake(24);
    }
  }

  private updateCamera(dt: number) {
    const v = this.virus;
    const look = scale(v.vel, 0.22);
    const tx = clamp(
      v.pos.x + look.x,
      0,
      this.stage.world.w,
    );
    const ty = clamp(v.pos.y + look.y, 0, this.stage.world.h);
    this.cam.pos.x = smooth(this.cam.pos.x, tx, 5.5, dt);
    this.cam.pos.y = smooth(this.cam.pos.y, ty, 5.5, dt);
    this.cam.shakeAngle = rand(TAU);
  }

  /* ---------------------------------------------------------------- */

  applyMutation(id: string) {
    const def = MUTATION_BY_ID[id];
    if (!def) return;
    const lv = (this.levels[id] ?? 0) + 1;
    if (lv > def.max) return;
    const beforeHp = this.traits.maxHp;
    const beforeShield = this.traits.shieldMax;
    this.levels = { ...this.levels, [id]: lv };
    this.traits = this.rebuildTraits();
    const gained = this.traits.maxHp - beforeHp;
    this.virus.hp = Math.min(this.traits.maxHp, this.virus.hp + Math.max(0, gained));
    this.virus.shield = Math.min(
      this.traits.shieldMax,
      this.virus.shield + Math.max(0, this.traits.shieldMax - beforeShield),
    );
    this.virus.r = this.traits.radius;
    this.evolutionCount += 1;
    this.evolvedThisStage += 1;
    if (this.stageIndex === 0 && !this.tut.evolved) {
      this.tut.evolved = true;
      this.setHint("Mutated! Your body has changed — keep hunting DNA", 5);
    }
    this.dna = 0;
    this.dnaNeeded = nextEvolveCost(this.evolutionCount, this.stage);
    this.addScore(150 * lv);
    this.virus.evolveFlash = 1;
    this.virus.morph = 1;
    this.virus.invuln = Math.max(this.virus.invuln, 1.1);
    this.shake(18);
    this.doFlash(def.tint, 0.65);
    this.slowmo = 0.4;
    audio.play("evolve");
    this.parts.ring(this.virus.pos, def.tint, 20, 0.9, 900);
    this.parts.ring(this.virus.pos, "#ffffff", 10, 0.7, 600);
    this.parts.helix(this.virus.pos, 26, def.tint);
    this.parts.burst(this.virus.pos, 34, def.tint, 380, 5, 0.9);
    this.parts.text(this.virus.pos, `${def.name} LV${lv}`, def.tint, 26, {
      x: 0,
      y: -46,
    });
    this.pendingEvolve = false;
  }

  /** Is there anything left to mutate? */
  hasEvolvable(): boolean {
    return Object.values(MUTATION_BY_ID).some(
      (m) => (this.levels[m.id] ?? 0) < m.max,
    );
  }

  /** Three uniformly sampled, currently-available mutation choices. */
  rollChoices(): string[] {
    const shuffled = Object.values(MUTATION_BY_ID).filter(
      (m) => (this.levels[m.id] ?? 0) < m.max,
    );
    // Fisher–Yates gives every subset of three mutations equal probability.
    // Category-first selection artificially favoured mutations in smaller
    // categories whenever some mutation levels were already maxed.
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled.slice(0, 3).map((mutation) => mutation.id);
  }

  bossHp(): number {
    const boss = this.enemies.find((e) => e.kind === "sentinel" && e.alive);
    if (!boss) return -1;
    return boss.shielded ? -1 : boss.hp / boss.maxHp;
  }

  wallRects(): Rect[] {
    return this.stage.walls;
  }

  randInt(lo: number, hi: number) {
    return randInt(lo, hi);
  }
}
