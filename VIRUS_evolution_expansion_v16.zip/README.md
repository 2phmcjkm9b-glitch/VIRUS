# VIRUS — v16 Enemy Evolution Update

**v16 adds three fully simulated specialist enemy families: Symbiote healer, cloaked Phantom ambusher, and Incubator nest.** Their AI, combat interactions, telegraphs, sounds, world spawns, and distinct procedural sprites are integrated into zones 6–8. v15 seamless-background and mutation-preview work remains included. See `ОБНОВЛЕНИЕ_v16.md` and `АУДИТ_ВРАГОВ_v16.md`. The recommended Windows launcher remains `START_VIRUS.bat`.

---

# VIRUS

A complete, original browser arcade game. You are a living green spiky virus
loose inside a colorful microscopic ecosystem: harvest loose DNA, dodge (or
shred) hostile organisms, **mutate** to visibly evolve your body, and infect the
host cell at the heart of each chamber.

Built with **React 19 + TypeScript + Vite + HTML5 Canvas**. No art assets —
every organism, particle and effect is drawn procedurally, and every sound is
synthesised with the Web Audio API.

---

## Running it

**Windows:** install Node.js 22 LTS (22.12 or newer), extract the ZIP, and double-click `START_VIRUS.bat`. On first launch it installs dependencies, runs the TypeScript check, then starts the dev server and opens the browser. An internet connection is needed for the first install.

**Other systems / terminal:**

```bash
npm ci            # clean, platform-appropriate dependency install
npm run typecheck # TypeScript check
npm test          # critical gameplay regression tests
npm run dev       # development server (http://localhost:5173)
npm run build     # production build -> dist/
npm run preview   # serve the production build
```

Works in any modern desktop or mobile browser. On phones, play in landscape for
the widest view (the game is fully playable in portrait too).

---

## Controls

| Action | Keyboard | Mouse | Touch |
| --- | --- | --- | --- |
| Move | `W A S D` / arrow keys | hold the button — the virus chases the cursor | drag anywhere for a joystick |
| Dash | `Space` or `Shift` | right-click | big ⚡ DASH button |
| Pause | `Esc` or `P` | ❙❙ button | ❙❙ button |
| Choose mutation | `1` `2` `3` / `←→` + `Enter` | click a card | tap a card |
| Restart run | `R` (paused / dead / won) | button | button |
| Mute | `M` | 🔊 button | 🔊 button |

Dash is your only innate weapon: it shreds small organisms, cancels their
damage, and crosses acid pools safely. Everything else is earned by mutating.

---

## The loop

1. **Collect DNA** — glowing double helices (and gold plasmids worth 5). Quick
   chains build a score multiplier up to ×6.
2. **Evolve** — fill the EVOLVE bar and pick one of **three mutations** from
   twelve, each with three tiers. Your capsid visibly grows spikes, tails,
   cilia, plates, tendrils, aura and shield spores.
3. **Hit the quota** — each sector needs a DNA total before the host cell
   membrane unlocks (a progress ring is drawn around it).
4. **Infect** — dive into the open cell to clear the sector.

Score comes from DNA pickups (including the combo and Taxis Sense bonus), kills, mutations and the sector-clear health bonus. Best eight runs are stored in `localStorage`.

---

## Current campaign — v16 specialist enemies, v15 visual polish and mutation-tier visualization

The eight-zone campaign uses a balanced difficulty curve: initial enemy counts rise from 20 through 30, 40, 50 and 60, then 72, 84 and 95 as the late-game specialist families join. DNA quotas rise from 14 to 91, and reinforcements arrive faster in later zones (7 seconds in zone 1 down to 3.5 seconds in zone 8). Five standard enemy types are introduced through the first five zones; a new specialist joins in each of zones 6, 7 and 8.

**Level unlock rule:** zone 1 is always available. Clearing a zone permanently records it as completed and immediately unlocks the next zone. Therefore, if you clear zone 2, zone 3 is available from the level selector even if you later lose in zone 3. The new frontier remains unlocked after defeat and reloading the game; zones beyond that frontier stay closed until the preceding zone is cleared. The selector uses the same unlock rule as the game engine, so it cannot show a zone as open while the engine rejects it.

The campaign progress remains stored redundantly in primary, backup and monotonic completion records in `localStorage`. Replaying a zone starts a separate score/statistics run and does not remove cleared-zone history. A replay uses the best saved mutation loadout for that zone. The selector is available from the main menu, zone-clear screen and run-results screen. The Evolution Map and skippable ending cinematic remain included.

See [ОБНОВЛЕНИЕ_v12.md](./ОБНОВЛЕНИЕ_v12.md) and [АУДИТ_ОШИБОК_v12.md](./АУДИТ_ОШИБОК_v12.md) for the latest independent review, regressions and current test limitations. Earlier save history: [v10](./АУДИТ_СОХРАНЕНИЙ_v10.md) and [v11](./АУДИТ_СОХРАНЕНИЙ_v11.md).


### Latest validation note (v16)

`npm test` passes 72 regression tests, including specialist-enemy AI, healing, ambush timing, brood limits, no recursive brood fission, spawn progression and finite-state stress checks. The game-core strict TypeScript check and React/TSX component check pass. The local packaging environment could not complete a clean npm dependency install, so a full Vite production build and browser smoke test have not been confirmed for v16. On Windows, use `START_VIRUS.bat`, then run `npm test` and `npm run build`; keep the v12–v15 stable folders as rollback points. The rendered specialist gallery is available at [docs/VIRUS_v16_enemy_showcase.png](./docs/VIRUS_v16_enemy_showcase.png).

## The eight sectors

| # | Sector | What makes it different |
| --- | --- | --- |
| 1 | **Plasma Shallows** | Open broth, drifting mites, first macrophages. Tutorial hints fire as you play. |
| 2 | **Acid Ducts** | Walled capillary maze, lytic acid pools that burn over time, immobile spike mines that detonate on contact, aggressive macrophage packs. |
| 3 | **Antibody Storm** | Wide open serum with three pushing currents, antibody hunters that keep range and fire bolt spreads, spores that split in two. |
| 4 | **The Nucleus** | Organelle lattice around a guarded nucleus, a radial-burst **Sentinel** boss. |
| 5 | **Lymphatic Crypt** | Dense living channels, toxic pockets, and stronger hunters. |
| 6 | **Bioelectric Abyss** | Strong currents, distant antibody hunters, dense pillars, and the first **Symbiotes** that heal damaged allies. |
| 7 | **Genetic Collapse** | Intersecting currents, acid zones, crowded groups, returning Symbiotes, and cloaked **Phantoms** that telegraph their ambush dash. |
| 8 | **Pandemic Epicenter** | Symbiotes, Phantoms, an **Incubator** nest that hatches minions, the final **Sentinel**, and the ending sequence. |


## Specialist enemies — v16

The regular enemy roster grows by one specialist family in each of the final three zones. The five original enemy families remain in the late-game mixes.

| First zone | Enemy | Tactical role | Counterplay |
| --- | --- | --- | --- |
| 6 | **Symbiote** | Retreats behind damaged allies and channels a visible green tether. After a 0.95-second telegraph it restores up to 16% of an ally's maximum HP (at least 8 points, capped by missing HP). It cannot heal itself, other Symbiotes, Incubators or the Sentinel. | Break line pressure by targeting the healer first; the channel cancels if its target dies, recovers, or moves more than 520 units away. |
| 7 | **Phantom** | Becomes translucent while stalking, then reveals a purple aim line for 0.78 seconds before a 0.42-second, 520-speed lunge. A successful dash contact deals 1.35× its regular contact damage. | Watch the purple line/reticle and dash sideways. Its outline and refraction rings remain visible while cloaked. |
| 8 | **Incubator** | A slow brood cyst with six visible egg chambers. It telegraphs hatching for 1.35 seconds, then releases up to two alternating Mite/Spore larvae. It maintains a cap of four living direct offspring and has an 8.8-second successful hatch cooldown. | Destroy the nest before hatching. It does not respawn, and its summoned Spores do not split recursively. |

The Incubator is a specialist elite, not a second boss. The zone 8 Sentinel remains the unique final boss and its existing shield/quota rules are unchanged. New enemy types are listed in the corresponding zone briefing before the player starts.

---

## Mutations (12 × 3 tiers)

- **Locomotion** — Flagellum, Cilia Surge, Phase Membrane
- **Membrane** — Chitin Plating, Regen Cytoplasm, Binary Fission (spore shields)
- **Harvest** — Magnetic Genome, Filament Net, Taxis Sense
- **Offense** — Spike Barbs (thorns), Lytic Enzymes (digest on touch),
  Electrostatic Burst (dash shockwave)

Mutations stack across a whole run, and the drawn specimen always reflects the
exact combination you carry (see the live preview on the mutation cards and the
main menu). The **Evolution Map** can be opened from the main menu or pause screen;
it displays all four branches and the three tiers of each mutation. The final zone
ends with a skippable, animated victory cinematic before the results screen.

---

## Project layout

```
src/
  App.tsx                 root
  index.css               theme, animations, UI classes
  components/
    GameShell.tsx         canvas + engine wiring + overlay routing
    Hud.tsx               health, DNA quota, evolve meter, score, touch dash
    Overlays.tsx          start screen, briefing, mutation picker, pause,
                          sector clear, run end, high scores, field manual
    VirusPreview.tsx      animated specimen canvas for menus
  game/
    engine.ts             fixed-step loop, phases, camera, input→world bridge
    world.ts              simulation: virus, enemies, pickups, hazards, scoring
    data.ts               stages, arenas, palettes, mutation definitions
    draw.ts               all procedural art + culling
    particles.ts          pooled particle / floating-text system
    input.ts              keyboard + mouse + touch joystick
    audio.ts              synthesised SFX
    save.ts               localStorage high scores and campaign progression
    math.ts, types.ts     helpers and shared types
```

The simulation runs at a fixed 60 Hz step with an accumulator, so behaviour is
identical on any refresh rate; rendering is once per animation frame with
camera culling, a cached serum pattern, cached glow sprites and a hard particle
cap for a stable 60 fps on mobile.

## Брифинг в начале зоны

Окно с описанием сектора остаётся открытым неограниченно долго, пока игрок сам не подтвердит начало. Нажми Enter или коснись/кликни по окну, чтобы начать уровень. Таймера автоматического закрытия нет; после загрузки нового сектора снова показывается его описание.


## Campaign persistence fix v7

Previously completed zones now remain selectable after continuing to a later zone and losing there. Campaign progress is merged from primary and backup save records plus a separate monotonic completed-zone list. Completing or replaying one zone never removes earlier completions. Future zones that have not been cleared remain locked, as intended.

## Fix v8 — TypeScript startup blocker

Removed an unused `EMPTY_PROGRESS` constant from `src/game/save.ts`. With `noUnusedLocals: true`, it caused TS6133 and stopped startup before the app could run. Campaign save behavior is unchanged. Regression tests still pass (25). Full project typecheck remains unconfirmed in the packaging environment because `npm ci` timed out before installing all type packages; the affected save module and shared game types were checked independently.


## Fix v9 — unlock the next zone immediately after clearing the previous one

The level selector now enables a zone when it is zone 1, already cleared, or the immediately preceding zone has been cleared. This means the newly reached/current zone remains selectable after defeat; only zones beyond the next unlocked frontier remain locked. The UI and engine share the same `isStageUnlocked` predicate to prevent disagreement.


## Save system and permanent evolution — v10

The save model separates four kinds of state:

- **Campaign history:** completed zones and saved best zone-entry mutation builds. Completion is monotonic and read from primary, backup, and separate completed-zone records. The next zone opens after its predecessor is cleared; defeat does not close an unlocked zone.
- **Active campaign checkpoint:** saved at the start of a zone and after clearing a zone (which stores the next zone). Continue resumes at the beginning of that saved zone with its entry mutation build, score, and totals. It does not serialize the exact frame-by-frame state of enemies/player in the middle of a zone.
- **Standalone replay:** does not overwrite or clear a suspended campaign checkpoint. Replay results can update score records and complete a zone for the first time, but a replay defeat leaves a suspended campaign checkpoint intact.
- **Permanent evolution:** first clear of each zone gives 5 essence only once. Three persistent upgrades (`vitality`, `mobility`, `harvest`) cost 2/4/6 per rank; completing all eight zones grants 40 essence and the full tree costs 36. Bought ranks survive defeat and affect newly created zones/runs.

The metadata loader reconciles completed zones against first-clear reward claims, allowing missing reward records to be repaired once while preventing replay farming. Legacy completed-zone saves are migrated. Redundant writes and backup reads are tested with simulated storage-write failures.

See [АУДИТ_СОХРАНЕНИЙ_v10.md](./АУДИТ_СОХРАНЕНИЙ_v10.md). The audit environment could run regression and targeted TypeScript checks, but could not complete a clean dependency install, the standard project typecheck, production build, or browser visual test because the npm dependency download timed out.


## v11 save reliability follow-up

The active-run checkpoint uses a monotonic generation marker (with a backup) to prevent an ended checkpoint from being resurrected when storage deletion fails. Invalid newer checkpoints are filtered before sorting so a good backup can be used. Meta reward markers are advanced only when at least one full meta save succeeds, and malformed oversized revision values cannot mask a healthy backup. See [ОБНОВЛЕНИЕ_v11.md](./ОБНОВЛЕНИЕ_v11.md) and [АУДИТ_СОХРАНЕНИЙ_v11.md](./АУДИТ_СОХРАНЕНИЙ_v11.md).


## Mutation-card tier indicators (v13)

The three small bars below each mutation card now show **current, already-owned ranks** rather than the result after clicking the card:

- **Bright filled bar** — rank already owned before this choice.
- **Outlined, faintly glowing bar** — the next rank offered by this card; it is only a preview and is not owned until the player chooses it.
- **Dim bar** — a later rank that is still locked.

Examples: a new mutation shows an outlined tier 1 and two dim tiers; a rank-2 mutation shows two filled tiers and an outlined tier 3. This avoids making the third rank look already acquired on the selection screen.

Version 13 also updates the lockfile to esbuild 0.28.2, including its matching optional platform packages, to retain the dependency fix applied during the v12 Windows verification. The mutation-tier helper has regression coverage; all 60 regression tests and the strict game/UI stub type checks pass in this working copy.
